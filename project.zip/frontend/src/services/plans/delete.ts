import { useMutation, useQueryClient } from "@tanstack/react-query";
import api from "../api";
import { useToast } from "@/hooks/use-toast";

async function deletePlan(planId: string) {
  const res = await api.delete(`/plans/${planId}`);
  return res.data;
}

export default function useDeletePlan() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const mutation = useMutation({
    mutationFn: deletePlan,

    onSuccess: async () => {
      await queryClient.invalidateQueries({
        queryKey: ["plan.list"],
      });
      toast({
        title: "Plan deleted successfully",
      });
    },
  });
  return mutation.mutateAsync;
}
