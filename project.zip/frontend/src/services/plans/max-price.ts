import { useQuery } from "@tanstack/react-query";
import api from "../api";

type MaxPriceResponse = {
  maxPrice: number;
};

async function getMaxPrice() {
  const res = await api.get<MaxPriceResponse>("/plans/max-price");
  return res.data;
}

export default function useGetMaxPrice() {
  return useQuery({
    queryKey: ["plans.maxPrice"],
    queryFn: getMaxPrice,
  });
}
