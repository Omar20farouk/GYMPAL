import { useMutation, useQueryClient } from "@tanstack/react-query";
import api from "../api";
import { useToast } from "@/hooks/use-toast";

type UpdatePlanPayload = {
  planId: string;
  data: Partial<{
    name: string;
    description: string;
    price: number;
    features: string[];
  }>;
};

async function updatePlan(payload: UpdatePlanPayload) {
  const res = await api.patch(`/plans/${payload.planId}`, payload.data);
  return res.data;
}

export default function useUpdatePlan() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const mutation = useMutation({
    mutationFn: updatePlan,
    onSuccess: async () => {
      await queryClient.invalidateQueries({
        queryKey: ["plan.list"],
      });
      toast({
        title: "Plan updated successfully",
      });
    },
  });
  return mutation.mutateAsync;
}
