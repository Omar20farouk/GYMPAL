import { useMutation, useQueryClient } from "@tanstack/react-query";
import api from "../api";
import { useToast } from "@/hooks/use-toast";

type CreatePlanPayload = {
  name: string;
  description: string;
  price: number;
  features: string[];
};

async function createPlan(payload: CreatePlanPayload) {
  const res = await api.post("/plans", payload);
  return res.data;
}

export default function useCreatePlan() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const mutation = useMutation({
    mutationFn: createPlan,
    onSuccess: async () => {
      await queryClient.invalidateQueries({
        queryKey: ["plan.list"],
      });

      toast({
        title: "Plan created successfully",
      });
    },
  });

  return mutation.mutateAsync;
}
