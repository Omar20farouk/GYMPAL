import { useQuery } from "@tanstack/react-query";
import api from "../api";
import { Plan } from "@/types/plans";

async function getPlans() {
  const res = await api.get<Plan[]>(`/plans`);
  return res.data;
}

export default function useGetPlans() {
  return useQuery({
    queryKey: ["plan.list"],
    queryFn: getPlans,
  });
}
