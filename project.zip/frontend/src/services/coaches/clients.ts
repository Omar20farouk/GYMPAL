import { useQuery } from "@tanstack/react-query";
import api from "../api";

export type ClientWithSubscription = {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  subscriptionStatus: "active" | "expired" | "cancelled" | "none";
  subscriptionPlan?: string;
  startDate?: string;
  endDate?: string;
  lastInteraction?: string;
};

async function getCoachClients() {
  const res = await api.get<ClientWithSubscription[]>(`/coaches/clients`);
  return res.data;
}

export default function useCoachClients() {
  return useQuery({
    queryKey: ["coach.clients"],
    queryFn: () => getCoachClients(),
  });
}
