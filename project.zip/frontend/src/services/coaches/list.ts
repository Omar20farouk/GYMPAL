import { useQuery } from "@tanstack/react-query";
import api from "../api";
import { Coach } from "@/types/coach";
import { toQuery } from "../toQuery";

type CoachFilters = {
  specialty: string | null;
  priceRange: [number, number];
};

async function getCoaches(filters?: CoachFilters) {
  const res = await api.get<Coach[]>(`/coaches?${toQuery(filters ?? {})}`);
  return res.data;
}

export default function useGetCoaches(filters?: CoachFilters) {
  return useQuery({
    queryKey: ["coach.list", filters],
    queryFn: () => getCoaches(filters),
  });
}
