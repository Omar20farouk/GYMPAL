import { useQuery } from "@tanstack/react-query";
import api from "../api";
import { Coach } from "@/types/coach";

async function getCoachById(id: string) {
  const res = await api.get<Coach>(`/coaches/${id}`);
  return res.data;
}

export default function useGetCoachById(id: string) {
  return useQuery({
    queryKey: ["coach", id],
    queryFn: () => getCoachById(id),
  });
}
