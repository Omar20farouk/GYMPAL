import { useQuery } from "@tanstack/react-query";
import api from "../api";

export type EarningsSummary = {
  currentBalance: number;
  totalEarnings: number;
  pendingPayouts: number;
  subscriptions: Array<{
    id: string;
    clientName: string;
    amount: number;
    status: "active" | "cancelled" | "pending";
    planName: string;
    startDate: string;
    endDate: string;
  }>;
};

async function getCoachEarnings() {
  const res = await api.get<EarningsSummary>(`/coaches/earnings`);
  return res.data;
}

export default function useCoachEarnings() {
  return useQuery({
    queryKey: ["coach.earnings"],
    queryFn: () => getCoachEarnings(),
  });
}
