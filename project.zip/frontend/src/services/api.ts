import { useToast } from "@/components/ui/use-toast";
import axios from "axios";

const api = axios.create({
  baseURL: "http://localhost:3001/api",
});

const STATUS_CONFIG = {
  500: { variant: "destructive" as const },
  401: { variant: "warning" as const },
  403: { variant: "warning" as const },
  409: { variant: "warning" as const },
  400: { variant: "warning" as const },
  422: { variant: "warning" as const },
  200: { variant: "default" as const },
} as const;

api.interceptors.request.use((config) => {
  const authStorage = JSON.parse(localStorage.getItem("auth-storage") || "{}");
  if (!authStorage?.state?.token) return config;

  config.headers.Authorization = `Bearer ${authStorage.state.token}`;
  return config;
});

api.interceptors.response.use(
  (res) => res,
  (err) => {
    const res = err.response;
    const data = res?.data;

    if (data?.message) {
      const config = STATUS_CONFIG[
        res.status as keyof typeof STATUS_CONFIG
      ] ?? { title: "Information", variant: "info" as const };

      useToast().toast({
        ...config,
        title:
          res.status >= 500
            ? "An unexpected error occurred. Please try again later."
            : data.message,
      });
    }

    throw new Error(data?.error);
  }
);

export default api;
