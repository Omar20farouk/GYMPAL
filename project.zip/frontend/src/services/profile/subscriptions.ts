import { useQuery } from "@tanstack/react-query";
import api from "../api";
import { Subscription } from "@/types/subscription";

async function getSubscriptions() {
  const res = await api.get<Subscription[]>("/profile/subscriptions");
  return res.data;
}

export function useGetSubscriptions() {
  return useQuery({
    queryKey: ["subscriptions"],
    queryFn: getSubscriptions,
  });
}
