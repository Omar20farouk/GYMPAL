import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import api from "../api";
import { User } from "@/types/user";

async function getProfile() {
  const res = await api.get<User>("/profile");
  return res.data;
}

export function useGetProfile() {
  return useQuery({
    queryKey: ["profile"],
    queryFn: getProfile,
  });
}

type UpdateClientProfileParams = {
  firstName: string;
  lastName: string;
  city: string;
};

async function updateClientProfile(params: UpdateClientProfileParams) {
  const res = await api.patch<User>("/profile/client", params);
  return res.data;
}

export function useUpdateClientProfile() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: updateClientProfile,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["profile"] });
    },
  });
}

type UpdateCoachProfileParams = {
  firstName: string;
  lastName: string;
  city: string;
  experience: number;
  about?: string;
  profilePicture?: string;
  coverPicture?: string;
};

async function updateCoachProfile(params: UpdateCoachProfileParams) {
  const res = await api.patch<User>("/profile/coach", params);
  return res.data;
}

export function useUpdateCoachProfile() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: updateCoachProfile,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["profile"] });
    },
  });
}
