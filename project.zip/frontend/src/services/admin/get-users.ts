import { useQuery } from "@tanstack/react-query";
import api from "../api";
import { User } from "@/types/user";

async function getUsers() {
  const res = await api.get<User[]>("/admin/users");
  return res.data;
}

export function useGetUsers() {
  return useQuery({
    queryKey: ["users"],
    queryFn: getUsers,
  });
}
