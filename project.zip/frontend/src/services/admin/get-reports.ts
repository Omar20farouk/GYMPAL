import { useQuery } from "@tanstack/react-query";
import api from "../api";

export interface Report {
  id: string;
  title: string;
  description: string;
  createdAt: string;
  status: string;
  client: string;
  coach: string;
}

async function getReports() {
  const res = await api.get<Report[]>("/admin/reports");
  return res.data;
}

export default function useGetReports() {
  return useQuery({
    queryKey: ["admin.reports"],
    queryFn: getReports,
  });
}
