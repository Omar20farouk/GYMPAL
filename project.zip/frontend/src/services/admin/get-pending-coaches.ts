import { useQuery } from "@tanstack/react-query";
import api from "../api";
import { Coach } from "@/types/coach";

async function getPendingCoaches() {
  const res = await api.get<Coach[]>("/admin/pending-coaches");
  return res.data;
}

export default function useGetPendingCoaches() {
  return useQuery({
    queryKey: ["admin.pending-coaches"],
    queryFn: getPendingCoaches,
  });
}
