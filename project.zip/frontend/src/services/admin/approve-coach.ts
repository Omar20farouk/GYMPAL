import { useMutation, useQueryClient } from "@tanstack/react-query";
import api from "../api";
import { useToast } from "@/hooks/use-toast";

async function approveCoach(id: string) {
  const res = await api.patch(`/admin/coaches/${id}/approve`);
  return res.data;
}

export default function useApproveCoach() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const mutation = useMutation({
    mutationFn: approveCoach,
    onSuccess: () => {
      toast({
        title: "Coach approved successfully",
      });
      queryClient.invalidateQueries({
        queryKey: ["admin.pending-coaches"],
      });
      queryClient.invalidateQueries({
        queryKey: ["admin.dashboard-stats"],
      });
      queryClient.invalidateQueries({
        queryKey: ["coach.list"],
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to approve coach. Please try again.",
        variant: "destructive",
      });
    },
  });

  return mutation.mutateAsync;
}
