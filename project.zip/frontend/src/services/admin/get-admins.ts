import { useQuery } from "@tanstack/react-query";
import api from "../api";
import { User } from "@/types/user";

async function getAdmins() {
  const res = await api.get<User[]>("/admin/admins");
  return res.data;
}

export default function useGetAdmins() {
  return useQuery({
    queryKey: ["admin.list"],
    queryFn: getAdmins,
  });
}
