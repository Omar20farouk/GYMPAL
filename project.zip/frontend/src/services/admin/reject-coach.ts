import { useMutation, useQueryClient } from "@tanstack/react-query";
import api from "../api";
import { useToast } from "@/hooks/use-toast";

async function rejectCoach(id: string) {
  const res = await api.patch(`/admin/coaches/${id}/reject`);
  return res.data;
}

export default function useRejectCoach() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const mutation = useMutation({
    mutationFn: rejectCoach,
    onSuccess: () => {
      toast({
        title: "Coach rejected",
      });
      queryClient.invalidateQueries({
        queryKey: ["admin.pending-coaches"],
      });
      queryClient.invalidateQueries({
        queryKey: ["admin.dashboard-stats"],
      });
      queryClient.invalidateQueries({
        queryKey: ["coach.list"],
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to reject coach. Please try again.",
        variant: "destructive",
      });
    },
  });

  return mutation.mutateAsync;
}
