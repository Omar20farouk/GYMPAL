import { useQuery } from "@tanstack/react-query";
import api from "../api";

export interface DashboardStats {
  totalUsers: number;
  pendingCoaches: number;
  reports: number;
  revenue: number;
  userGrowth: number;
  revenueGrowth: number;
}

async function getDashboardStats() {
  const res = await api.get<DashboardStats>("/admin/dashboard-stats");
  return res.data;
}

export default function useGetDashboardStats() {
  return useQuery({
    queryKey: ["admin.dashboard-stats"],
    queryFn: getDashboardStats,
  });
}
