import { useMutation, useQueryClient } from "@tanstack/react-query";
import api from "../api";
import { useToast } from "@/components/ui/use-toast";

type AdminPayload = {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
};

async function createAdmin(payload: AdminPayload) {
  const res = await api.post("/admin/admins", payload);
  return res.data;
}

export default function useCreateAdmin() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const mutation = useMutation({
    mutationFn: createAdmin,
    onSuccess: () => {
      toast({
        title: "Admin created successfully",
      });
      queryClient.invalidateQueries({
        queryKey: ["admin.list"],
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create Admin. Please try again.",
        variant: "destructive",
      });
    },
  });

  return mutation.mutateAsync;
}
