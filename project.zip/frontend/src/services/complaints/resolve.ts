import { useMutation, useQueryClient } from "@tanstack/react-query";
import api from "../api";
import { useToast } from "@/components/ui/use-toast";

async function resolveComplaint(id: string) {
  const res = await api.patch(`/complaints/${id}/resolve`);
  return res.data;
}

export default function useResolveComplaint() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const mutation = useMutation({
    mutationFn: resolveComplaint,
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Complaint has been resolved successfully.",
      });
      // Invalidate the complaints list query to refetch the updated data
      queryClient.invalidateQueries({ queryKey: ["complaint.list"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to resolve the complaint. Please try again.",
        variant: "destructive",
      });
    },
  });

  return mutation.mutateAsync;
}
