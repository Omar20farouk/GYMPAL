import { useMutation } from "@tanstack/react-query";
import api from "../api";
import { useToast } from "@/components/ui/use-toast";

type ComplaintPayload = {
  coachId: string;
  description: string;
  images?: string[];
};

async function createComplaint(payload: ComplaintPayload) {
  const res = await api.post("/complaints", payload);
  return res.data;
}

export default function useCreateComplaint() {
  const { toast } = useToast();

  const mutation = useMutation({
    mutationFn: createComplaint,
    onSuccess: () => {
      toast({
        title: "Complaint submitted successfully",
        description:
          "We will review your complaint and take appropriate action.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to submit complaint. Please try again.",
        variant: "destructive",
      });
    },
  });

  return mutation.mutateAsync;
}
