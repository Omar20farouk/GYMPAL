import { useQuery } from "@tanstack/react-query";
import api from "../api";
import { Complaint } from "@/types/complaint";

async function getComplaints() {
  const res = await api.get<Complaint[]>(`/complaints`);
  return res.data;
}

export default function useGetComplaints() {
  return useQuery({
    queryKey: ["complaint.list"],
    queryFn: getComplaints,
  });
}
