import { useQuery } from "@tanstack/react-query";
import api from "../api";
import { Complaint } from "@/types/complaint";

async function getClientComplaints() {
  const res = await api.get<Complaint[]>(`/complaints/my-complaints`);
  return res.data;
}

export default function useGetClientComplaints() {
  return useQuery({
    queryKey: ["complaint.client"],
    queryFn: getClientComplaints,
  });
}
