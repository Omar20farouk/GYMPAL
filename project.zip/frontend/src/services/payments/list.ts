import { useQuery } from "@tanstack/react-query";
import api from "../api";

async function getPayments() {
  const res = await api.get("/payments");
  return res.data;
}

export function useGetPayments() {
  return useQuery({
    queryKey: ["payments.list"],
    queryFn: getPayments,
  });
}
