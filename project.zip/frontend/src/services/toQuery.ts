// make a function that takes a query object and returns a query string, ignore if the value is undefined or null

export const toQuery = (
  query: Record<string, string | number | (string | number)[] | null>
) => {
  const queryString = Object.entries(query)
    .map(([key, value]) => {
      if (value === undefined || value === null) return "";
      if (Array.isArray(value)) {
        return value.map((item) => `${key}=${item}`).join("&");
      }
      return `${key}=${value}`;
    })
    .filter(Boolean)
    .join("&");
  return queryString;
};
