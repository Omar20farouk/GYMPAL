import { useQuery } from "@tanstack/react-query";
import api from "../api";
import { Qualification } from "@/types/qualification";

async function getQualifications() {
  const res = await api.get<Qualification[]>("/qualifications");
  return res.data;
}

export default function useGetQualifications() {
  return useQuery({
    queryKey: ["qualifications"],
    queryFn: getQualifications,
  });
}
