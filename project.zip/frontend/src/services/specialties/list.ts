import { useQuery } from "@tanstack/react-query";
import api from "../api";
import { Specialty } from "@/types/specialty";

async function getSpecialties() {
  const res = await api.get<Specialty[]>("/specialties");
  return res.data;
}

export default function useGetSpecialties() {
  return useQuery({
    queryKey: ["specialties"],
    queryFn: getSpecialties,
  });
}
