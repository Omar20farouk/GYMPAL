import { useQuery } from "@tanstack/react-query";
import api from "../api";
import { Client } from "@/types/client";

async function getClients() {
  const res = await api.get<Client[]>("/clients");
  return res.data;
}

export default function useGetClients() {
  return useQuery({
    queryKey: ["client.list"],
    queryFn: getClients,
  });
}
