import { io, Socket } from "socket.io-client";
import { getAuthStorage } from "@/lib/auth";

class ChatSocketService {
  private socket: Socket | null = null;
  private userId: string | null = null;
  private userType: "CLIENT" | "COACH" | null = null;

  connect(): Promise<boolean> {
    return new Promise((resolve) => {
      try {
        const auth = getAuthStorage();
        if (!auth || !auth.token) {
          resolve(false);
          return;
        }

        this.userId = auth.user.id;
        this.userType = auth.user.role === "CLIENT" ? "CLIENT" : "COACH";

        // Set up the socket connection
        this.socket = io("http://localhost:3001", {
          auth: {
            token: auth.token,
            userId: this.userId,
            userType: this.userType,
          },
        });

        this.socket.on("connect", () => {
          console.log("Socket connected");
          resolve(true);
        });

        this.socket.on("connect_error", (err) => {
          console.error("Socket connection error:", err);
          resolve(false);
        });
      } catch (error) {
        console.error("Error connecting to socket:", error);
        resolve(false);
      }
    });
  }

  disconnect() {
    if (this.socket) {
      this.socket.disconnect();
      this.socket = null;
    }
  }

  isConnected(): boolean {
    return this.socket !== null && this.socket.connected;
  }

  sendMessage(data: { receiverId: string; content: string }): Promise<any> {
    if (!this.userId || !this.userType) {
      return Promise.reject(new Error("Not authenticated"));
    }

    return this.emitWithAck("sendMessage", {
      senderId: this.userId,
      senderType: this.userType,
      receiverId: data.receiverId,
      content: data.content,
    });
  }

  getConversation(chatId: string): Promise<any> {
    return this.emitWithAck("getConversation", { chatId });
  }

  getClientConversations(): Promise<any> {
    return this.emitWithAck("getClientConversations", {
      clientId: this.userId,
    });
  }

  getCoachConversations(): Promise<any> {
    return this.emitWithAck("getCoachConversations", { coachId: this.userId });
  }

  markAsRead(messageIds: string[]): Promise<any> {
    return this.emitWithAck("markAsRead", { messageIds });
  }

  sendTypingStatus(receiverId: string, isTyping: boolean): void {
    if (this.socket) {
      this.socket.emit("userTyping", {
        senderId: this.userId,
        receiverId,
        isTyping,
      });
    }
  }

  onNewMessage(callback: (message: any) => void) {
    if (this.socket) {
      this.socket.on("receiveMessage", callback);
    }
    return () => {
      if (this.socket) {
        this.socket.off("receiveMessage", callback);
      }
    };
  }

  onTypingStatus(
    callback: (data: { userId: string; isTyping: boolean }) => void
  ) {
    if (this.socket) {
      this.socket.on("userTypingUpdate", callback);
    }
    return () => {
      if (this.socket) {
        this.socket.off("userTypingUpdate", callback);
      }
    };
  }

  private emitWithAck(event: string, data: any): Promise<any> {
    return new Promise((resolve, reject) => {
      if (!this.socket) {
        reject(new Error("Socket not connected"));
        return;
      }

      this.socket.emit(event, data, (response: any) => {
        if (response?.success) {
          resolve(response);
        } else {
          reject(new Error(response?.error || "Unknown error"));
        }
      });
    });
  }
}

// Create a singleton instance
export const chatSocketService = new ChatSocketService();
