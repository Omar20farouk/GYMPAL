import { useQuery } from "@tanstack/react-query";
import api from "../api";

export interface ClientGrowth {
  count: number;
  growth: number;
}

export interface RecentClient {
  id: string;
  name: string;
  initials: string;
  planName: string;
  startDate: Date;
}

export interface RecentMessage {
  id: string;
  clientId: string;
  clientName: string;
  content: string;
  sentAt: Date;
}

export interface CoachDashboardStats {
  totalClients: number;
  activePlans: number;
  monthlyEarnings: number;
  earningsGrowth: number;
  recentClients: RecentClient[];
  recentMessages: RecentMessage[];
}

async function getCoachDashboardStats() {
  const res = await api.get<CoachDashboardStats>("/coaches/dashboard-stats");
  return res.data;
}

export default function useGetCoachDashboardStats() {
  return useQuery({
    queryKey: ["coach.dashboard-stats"],
    queryFn: getCoachDashboardStats,
  });
}
