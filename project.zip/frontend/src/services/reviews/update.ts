import { useMutation, useQueryClient } from "@tanstack/react-query";
import api from "../api";
import { useToast } from "@/hooks/use-toast";

type UpdateReviewPayload = {
  id: string;
  rating?: number;
  comment?: string;
};

async function updateReview(payload: UpdateReviewPayload) {
  const res = await api.patch(`/reviews/${payload.id}`, payload);
  return res.data;
}

export default function useUpdateReview() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const mutation = useMutation({
    mutationFn: updateReview,
    onSuccess: async () => {
      await queryClient.invalidateQueries({
        queryKey: ["coach"],
      });
      toast({
        title: "Review updated successfully",
      });
    },
  });

  return mutation.mutateAsync;
}
