import { useMutation, useQueryClient } from "@tanstack/react-query";
import api from "../api";
import { useToast } from "@/hooks/use-toast";

async function deleteReview(id: string) {
  const res = await api.delete(`/reviews/${id}`);
  return res.data;
}

export default function useDeleteReview() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const mutation = useMutation({
    mutationFn: deleteReview,

    onSuccess: async () => {
      await queryClient.invalidateQueries({
        queryKey: ["coach"],
      });
      toast({
        title: "Review deleted successfully",
      });
    },
  });

  return mutation.mutateAsync;
}
