import { useMutation, useQueryClient } from "@tanstack/react-query";
import api from "../api";
import { useToast } from "@/hooks/use-toast";

type ReviewPayload = {
  coachId: string;
  rating: number;
  comment?: string;
};

async function createReview(payload: ReviewPayload) {
  const res = await api.post(`/coaches/${payload.coachId}/reviews`, payload);
  return res.data;
}

export default function useCreateReview() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const mutation = useMutation({
    mutationFn: createReview,
    onSuccess: async (_, { coachId }) => {
      await queryClient.invalidateQueries({
        queryKey: ["coach", coachId],
      });
      toast({
        title: "Review submitted successfully",
      });
    },
  });

  return mutation.mutateAsync;
}
