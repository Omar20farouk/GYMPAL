import api from "./api";

export interface CreatePaymentSessionParams {
  planId: string;
}

export interface PaymentIntent {
  id: string;
  clientSecret: string;
  amount: number;
  currency: string;
  status: string;
}

/**
 * Create a payment intent for Stripe checkout
 * This will be used to initialize the payment process
 */
export const createPaymentIntent = async (
  params: CreatePaymentSessionParams
): Promise<PaymentIntent> => {
  const response = await api.post("/payments/create-payment-intent", params);
  return response.data;
};

/**
 * Confirm a successful payment
 * This will be called after a successful Stripe payment
 */
export const confirmPayment = async (paymentIntentId: string) => {
  const response = await api.post("/payments/confirm", { paymentIntentId });
  return response.data;
};

/**
 * Get payment status
 * Check the status of a payment
 */
export const getPaymentStatus = async (paymentIntentId: string) => {
  const response = await api.get(`/payments/status/${paymentIntentId}`);
  return response.data;
};

/**
 * Get client's payment history
 */
export const getClientPaymentHistory = async (clientId: number) => {
  const response = await api.get(`/clients/${clientId}/payments`);
  return response.data;
};
