import { useMutation, useQueryClient } from "@tanstack/react-query";
import api from "../api";
import { UpdateTeamMemberParams, TeamMember } from "@/types/team";
import { useToast } from "@/components/ui/use-toast";

async function updateTeamMember(params: {
  teamId: string;
  memberId: string;
  data: UpdateTeamMemberParams;
}) {
  const res = await api.put<TeamMember>(
    `/teams/${params.teamId}/members/${params.memberId}`,
    params.data
  );
  return res.data;
}

export function useUpdateTeamMember() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: updateTeamMember,
    onSuccess: (data) => {
      queryClient.invalidateQueries({
        queryKey: ["team-members", data.teamId],
      });
      queryClient.invalidateQueries({ queryKey: ["teams", data.teamId] });
      toast({
        title: "Success",
        description: "Team member updated successfully!",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update team member. Please try again.",
        variant: "destructive",
      });
    },
  });
}
