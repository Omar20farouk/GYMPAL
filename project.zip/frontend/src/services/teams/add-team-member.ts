import { useMutation, useQueryClient } from "@tanstack/react-query";
import api from "../api";
import { AddTeamMemberParams, TeamMember } from "@/types/team";
import { useToast } from "@/components/ui/use-toast";

async function addTeamMember(params: {
  teamId: string;
  data: AddTeamMemberParams;
}) {
  const res = await api.post<TeamMember>(
    `/teams/${params.teamId}/members`,
    params.data
  );
  return res.data;
}

export function useAddTeamMember() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: addTeamMember,
    onSuccess: (data) => {
      queryClient.invalidateQueries({
        queryKey: ["team-members", data.teamId],
      });
      queryClient.invalidateQueries({ queryKey: ["teams", data.teamId] });
      toast({
        title: "Success",
        description: "Team member added successfully!",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to add team member. Please try again.",
        variant: "destructive",
      });
    },
  });
}
