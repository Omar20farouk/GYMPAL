import { useMutation, useQueryClient } from "@tanstack/react-query";
import api from "../api";
import { TeamMember } from "@/types/team";
import { useToast } from "@/components/ui/use-toast";

export interface CreateTeamMemberParams {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  role?: string;
  position?: string;
}

async function createTeamMember(params: {
  teamId: string;
  data: CreateTeamMemberParams;
}) {
  const res = await api.post<TeamMember>(
    `/teams/${params.teamId}/members/create`,
    params.data
  );
  return res.data;
}

export function useCreateTeamMember() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: createTeamMember,
    onSuccess: async () => {
      await queryClient.invalidateQueries({
        queryKey: ["coach-team"],
      });
      toast({
        title: "Success",
        description: "Team member created successfully!",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create team member. Please try again.",
        variant: "destructive",
      });
    },
  });
}
