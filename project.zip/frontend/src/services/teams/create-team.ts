import { useMutation, useQueryClient } from "@tanstack/react-query";
import api from "../api";
import { CreateTeamParams, Team } from "@/types/team";
import { useToast } from "@/components/ui/use-toast";

async function createTeam(params: CreateTeamParams) {
  const res = await api.post<Team>("/teams", params);
  return res.data;
}

export function useCreateTeam() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: createTeam,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["teams"] });
      queryClient.invalidateQueries({ queryKey: ["coach-team"] });
      toast({
        title: "Success",
        description: "Team created successfully!",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create team. Please try again.",
        variant: "destructive",
      });
    },
  });
}
