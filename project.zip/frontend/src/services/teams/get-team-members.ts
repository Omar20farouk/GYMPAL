import { useQuery } from "@tanstack/react-query";
import api from "../api";
import { TeamMember } from "@/types/team";

async function getTeamMembers(teamId: string) {
  const res = await api.get<TeamMember[]>(`/teams/${teamId}/members`);
  return res.data;
}

export function useGetTeamMembers(teamId: string) {
  return useQuery({
    queryKey: ["team-members", teamId],
    queryFn: () => getTeamMembers(teamId),
    enabled: !!teamId,
  });
}
