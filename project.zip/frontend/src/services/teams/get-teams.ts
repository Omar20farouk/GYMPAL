import { useQuery } from "@tanstack/react-query";
import api from "../api";
import { Team } from "@/types/team";

async function getTeams() {
  const res = await api.get<Team[]>("/teams");
  return res.data;
}

export function useGetTeams() {
  return useQuery({
    queryKey: ["teams"],
    queryFn: getTeams,
  });
}

async function getCoachTeam() {
  const res = await api.get<Team[]>("/teams/coach");
  return res.data;
}

export function useGetCoachTeam() {
  return useQuery({
    queryKey: ["coach-team"],
    queryFn: getCoachTeam,
  });
}

async function getTeam(id: string) {
  const res = await api.get<Team>(`/teams/${id}`);
  return res.data;
}

export function useGetTeam(id: string) {
  return useQuery({
    queryKey: ["teams", id],
    queryFn: () => getTeam(id),
    enabled: !!id,
  });
}
