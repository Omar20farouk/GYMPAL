import { useMutation, useQueryClient } from "@tanstack/react-query";
import api from "../api";
import { useToast } from "@/components/ui/use-toast";

async function removeTeamMember(params: { teamId: string; memberId: string }) {
  const res = await api.delete(
    `/teams/${params.teamId}/members/${params.memberId}`
  );
  return { ...res.data, teamId: params.teamId };
}

export function useRemoveTeamMember() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: removeTeamMember,
    onSuccess: async (data) => {
      await queryClient.invalidateQueries({
        queryKey: ["coach-team"],
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to remove team member. Please try again.",
        variant: "destructive",
      });
    },
  });
}
