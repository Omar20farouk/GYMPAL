import { useMutation, useQueryClient } from "@tanstack/react-query";
import api from "../api";
import { UpdateTeamParams, Team } from "@/types/team";
import { useToast } from "@/components/ui/use-toast";

async function updateTeam(params: { id: string; data: UpdateTeamParams }) {
  const res = await api.put<Team>(`/teams/${params.id}`, params.data);
  return res.data;
}

export function useUpdateTeam() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: updateTeam,
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["teams"] });
      queryClient.invalidateQueries({ queryKey: ["coach-team"] });
      queryClient.invalidateQueries({ queryKey: ["teams", data.id] });
      toast({
        title: "Success",
        description: "Team updated successfully!",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update team. Please try again.",
        variant: "destructive",
      });
    },
  });
}
