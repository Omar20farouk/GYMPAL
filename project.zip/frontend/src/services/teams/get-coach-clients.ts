import { useQuery } from "@tanstack/react-query";
import api from "../api";
import { ClientWithSubscription } from "../coaches/clients";

// This service allows team members to access a coach's clients
async function getCoachClientsByTeam(teamId: string) {
  const res = await api.get<ClientWithSubscription[]>(
    `/teams/${teamId}/clients`
  );
  return res.data;
}

export function useGetCoachClientsByTeam(teamId: string) {
  return useQuery({
    queryKey: ["team.clients", teamId],
    queryFn: () => getCoachClientsByTeam(teamId),
    enabled: !!teamId,
  });
}
