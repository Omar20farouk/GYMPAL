import { useMutation } from "@tanstack/react-query";
import api from "../api";
import { useToast } from "@/hooks/use-toast";
import { useAuthStore } from "@/store/authStore";
import { UserRole } from "@/types/user";

type SignUpPayload = {
  firstName: string;
  lastName: string;
  email: string;
  city: string;
  password: string;
  confirmPassword: string;
  role: UserRole;
  experience?: number;
  qualifications?: string[];
  specialties?: string[];
};

async function signUp(payload: SignUpPayload) {
  const res = await api.post(`/auth/signup`, payload);
  return res.data;
}

export default function useSignUp() {
  const { toast } = useToast();
  const { setUser } = useAuthStore();

  const mutation = useMutation({
    mutationFn: signUp,
    onSuccess: (data) => {
      setUser(data);

      toast({
        title: "Account created successfully",
        description:
          data.role === "COACH"
            ? "Your coach profile is now under review. We'll notify you when it's approved."
            : "Welcome to GYMPAL!",
      });
    },
  });

  return mutation.mutateAsync;
}
