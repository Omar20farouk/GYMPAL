import { useMutation } from "@tanstack/react-query";
import api from "../api";
import { useAuthStore } from "@/store/authStore";

type LoginPayload = {
  email: string;
  password: string;
};

async function login(payload: LoginPayload) {
  const res = await api.post(`/auth/login`, payload);
  return res.data;
}

export default function useLogin() {
  const { setUser } = useAuthStore();

  const mutation = useMutation({
    mutationFn: login,
    onSuccess: (data) => {
      setUser(data);
    },
  });

  return mutation.mutateAsync;
}
