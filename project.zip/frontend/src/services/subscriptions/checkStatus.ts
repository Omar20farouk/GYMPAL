import { useQuery } from "@tanstack/react-query";
import api from "../api";

async function checkSubscriptionStatus(coachId: string) {
  const res = await api.get(`/subscriptions/check-status/${coachId}`);
  return res.data.hasActiveSubscription;
}

export default function useCheckSubscriptionStatus(coachId: string) {
  return useQuery({
    queryKey: ["subscription.status", coachId],
    queryFn: () => checkSubscriptionStatus(coachId),
    enabled: !!coachId, // Only run the query if coachId is provided
  });
}
