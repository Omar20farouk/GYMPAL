import { useMutation } from "@tanstack/react-query";
import api from "../api";
import { useToast } from "@/components/ui/use-toast";

type UploadImageResponse = {
  url: string;
  originalname: string;
  mimetype: string;
  size: number;
};

/**
 * Uploads an image file to the server
 * @param file The image file to upload
 * @returns The URL of the uploaded image
 * @throws Error if the upload fails
 */
async function uploadImage(file: File): Promise<string> {
  // Validate file size (5MB max)
  if (file.size > 5 * 1024 * 1024) {
    throw new Error("File size exceeds 5MB limit");
  }

  // Validate file type
  if (!file.type.match(/^image\/(jpeg|jpg|png|gif)$/)) {
    throw new Error("Only JPEG, PNG, and GIF images are allowed");
  }

  // Create a form data object to send the image
  const formData = new FormData();
  formData.append("file", file);

  try {
    // Upload the image
    const response = await api.post<UploadImageResponse>(
      "/uploads/image",
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      }
    );

    // Return the URL of the uploaded image
    return response.data.url;
  } catch (error: unknown) {
    console.error("Error uploading image:", error);

    const axiosError = error as {
      response?: { status?: number; data?: { message?: string } };
    };

    if (axiosError.response?.status === 401) {
      throw new Error("Authentication error: Please log in again");
    } else if (axiosError.response?.status === 413) {
      throw new Error("File too large: Maximum file size is 5MB");
    } else if (axiosError.response?.data?.message) {
      throw new Error(`Upload failed: ${axiosError.response.data.message}`);
    } else {
      throw new Error("Failed to upload image. Please try again.");
    }
  }
}

/**
 * Hook for uploading images to the server
 * Returns a function that uploads an image and returns its URL
 */
export default function useUploadImage() {
  const { toast } = useToast();

  const mutation = useMutation({
    mutationFn: uploadImage,
    onError: (error: Error) => {
      toast({
        title: "Upload Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return mutation.mutateAsync;
}
