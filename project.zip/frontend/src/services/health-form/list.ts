import { useQuery } from "@tanstack/react-query";
import api from "../api";

const getAllHealthForms = async (clientId: string) => {
  const response = await api.get(`/clients/${clientId}/health-forms`);
  return response.data;
};

export default function useGetClientHealthForms(clientId: string) {
  return useQuery({
    queryKey: ["health-forms.list", clientId],
    queryFn: () => getAllHealthForms(clientId),
    enabled: !!clientId,
  });
}
