import { useSubmit } from "react-router-dom";
import api from "../api";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

export interface HealthFormData {
  height: string;
  weight: string;
  chronicDiseases?: string;
  hasDisability: boolean;
  disabilityDetails?: string;
  favoriteFood?: string;
  fitnessGoal: string;
  planId: string;
}

async function submitHealthForm(formData: HealthFormData) {
  const response = await api.post("/clients/health-form", formData);
  return response.data;
}

export default function useSubmitHealthForm() {
  const { toast } = useToast();

  const mutation = useMutation({
    mutationFn: submitHealthForm,
    onSuccess: () => {
      toast({
        title: "Health form submitted",
        description: "Your health form has been submitted successfully.",
      });
    },
  });

  return mutation.mutateAsync;
}
