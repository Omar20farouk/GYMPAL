export type Specialty = {
  id: string;
  name: string;
};
