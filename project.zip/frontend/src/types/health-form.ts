export enum FitnessGoal {
  GENERAL_HEALTH = "GENERAL_HEALTH",
  WEIGHT_LOSS = "WEIGHT_LOSS",
  MUSCLE_GAIN = "MUSCLE_GAIN",
  ENDURANCE = "ENDURANCE",
  FLEXIBILITY = "FLEXIBILITY",
}

export interface HealthForm {
  id: string;
  height: string;
  weight: string;
  chronicDiseases: string | null;
  hasDisability: boolean;
  disabilityDetails: string | null;
  favoriteFood: string | null;
  fitnessGoal: FitnessGoal;
  clientId: string;
  planId: string;
  plan?: {
    id: string;
    name: string;
  };
  createdAt: string | Date;
  updatedAt: string | Date;
}
