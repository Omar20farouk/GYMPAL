import { Client } from "./client";
import { Coach } from "./coach";

export enum ComplaintStatus {
  PENDING = "PENDING",
  RESOLVED = "RESOLVED",
}

export type Complaint = {
  id: string;
  clientId: string;
  client: Client;
  coachId: string;
  coach: Coach;
  description: string;
  images?: string[]; // Array of image URLs
  status: ComplaintStatus;
  createdAt: Date;
  updatedAt: Date;
};
