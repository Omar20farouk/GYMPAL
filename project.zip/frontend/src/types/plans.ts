import { Coach } from "./coach";

export type Plan = {
  id: string;
  coachId: string;
  coach: Coach;
  name: string;
  price: number;
  duration: number;
  durationUnit: "day" | "week" | "month";
  description: string;
  features: string[];
  createdAt: Date;
  updatedAt: Date;
};
