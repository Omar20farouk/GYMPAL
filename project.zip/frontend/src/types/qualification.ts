export type Qualification = {
  id: string;
  name: string;
};
