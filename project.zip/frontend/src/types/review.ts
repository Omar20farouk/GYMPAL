import { Client } from "./client";
import { Coach } from "./coach";

export type Review = {
  id: string;
  coachId: string;
  coach: Coach;
  clientId: string;
  client: Client;
  rating: number;
  comment?: string;
  createdAt: Date;
  updatedAt: Date;
};
