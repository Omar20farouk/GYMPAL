import { Client } from "./client";
import { Coach } from "./coach";

export type UserRole = "CLIENT" | "COACH" | "ADMIN" | "TEAM_MEMBER";

export type User = {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  password: string;
  city: string;
  role: UserRole;
  coach: Coach | null;
  client: Client | null;
  teamMember?: {
    id: string;
    teamId: string;
    position?: string;
    role?: string;
  } | null;
  createdAt: Date;
  updatedAt: Date;
};
