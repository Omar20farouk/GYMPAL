import { User } from "./user";

export enum TeamMemberRole {
  MEMBER = "MEMBER",
  ADMIN = "ADMIN",
}

export interface TeamMember {
  id: string;
  teamId: string;
  userId: string;
  user: User;
  role: TeamMemberRole;
  position?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Team {
  id: string;
  name: string;
  description?: string;
  coachId: string;
  coach: {
    id: string;
    userId: string;
    user: User;
  };
  members?: TeamMember[];
  createdAt: string;
  updatedAt: string;
}

export interface CreateTeamParams {
  name: string;
  description?: string;
}

export interface UpdateTeamParams {
  name?: string;
  description?: string;
}

export interface AddTeamMemberParams {
  userId: string;
  role?: TeamMemberRole;
  position?: string;
}

export interface UpdateTeamMemberParams {
  role?: TeamMemberRole;
  position?: string;
}
