import { Client } from "./client";
import { Coach } from "./coach";
import { Plan } from "./plans";

export enum PaymentStatus {
  PENDING = "pending",
  SUCCEEDED = "succeeded",
  FAILED = "failed",
  REFUNDED = "refunded",
  CANCELED = "canceled",
}

export type Payment = {
  id: string;
  clientId: string;
  client: Client;
  coachId: string;
  coach: Coach;
  planId: string;
  plan: Plan;
  amount: number;
  description: string;
  paymentIntentId: string;
  status: PaymentStatus;
  createdAt: Date;
  updatedAt: Date;
};
