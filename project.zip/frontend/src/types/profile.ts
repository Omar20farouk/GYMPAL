// This file creates success and warning variants for the Badge component in the client-side DTO

export type UpdateClientProfileFormValues = {
  firstName: string;
  lastName: string;
  city: string;
};
