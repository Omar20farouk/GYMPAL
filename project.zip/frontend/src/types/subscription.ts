import { Client } from "./client";
import { Plan } from "./plans";

export type Subscription = {
  id: string;
  clientId: string;
  client: Client;
  planId: string;
  plan: Plan;
  startDate: Date;
  endDate: Date;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
};
