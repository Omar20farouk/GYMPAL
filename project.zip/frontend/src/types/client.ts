import { Complaint } from "./complaint";
import { User } from "./user";

export type Client = {
  id: string;
  userId: string;
  user: User;
  complaints: Complaint[];
};
