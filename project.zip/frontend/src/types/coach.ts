import { Plan } from "./plans";
import { Qualification } from "./qualification";
import { Review } from "./review";
import { Specialty } from "./specialty";
import { User } from "./user";

export type Coach = {
  id: string;
  userId: string;
  user: User;
  reviews: Review[];
  averageRating: number;
  plans: Plan[];
  about?: string;
  qualifications?: Qualification[];
  specialties: Specialty[];
  balance: number;
  experience: number;
  status: "PENDING" | "APPROVED" | "REJECTED";
  profilePicture?: string;
  coverPicture?: string;
};
