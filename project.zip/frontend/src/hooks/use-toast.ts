import { ExternalToast, toast as sonnerToast } from "sonner";

type ToastProps = {
  title: string;
  description?: string;
  variant?: "default" | "destructive" | "warning" | "info";
};

const toastStyles: { [key: string]: ExternalToast } = {
  default: {
    style: {
      backgroundColor: "#ffffff",
      border: "1px solid #E5E7EB",
      color: "#111827",
      borderRadius: "0.5rem",
      boxShadow:
        "0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)",
    },
    icon: "✨",
    duration: 4000,
    cancelButtonStyle: {
      backgroundColor: "red",
    },
  },
  success: {
    style: {
      backgroundColor: "#ECFDF5",
      border: "1px solid #6EE7B7",
      color: "#065F46",
      borderRadius: "0.5rem",
      boxShadow:
        "0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)",
    },
    icon: "✅",
    duration: 4000,
    cancelButtonStyle: {
      backgroundColor: "red",
    },
  },
  error: {
    style: {
      backgroundColor: "#FEF2F2",
      border: "1px solid #FCA5A5",
      color: "#991B1B",
      borderRadius: "0.5rem",
      boxShadow:
        "0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)",
    },
    icon: "❌",
    duration: 4000,
    cancelButtonStyle: {
      backgroundColor: "red",
    },
  },
  warning: {
    style: {
      backgroundColor: "#FFFBEB",
      border: "1px solid #FCD34D",
      color: "#92400E",
      borderRadius: "0.5rem",
      boxShadow:
        "0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)",
    },
    icon: "⚠️",
    duration: 4000,
    actionButtonStyle: {
      backgroundColor: "red",
    },
    cancelButtonStyle: {
      color: "green !important",
    },
  },
  info: {
    style: {
      backgroundColor: "#EFF6FF",
      border: "1px solid #93C5FD",
      color: "#1E40AF",
      borderRadius: "0.5rem",
      boxShadow:
        "0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)",
    },
    icon: "ℹ️",
    duration: 4000,
    cancelButtonStyle: {
      backgroundColor: "red",
    },
  },
};

export function useToast() {
  const toast = ({ title, description, variant = "default" }: ToastProps) => {
    const style =
      variant === "destructive"
        ? toastStyles.error
        : toastStyles[variant as keyof typeof toastStyles];
    sonnerToast(title, {
      description,
      ...style,
    });
  };

  return { toast };
}
