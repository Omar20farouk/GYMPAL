import { useAuthStore } from "@/store/authStore";

export const getAuthStorage = () => {
  // Access localStorage directly for server-side operations like socket connection
  try {
    const authData = localStorage.getItem("auth-storage");
    if (authData) {
      return JSON.parse(authData).state;
    }
  } catch (error) {
    console.error("Error getting auth data from storage:", error);
  }

  return null;
};

export const getToken = (): string | null => {
  const authState = useAuthStore.getState();
  return authState.token;
};

export const getUser = () => {
  const authState = useAuthStore.getState();
  return authState.user;
};

export const getUserId = (): string | null => {
  const user = getUser();
  return user?.id || null;
};

export const getUserRole = (): string | null => {
  const user = getUser();
  return user?.role || null;
};

export const isAuthenticated = (): boolean => {
  return !!getToken();
};

export const isClient = (): boolean => {
  return getUserRole() === "CLIENT";
};

export const isCoach = (): boolean => {
  return getUserRole() === "COACH";
};

export const isAdmin = (): boolean => {
  return getUserRole() === "ADMIN";
};
