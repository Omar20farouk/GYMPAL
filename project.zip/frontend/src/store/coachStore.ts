import { Coach } from "@/types/coach";
import { Plan } from "@/types/plans";
import { create } from "zustand";

type CoachState = {
  selectedCoach: Coach | null;
  selectedPlan: Plan | null;
  setSelectedCoach: (coach: Coach | null) => void;
  setSelectedPlan: (plan: Plan | null) => void;
};

export const useCoachStore = create<CoachState>((set, get) => ({
  selectedCoach: null,
  selectedPlan: null,

  setSelectedCoach: (coach) => {
    set({ selectedCoach: coach });
  },

  setSelectedPlan: (plan) => {
    set({ selectedPlan: plan });
  },
}));
