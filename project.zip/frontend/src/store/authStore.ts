import { User } from "@/types/user";
import { create } from "zustand";
import { persist } from "zustand/middleware";

type AuthState = {
  user: User | null;
  token: string | null;
  logout: () => void;
  setUser: (user: User & { token: string }) => void;
};

const initialState: Pick<AuthState, "user" | "token"> = {
  user: null,
  token: null,
};

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      ...initialState,
      logout: () => {
        set({ user: null, token: null });
      },
      setUser: (user) => {
        set({ user, token: user.token });
      },
    }),
    {
      name: "auth-storage",
    }
  )
);
