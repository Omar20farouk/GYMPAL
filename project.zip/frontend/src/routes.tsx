import { createBrowserRouter } from "react-router-dom";

// Pages
import LandingPage from "./pages/LandingPage";
import RoleSelection from "./pages/auth/RoleSelection";
import LoginPage from "./pages/auth/LoginPage";
import SignupPage from "./pages/auth/SignupPage";
import ClientDashboard from "./pages/client/ClientDashboard";
import CoachDetails from "./pages/client/CoachDetails";
import HealthForm from "./pages/client/HealthForm";
import Payment from "./pages/client/Payment";
import PaymentSuccess from "./pages/client/PaymentSuccess";
import ClientChat from "./pages/client/Chat";
import ClientProfile from "./pages/client/Profile";
import ComplaintForm from "./pages/client/ComplaintForm";
import CoachDashboard from "./pages/coach/Dashboard";
import CoachChat from "./pages/coach/Chat";
import CoachProfile from "./pages/coach/Profile";
import CoachEarnings from "./pages/coach/Earnings";
import CoachClients from "./pages/coach/Clients";
import ClientHealthForm from "./pages/coach/Clients/ClientHealthForm";
import AdminDashboard from "./pages/admin/AdminDashboard";
import NotFound from "./pages/NotFound";
import Plans from "./pages/coach/Plans";
import CoachesApproval from "./pages/admin/Coaches";
import ClientsTable from "./pages/admin/Clients";
import ComplaintsTable from "./pages/admin/Complaints";
import Payments from "./pages/admin/Payments";
import Profile from "./pages/Profile";

import TeamManagement from "./pages/coach/TeamManagement";
import TeamDetails from "./pages/teams/TeamDetails";
import TeamMemberDashboard from "./pages/team-member/Dashboard";
import TeamMemberClients from "./pages/team-member/Clients";

// Layout components
import ClientLayout from "./components/layouts/ClientLayout";
import CoachLayout from "./components/layouts/CoachLayout";
import AdminLayout from "./components/layouts/AdminLayout";
import TeamMemberLayout from "./components/layouts/TeamMemberLayout";
import AuthGuard from "./components/layouts/AuthGuard";
import Layout from "./components/layouts/Layout";
import Dashboard from "./pages/Dashboard";
import AdminsTable from "./pages/admin/Admins";

export const createRoutes = () =>
  createBrowserRouter([
    {
      path: "/",
      element: <LandingPage />,
    },
    {
      path: "/role-select",
      element: <RoleSelection />,
    },
    {
      path: "/login",
      element: <LoginPage />,
    },
    {
      path: "/signup/:role",
      element: <SignupPage />,
    },
    {
      path: "/dashboard",
      element: (
        <AuthGuard allowedRoles={["CLIENT", "COACH", "ADMIN"]}>
          <Layout />
        </AuthGuard>
      ),
      children: [
        {
          path: "",
          element: <Dashboard />,
        },
      ],
    },
    {
      path: "/profile",
      element: (
        <AuthGuard allowedRoles={["CLIENT", "COACH", "ADMIN"]}>
          <Profile />
        </AuthGuard>
      ),
    },
    {
      path: "/client",
      element: (
        <AuthGuard allowedRoles={["CLIENT"]}>
          <ClientLayout />
        </AuthGuard>
      ),
      children: [
        {
          path: "dashboard",
          element: <ClientDashboard />,
        },
        {
          path: "coach/:id",
          element: <CoachDetails />,
        },
        {
          path: "health-form",
          element: <HealthForm />,
        },
        {
          path: "payment",
          element: <Payment />,
        },
        {
          path: "payment-success",
          element: <PaymentSuccess />,
        },
        {
          path: "chat",
          element: <ClientChat />,
        },
        {
          path: "chat/:coachId",
          element: <ClientChat />,
        },
        {
          path: "profile",
          element: <ClientProfile />,
        },
        {
          path: "complaint/:coachId",
          element: <ComplaintForm />,
        },
      ],
    },
    {
      path: "/coach",
      element: (
        <AuthGuard allowedRoles={["COACH"]}>
          <CoachLayout />
        </AuthGuard>
      ),
      children: [
        {
          path: "dashboard",
          element: <CoachDashboard />,
        },
        {
          path: "plans",
          element: <Plans />,
        },
        {
          path: "earnings",
          element: <CoachEarnings />,
        },
        {
          path: "clients",
          element: <CoachClients />,
        },
        {
          path: "clients/:clientId/health-form",
          element: <ClientHealthForm />,
        },
        {
          path: "chat",
          element: <CoachChat />,
        },
        {
          path: "chat/:clientId",
          element: <CoachChat />,
        },
        {
          path: "profile",
          element: <CoachProfile />,
        },
        {
          path: "team",
          element: <TeamManagement />,
        },
      ],
    },
    {
      path: "/admin",
      element: (
        <AuthGuard allowedRoles={["ADMIN"]}>
          <AdminLayout />
        </AuthGuard>
      ),
      children: [
        {
          path: "dashboard",
          element: <AdminDashboard />,
        },
        {
          path: "coaches",
          element: <CoachesApproval />,
        },
        {
          path: "clients",
          element: <ClientsTable />,
        },
        {
          path: "complaints",
          element: <ComplaintsTable />,
        },
        {
          path: "payments",
          element: <Payments />,
        },
        {
          path: "admins",
          element: <AdminsTable />,
        },
      ],
    },
    {
      path: "/teams/:teamId",
      element: (
        <AuthGuard allowedRoles={["CLIENT", "COACH", "ADMIN", "TEAM_MEMBER"]}>
          <TeamDetails />
        </AuthGuard>
      ),
    },
    {
      path: "/team-member",
      element: (
        <AuthGuard allowedRoles={["TEAM_MEMBER"]}>
          <TeamMemberLayout />
        </AuthGuard>
      ),
      children: [
        {
          path: "dashboard",
          element: <TeamMemberDashboard />,
        },
        {
          path: "clients",
          element: <TeamMemberClients />,
        },
        {
          path: "clients/:clientId/health-form",
          element: <ClientHealthForm />,
        },
      ],
    },
    {
      path: "*",
      element: <NotFound />,
    },
  ]);
