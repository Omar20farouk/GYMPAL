import { useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, CheckCircle } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import useGetCoachById from "@/services/coaches/get-by-id";
import { useCoachStore } from "@/store/coachStore";
import { useEffect } from "react";
import CoachReviews from "./components/reviews";
import CoachBundles from "./components/coach-bundles";
import Header from "./components/header";

const CoachDetails = () => {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const setSelectedCoach = useCoachStore((state) => state.setSelectedCoach);

  const { data: coach } = useGetCoachById(id!);

  useEffect(() => {
    if (coach) {
      setSelectedCoach(coach);
    }
  }, [coach]);

  if (!coach) {
    return (
      <div className="container mx-auto px-4 py-12 flex justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-gym-purple"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Back button */}
      <button
        onClick={() => navigate("/client/dashboard")}
        className="flex items-center text-gym-purple hover:text-gym-purple/80 mb-6"
      >
        <ArrowLeft className="w-5 h-5 mr-2" />
        Back to Coaches
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          {/* Coach profile header */}
          <Header coach={coach} />

          {/* Coach details tabs */}
          <Tabs
            defaultValue="about"
            className="bg-white rounded-lg shadow-md overflow-hidden"
          >
            <TabsList className="border-b p-0 w-full rounded-none">
              <TabsTrigger
                value="about"
                className="flex-1 rounded-none data-[state=active]:border-b-2 data-[state=active]:border-gym-purple"
              >
                About
              </TabsTrigger>
              <TabsTrigger
                value="qualifications"
                className="flex-1 rounded-none data-[state=active]:border-b-2 data-[state=active]:border-gym-purple"
              >
                Qualifications
              </TabsTrigger>
              <TabsTrigger
                value="reviews"
                className="flex-1 rounded-none data-[state=active]:border-b-2 data-[state=active]:border-gym-purple"
              >
                Reviews
              </TabsTrigger>
            </TabsList>

            <TabsContent value="about" className="p-6">
              <h2 className="text-xl font-semibold mb-4">About Me</h2>
              <p className="text-gray-700 whitespace-pre-line">{coach.about}</p>
            </TabsContent>

            <TabsContent value="qualifications" className="p-6">
              <h2 className="text-xl font-semibold mb-4">
                Qualifications & Certifications
              </h2>
              <ul className="space-y-3">
                {coach.qualifications?.map((qualification, index) => (
                  <li key={index} className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-gym-purple mr-2 mt-0.5 flex-shrink-0" />
                    <span>{qualification.name}</span>
                  </li>
                ))}
              </ul>
            </TabsContent>

            <TabsContent value="reviews" className="p-6">
              <CoachReviews reviews={coach.reviews} />
            </TabsContent>
          </Tabs>
        </div>

        {/* Bundles sidebar */}
        <CoachBundles plans={coach.plans} />
      </div>
    </div>
  );
};

export default CoachDetails;
