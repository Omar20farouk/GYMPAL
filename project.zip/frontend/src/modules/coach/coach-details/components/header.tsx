import ImageModal from "@/components/image-modal";
import { Badge } from "@/components/ui/badge";
import { Coach } from "@/types/coach";
import { Award, Mail, MapPin, Star, TriangleAlert } from "lucide-react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

type Props = {
  coach: Coach;
};

const Header: React.FC<Props> = ({ coach }) => {
  const [selectedImage, setSelectedImage] = useState<string | undefined | null>(
    null
  );
  const navigate = useNavigate();

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden mb-8">
      <div className="relative">
        {coach.coverPicture ? (
          <div
            className="relative group cursor-pointer"
            onClick={() => setSelectedImage(coach.coverPicture)}
          >
            <img
              src={coach.coverPicture}
              alt={`${coach.user.firstName} ${coach.user.lastName}`}
              className="w-full h-48 object-cover"
            />
            <div className="absolute inset-0 bg-black opacity-0 group-hover:opacity-50 transition-opacity duration-300"></div>
          </div>
        ) : (
          <div className="h-48 bg-gradient-to-r from-gym-purple/20 to-gym-blue/20"></div>
        )}

        <div className="absolute -bottom-16 left-8 w-32 h-32 rounded-full border-4 border-white overflow-hidden bg-gym-purple/10 flex items-center justify-center">
          {coach.profilePicture ? (
            <div
              className="relative group cursor-pointer h-full w-full"
              onClick={() => setSelectedImage(coach.profilePicture)}
            >
              <img
                src={coach.profilePicture}
                alt={`${coach.user.firstName} ${coach.user.lastName}`}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-black opacity-0 group-hover:opacity-50 transition-opacity duration-300"></div>
            </div>
          ) : (
            <span className="text-4xl font-bold text-gym-purple">
              {coach.user.firstName.charAt(0)}
            </span>
          )}
        </div>
      </div>

      <div className="pt-20 pb-6 px-8">
        <div className="flex flex-wrap justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold mb-1">
              {coach.user.firstName} {coach.user.lastName}
            </h1>
            <div className="flex items-center text-gray-600 mb-4">
              <MapPin className="w-4 h-4 mr-1" />
              {coach.user.city}
              <span className="mx-2">•</span>
              <Mail className="w-4 h-4 mr-1" />
              {coach.user.email}
            </div>

            <div className="flex flex-wrap gap-2 mb-4">
              {coach.specialties.map((specialty) => (
                <Badge key={specialty.id} variant="secondary">
                  {specialty.name}
                </Badge>
              ))}
            </div>
          </div>

          <div className="flex items-center bg-gym-purple/10 text-gym-purple py-2 px-3 rounded-md">
            <Star className="w-5 h-5 mr-1 fill-current" />
            <span className="font-medium text-lg">{coach.averageRating}</span>
          </div>
        </div>

        <div className="flex flex-wrap gap-4 mt-4">
          <div className="flex items-center">
            <Award className="w-5 h-5 text-gym-purple mr-2" />
            <span>{coach.experience} years experience</span>
          </div>
          {coach.qualifications?.length ? (
            <div className="flex items-center">
              <Award className="w-5 h-5 text-gym-purple mr-2" />
              <span>{coach.qualifications.length} certifications</span>
            </div>
          ) : null}
        </div>

        <div className="mt-6">
          <button
            onClick={() => navigate(`/client/complaint/${coach.id}`)}
            className="text-sm text-red-600 hover:text-red-800 flex items-center gap-2"
          >
            <TriangleAlert />
            File a Complaint
          </button>
        </div>
      </div>

      {selectedImage && (
        <ImageModal
          isOpen={!!selectedImage}
          onClose={() => setSelectedImage(null)}
          imageUrl={selectedImage}
        />
      )}
    </div>
  );
};

export default Header;
