import useDeleteReview from "@/services/reviews/delete";
import useUpdateReview from "@/services/reviews/update";
import { Review } from "@/types/review";
import { Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useMemo, useState } from "react";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import useCreateReview from "@/services/reviews/create";
import { useCoachStore } from "@/store/coachStore";
import { useAuthStore } from "@/store/authStore";

type Props = {
  reviews: Review[];
};

const CoachReviews: React.FC<Props> = ({ reviews }) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [rating, setRating] = useState<number | null>(null);
  const [comment, setComment] = useState<string>("");
  const [editingReviewId, setEditingReviewId] = useState<string | null>(null);
  const [editedComment, setEditedComment] = useState<string>("");
  const [editedRating, setEditedRating] = useState<number>(0);
  const selectedCoach = useCoachStore((state) => state.selectedCoach);
  const createReview = useCreateReview();
  const updateReview = useUpdateReview();
  const deleteReview = useDeleteReview();
  const user = useAuthStore((state) => state.user);

  const sortedReviews = useMemo(() => {
    if (!user?.client?.id) return reviews;

    return [...reviews].sort((a, b) => {
      if (a.client.id === user?.client?.id) return -1;
      if (b.client.id === user?.client?.id) return 1;
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
  }, [reviews, user?.client?.id]);

  const handleEdit = (
    reviewId: string,
    currentComment: string,
    currentRating: number
  ) => {
    setEditingReviewId(reviewId);
    setEditedComment(currentComment);
    setEditedRating(currentRating);
  };

  const handleCancelEdit = () => {
    setEditingReviewId(null);
    setEditedComment("");
    setEditedRating(0);
  };

  const handleSubmitEdit = async (reviewId: string) => {
    try {
      await updateReview({
        id: reviewId,
        comment: editedComment,
        rating: editedRating,
      });
      setEditingReviewId(null);
      setEditedComment("");
      setEditedRating(0);
    } catch (error) {
      console.error("Failed to update review", error);
    }
  };

  const handleAddReview = async () => {
    setIsSubmitting(true);

    if (!selectedCoach) {
      console.error("No coach selected");
      setIsSubmitting(false);
      return;
    }

    try {
      await createReview({
        coachId: selectedCoach.id,
        rating: rating ? rating : 0,
        comment,
      });
      setRating(null);
      setComment("");
    } catch (error) {
      console.error("Failed to add review", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div>
      <div className="mb-4 space-y-3">
        <h3 className="text-lg font-semibold mb-2">Add a Review</h3>
        <StarRating currentRating={rating} onRatingChange={setRating} />
        <Textarea
          placeholder="Write an optional comment..."
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          className="mb-2"
        />
        <div className="flex justify-end">
          <Button
            variant="default"
            onClick={handleAddReview}
            disabled={isSubmitting}
          >
            {isSubmitting ? "Submitting..." : "Submit Review"}
          </Button>
        </div>
      </div>

      <Separator className="my-6" />

      {sortedReviews.length > 0 ? (
        <ul className="space-y-4">
          {sortedReviews.map((review) => (
            <li key={review.id} className="border-b pb-4">
              <div className="flex items-center gap-2 mb-2">
                <div>
                  <span className="font-semibold mr-2">
                    {review.client.user.firstName} {review.client.user.lastName}
                  </span>
                  <span className="text-sm text-gray-500">
                    {new Date(review.createdAt).toLocaleDateString()}
                  </span>
                </div>
                <div className="flex items-center">
                  <Star className="w-5 h-5 text-gym-purple mr-1" />
                  <span className="font-semibold">{review.rating}</span>
                </div>
              </div>

              {editingReviewId === review.id ? (
                <div className="space-y-2">
                  <div className="mb-3">
                    <StarRating
                      currentRating={editedRating}
                      onRatingChange={setEditedRating}
                    />
                  </div>
                  <Textarea
                    value={editedComment}
                    onChange={(e) => setEditedComment(e.target.value)}
                    className="mb-2"
                  />
                  <div className="flex gap-2">
                    <Button
                      variant="default"
                      size="sm"
                      onClick={() => handleSubmitEdit(review.id)}
                    >
                      Submit
                    </Button>
                    <Button
                      variant="secondary"
                      size="sm"
                      onClick={handleCancelEdit}
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <>
                  <p className="text-gray-700">{review.comment}</p>
                  {review.client.id === user?.client?.id && (
                    <div className="flex gap-2 mt-2">
                      <Button
                        variant="secondary"
                        size="sm"
                        onClick={() =>
                          handleEdit(
                            review.id,
                            review.comment || "",
                            review.rating
                          )
                        }
                      >
                        Edit
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={async () => {
                          try {
                            await deleteReview(review.id);
                          } catch (error) {
                            console.error("Failed to delete review", error);
                          }
                        }}
                      >
                        Delete
                      </Button>
                    </div>
                  )}

                  {review.client.id === user?.client?.id && (
                    <div className="mt-1 text-xs text-gym-purple">
                      This is your review
                    </div>
                  )}
                </>
              )}
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-gray-500">No reviews yet.</p>
      )}
    </div>
  );
};

const StarRating = ({
  currentRating,
  onRatingChange,
  editable = true,
}: {
  currentRating: number | null;
  onRatingChange: (rating: number) => void;
  editable?: boolean;
}) => (
  <div className="flex items-center gap-2">
    {[1, 2, 3, 4, 5].map((star) => (
      <Star
        key={star}
        className={`w-6 h-6 ${editable ? "cursor-pointer" : ""} ${
          currentRating && currentRating >= star
            ? "text-gym-purple"
            : "text-gray-300"
        }`}
        onClick={() => editable && onRatingChange(star)}
      />
    ))}
  </div>
);

export default CoachReviews;
