import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useCoachStore } from "@/store/coachStore";
import { Plan } from "@/types/plans";
import { CheckCircle, Clock } from "lucide-react";
import { useNavigate } from "react-router-dom";

function CoachPlans({ plans }: { plans: Plan[] }) {
  const navigate = useNavigate();

  const { setSelectedPlan } = useCoachStore();

  const handleSelectPlan = (plan: Plan) => {
    setSelectedPlan(plan);
    navigate("/client/health-form");
  };

  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">Coaching Plans</h2>
      <div className="space-y-4">
        {plans.map((plan) => (
          <Card
            key={plan.id}
            className={`border ${
              plan.name.toLowerCase().includes("premium")
                ? "border-gym-purple/30 shadow-md"
                : "border-gray-200"
            }`}
          >
            {plan.name.toLowerCase().includes("premium") && (
              <div className="bg-gym-purple text-white py-1 text-center text-sm font-medium">
                Most Popular
              </div>
            )}

            <CardHeader>
              <CardTitle>{plan.name}</CardTitle>
              <div className="flex items-center text-sm text-gray-500">
                <Clock className="w-4 h-4 mr-1" />
                {plan.duration}{" "}
                {plan.duration > 1
                  ? plan.durationUnit + "s"
                  : plan.durationUnit}
              </div>
            </CardHeader>

            <CardContent className="pt-0">
              <div className="mb-4">
                <span className="text-2xl font-bold">${plan.price}</span>
                <span className="text-gray-500">/month</span>
              </div>

              <p className="text-gray-600 mb-4">{plan.description}</p>
              <ul className="space-y-2 mb-6">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-gym-purple mr-2 mt-0.5 flex-shrink-0" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>

              <Button
                className={`w-full ${
                  plan.name.toLowerCase().includes("premium")
                    ? "bg-gym-purple hover:bg-gym-purple/90"
                    : "bg-gym-blue hover:bg-gym-blue/90"
                }`}
                onClick={() => handleSelectPlan(plan)}
              >
                Choose Plan
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

export default CoachPlans;
