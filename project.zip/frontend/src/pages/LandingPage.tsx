import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import {
  ArrowRight,
  CheckCircle,
  DumbbellIcon,
  Heart,
  Users,
} from "lucide-react";

const LandingPage = () => {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Header/Navigation */}
      <header className="py-6 px-4 md:px-8 lg:px-12 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <DumbbellIcon className="w-8 h-8 text-gym-purple" />
          <span className="text-xl font-bold">GYMPAL</span>
        </div>
        <div className="flex items-center space-x-4">
          <Link to="/login">
            <Button variant="outline">Log In</Button>
          </Link>
          <Link to="/role-select">
            <Button className="bg-gym-purple hover:bg-gym-purple/90">
              Sign Up
            </Button>
          </Link>
        </div>
      </header>

      {/* Hero Section */}
      <section className="hero-gradient py-16 md:py-24 px-4 md:px-8 lg:px-12 flex flex-col items-center text-center">
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 max-w-3xl">
          Transform Your Fitness Journey With Expert Coaching
        </h1>
        <p className="text-lg md:text-xl text-gray-600 mb-10 max-w-2xl">
          Connect with certified coaches specializing in personalized training
          plans, including programs for individuals with disabilities.
        </p>
        <div className="flex flex-col sm:flex-row gap-4">
          <Link to="/role-select">
            <button className="cta-button">
              Get Started <ArrowRight className="ml-2 w-5 h-5" />
            </button>
          </Link>
          <Link to="/login">
            <button className="secondary-button">Login to Your Account</button>
          </Link>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 md:py-24 px-4 md:px-8 lg:px-12">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Why Choose GYMPAL?
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Our platform offers a personalized approach to fitness with expert
            coaches and tailored plans for all needs and abilities.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Feature 1 */}
          <div className="feature-card">
            <div className="rounded-full bg-gym-purple/10 w-12 h-12 flex items-center justify-center mb-4">
              <Users className="w-6 h-6 text-gym-purple" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Expert Coaching</h3>
            <p className="text-gray-600">
              Connect with certified coaches with proven experience in various
              fitness domains.
            </p>
            <ul className="mt-4 space-y-2">
              <li className="flex items-center">
                <CheckCircle className="w-5 h-5 text-gym-purple mr-2" />
                <span>Verified qualifications</span>
              </li>
              <li className="flex items-center">
                <CheckCircle className="w-5 h-5 text-gym-purple mr-2" />
                <span>Personalized attention</span>
              </li>
              <li className="flex items-center">
                <CheckCircle className="w-5 h-5 text-gym-purple mr-2" />
                <span>Continuous feedback</span>
              </li>
            </ul>
          </div>

          {/* Feature 2 */}
          <div className="feature-card">
            <div className="rounded-full bg-gym-blue/10 w-12 h-12 flex items-center justify-center mb-4">
              <Heart className="w-6 h-6 text-gym-blue" />
            </div>
            <h3 className="text-xl font-semibold mb-2">
              Inclusive Health Plans
            </h3>
            <p className="text-gray-600">
              Tailored programs for all fitness levels, including specialized
              plans for individuals with disabilities.
            </p>
            <ul className="mt-4 space-y-2">
              <li className="flex items-center">
                <CheckCircle className="w-5 h-5 text-gym-blue mr-2" />
                <span>Adaptive fitness programs</span>
              </li>
              <li className="flex items-center">
                <CheckCircle className="w-5 h-5 text-gym-blue mr-2" />
                <span>Nutrition guidance</span>
              </li>
              <li className="flex items-center">
                <CheckCircle className="w-5 h-5 text-gym-blue mr-2" />
                <span>Mobility-focused training</span>
              </li>
            </ul>
          </div>

          {/* Feature 3 */}
          <div className="feature-card">
            <div className="rounded-full bg-gym-orange/10 w-12 h-12 flex items-center justify-center mb-4">
              <DumbbellIcon className="w-6 h-6 text-gym-orange" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Flexible Pricing</h3>
            <p className="text-gray-600">
              Choose from a variety of coaching packages to match your goals and
              budget.
            </p>
            <ul className="mt-4 space-y-2">
              <li className="flex items-center">
                <CheckCircle className="w-5 h-5 text-gym-orange mr-2" />
                <span>Affordable bundles</span>
              </li>
              <li className="flex items-center">
                <CheckCircle className="w-5 h-5 text-gym-orange mr-2" />
                <span>No long-term commitments</span>
              </li>
              <li className="flex items-center">
                <CheckCircle className="w-5 h-5 text-gym-orange mr-2" />
                <span>Satisfaction guaranteed</span>
              </li>
            </ul>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gym-purple/10 py-16 md:py-24 px-4 md:px-8 lg:px-12 text-center">
        <h2 className="text-3xl md:text-4xl font-bold mb-6">
          Ready to Start Your Fitness Journey?
        </h2>
        <p className="text-lg text-gray-600 mb-10 max-w-2xl mx-auto">
          Whether you're looking for a coach or want to offer your expertise,
          GYMPAL is the platform for you.
        </p>
        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <Link to="/role-select">
            <Button
              size="lg"
              className="bg-gym-purple hover:bg-gym-purple/90 h-12 px-8"
            >
              Sign Up Now <ArrowRight className="ml-2" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-10 px-4 md:px-8 lg:px-12 bg-gym-dark text-white">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center space-x-2 mb-4 md:mb-0">
            <DumbbellIcon className="w-6 h-6" />
            <span className="text-xl font-bold">GYMPAL</span>
          </div>
          <div className="text-sm text-gray-400">
            © {new Date().getFullYear()} GYMPAL. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;
