import { useAuthStore } from "@/store/authStore";
import ClientDashboard from "./client/ClientDashboard";
import CoachDashboard from "./coach/Dashboard";
import AdminDashboard from "./admin/AdminDashboard";

const Dashboard = () => {
  const { user } = useAuthStore();

  if (user?.role === "CLIENT") return <ClientDashboard />;
  if (user?.role === "COACH") return <CoachDashboard />;
  if (user?.role === "ADMIN") return <AdminDashboard />;

  return <div>Unauthorized</div>;
};

export default Dashboard;
