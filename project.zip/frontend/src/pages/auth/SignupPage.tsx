import { useState } from "react";

import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useNavigate, Link, useParams } from "react-router-dom";
import { ArrowLeft, DumbbellIcon, Loader2 } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import CoachData from "./components/CoachData";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import useSignUp from "@/services/auth/signup";
import { UserRole } from "@/types/user";
import { useAuthStore } from "@/store/authStore";
import RedirectBasedOnRole from "@/components/Redirect";

const signupSchema = z
  .object({
    firstName: z.string().min(1, "First name is required"),
    lastName: z.string().min(1, "Last name is required"),
    email: z.string().email("Invalid email address"),
    password: z.string().min(8, "Password must be at least 8 characters long"),
    confirmPassword: z.string().min(1, "Confirm password is required"),
    city: z.string().min(1, "City is required"),
    experience: z.coerce.number().optional(),
    qualifications: z.array(z.string()).optional(),
    specialties: z.array(z.string()).optional(),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Passwords do not match",
    path: ["confirmPassword"],
  });

export type SignupFormValues = z.infer<typeof signupSchema>;

const SignupPage = () => {
  const user = useAuthStore((state) => state.user);
  const { role = "client" } = useParams<{ role: string }>();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const signup = useSignUp();

  const form = useForm<SignupFormValues>({
    resolver: zodResolver(signupSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      password: "",
      confirmPassword: "",
      city: "",
      experience: undefined,
      qualifications: undefined,
      specialties: undefined,
    },
  });

  const isCoach = role === "coach";

  const handleSubmit = async (values: SignupFormValues) => {
    const {
      firstName,
      lastName,
      email,
      password,
      confirmPassword,
      city,
      experience,
      qualifications,
      specialties,
    } = values;

    if (isCoach && (!experience || !qualifications || !specialties)) {
      // setError("Please fill out all coach information fields");
      return;
    }

    try {
      setLoading(true);
      await signup({
        firstName,
        lastName,
        email,
        city,
        ...(isCoach && {
          experience,
          qualifications,
          specialties,
        }),
        password,
        confirmPassword,
        role: role.toUpperCase() as UserRole,
      });

      if (isCoach) {
        navigate("/login");
      } else {
        navigate("/dashboard");
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (user) {
    return <RedirectBasedOnRole user={user} />;
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <div className="py-8 px-4 sm:px-6 lg:px-8">
        <Link
          to="/role-select"
          className="inline-flex items-center text-gym-purple hover:text-gym-purple/80"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Back to Role Selection
        </Link>
      </div>

      <div className="flex-grow flex items-center justify-center px-4 sm:px-6 lg:px-8 py-12">
        <div className="max-w-md w-full space-y-8">
          <div>
            <div className="flex justify-center">
              <DumbbellIcon className="h-12 w-12 text-gym-purple" />
            </div>
            <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
              Sign up as a {role}
            </h2>
            <p className="mt-2 text-center text-sm text-gray-600">
              Already have an account?{" "}
              <Link
                to="/login"
                className="font-medium text-gym-purple hover:text-gym-purple/90"
              >
                Log in
              </Link>
            </p>
          </div>

          <Form {...form}>
            <form
              className="mt-8 space-y-6"
              onSubmit={form.handleSubmit(handleSubmit)}
            >
              <div className="space-y-4">
                <FormField
                  name="firstName"
                  control={form.control}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel htmlFor="firstName">First Name</FormLabel>
                      <FormControl>
                        <Input
                          id="firstName"
                          type="text"
                          required
                          {...field}
                          className="mt-1"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  name="lastName"
                  control={form.control}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel htmlFor="lastName">Last Name</FormLabel>
                      <FormControl>
                        <Input
                          id="lastName"
                          type="text"
                          required
                          {...field}
                          className="mt-1"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  name="email"
                  control={form.control}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel htmlFor="email">Email</FormLabel>
                      <FormControl>
                        <Input
                          id="email"
                          type="email"
                          autoComplete="email"
                          required
                          {...field}
                          className="mt-1"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  name="city"
                  control={form.control}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel htmlFor="city">City</FormLabel>
                      <FormControl>
                        <Input
                          id="city"
                          type="text"
                          required
                          {...field}
                          className="mt-1"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Additional fields for coaches */}
                {isCoach && <CoachData form={form} />}

                <FormField
                  name="password"
                  control={form.control}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel htmlFor="password">Password</FormLabel>
                      <FormControl>
                        <Input
                          id="password"
                          type="password"
                          required
                          {...field}
                          className="mt-1"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  name="confirmPassword"
                  control={form.control}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel htmlFor="confirmPassword">
                        Confirm Password
                      </FormLabel>
                      <FormControl>
                        <Input
                          id="confirmPassword"
                          type="password"
                          required
                          {...field}
                          className="mt-1"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div>
                  <Button
                    type="submit"
                    className={`w-full ${
                      isCoach
                        ? "bg-gym-blue hover:bg-gym-blue/90"
                        : "bg-gym-purple hover:bg-gym-purple/90"
                    } flex items-center justify-center`}
                    disabled={loading}
                  >
                    {loading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Creating account...
                      </>
                    ) : (
                      "Sign up"
                    )}
                  </Button>
                </div>
              </div>

              {isCoach && (
                <div className="text-sm text-gray-500 bg-blue-50 p-4 rounded-md">
                  Note: Coach accounts require admin approval before they can be
                  accessed. We'll notify you by email when your account is
                  approved.
                </div>
              )}
            </form>
          </Form>
        </div>
      </div>
    </div>
  );
};

export default SignupPage;
