import { useEffect, useState } from "react";

import { z } from "zod";
import { useForm } from "react-hook-form";
import { useNavigate, Link } from "react-router-dom";
import { zodResolver } from "@hookform/resolvers/zod";
import { ArrowLeft, DumbbellIcon, Loader2 } from "lucide-react";

import { useAuthStore } from "@/store/authStore";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import useLogin from "@/services/auth/login";
import { useToast } from "@/hooks/use-toast";
import RedirectBasedOnRole from "@/components/Redirect";
import { toast } from "sonner";

const loginSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(8, "Password must be at least 8 characters long"),
});

type LoginFormValues = z.infer<typeof loginSchema>;

const LoginPage = () => {
  const user = useAuthStore((state) => state.user);
  const navigate = useNavigate();
  const login = useLogin();
  const [loading, setLoading] = useState(false);
  const form = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  const { toast } = useToast();

  const handleSubmit = async (values: LoginFormValues) => {
    try {
      setLoading(true);
      const userData = await login(values);

      // Redirect based on user role
      if (userData.role === "CLIENT") {
        navigate("/client/dashboard");
      } else if (userData.role === "COACH") {
        if (userData.coach?.status !== "APPROVED") {
          toast({
            title: "Your account is not approved yet",
            description: "Please wait for an admin to approve your account.",
            variant: "info",
          });
          return;
        }
        navigate("/coach/dashboard");
      } else if (userData.role === "ADMIN") {
        navigate("/admin/dashboard");
      } else if (userData.role === "TEAM_MEMBER") {
        navigate("/team-member/dashboard");
      } else {
        navigate("/dashboard");
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <div className="py-8 px-4 sm:px-6 lg:px-8">
        <Link
          to="/"
          className="inline-flex items-center text-gym-purple hover:text-gym-purple/80"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Back to Home
        </Link>
      </div>

      <div className="flex-grow flex items-center justify-center px-4 sm:px-6 lg:px-8">
        <div className="max-w-md w-full space-y-8">
          <div>
            <div className="flex justify-center">
              <DumbbellIcon className="h-12 w-12 text-gym-purple" />
            </div>
            <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
              Log in to your account
            </h2>
            <p className="mt-2 text-center text-sm text-gray-600">
              Or{" "}
              <Link
                to="/role-select"
                className="font-medium text-gym-purple hover:text-gym-purple/90"
              >
                create a new account
              </Link>
            </p>
          </div>

          <Form {...form}>
            <form
              className="mt-8 space-y-6"
              onSubmit={form.handleSubmit(handleSubmit)}
            >
              <div className="space-y-4">
                <FormField
                  name="email"
                  control={form.control}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          id="email"
                          type="email"
                          autoComplete="email"
                          required
                          className="mt-1"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  name="password"
                  control={form.control}
                  render={({ field }) => (
                    <FormItem>
                      <div className="flex justify-between">
                        <FormLabel>Password</FormLabel>
                        {/* <a
                          href="#"
                          className="text-sm text-gym-purple hover:text-gym-purple/90"
                        >
                          Forgot your password?
                        </a> */}
                      </div>
                      <FormControl>
                        <Input
                          {...field}
                          id="password"
                          type="password"
                          autoComplete="current-password"
                          required
                          className="mt-1"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div>
                <Button
                  type="submit"
                  className="w-full bg-gym-purple hover:bg-gym-purple/90 flex items-center justify-center"
                  disabled={loading}
                >
                  {loading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Logging in...
                    </>
                  ) : (
                    "Log in"
                  )}
                </Button>
              </div>
            </form>
          </Form>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
