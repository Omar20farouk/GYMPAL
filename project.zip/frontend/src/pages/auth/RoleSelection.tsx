import { Link, useNavigate } from "react-router-dom";
import { ArrowLeft, DumbbellIcon, Users, Award } from "lucide-react";
import { useAuthStore } from "@/store/authStore";

const RoleSelection = () => {
  const user = useAuthStore((state) => state.user);
  const navigate = useNavigate();

  if (user) {
    navigate("/dashboard");
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <div className="py-8 px-4 sm:px-6 lg:px-8">
        <Link
          to="/"
          className="inline-flex items-center text-gym-purple hover:text-gym-purple/80"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Back to Home
        </Link>
      </div>

      <div className="flex-grow flex items-center justify-center px-4 py-6 sm:px-6 lg:px-8">
        <div className="max-w-4xl w-full">
          <div className="text-center mb-12">
            <DumbbellIcon className="w-12 h-12 text-gym-purple mx-auto" />
            <h1 className="mt-4 text-3xl sm:text-4xl font-bold text-gray-900">
              Join GYMPAL
            </h1>
            <p className="mt-3 text-lg text-gray-500">
              Choose how you want to use our platform
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Client Card */}
            <Link
              to="/signup/client"
              className="relative bg-white overflow-hidden rounded-2xl shadow-lg hover:shadow-xl transition-all border border-gray-100 flex flex-col p-8 hover:border-gym-purple/30"
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-gym-purple/10 rounded-full -mr-16 -mt-16"></div>

              <Users className="mb-6 w-12 h-12 text-gym-purple" />
              <h3 className="text-2xl font-semibold mb-4">I am a Client</h3>
              <p className="text-gray-600 mb-8">
                Looking for professional coaches to help me achieve my fitness
                goals
              </p>

              <ul className="space-y-3 text-sm mb-8">
                <li className="flex items-start">
                  <span className="inline-flex items-center justify-center rounded-full bg-gym-purple/10 p-1 mr-3 mt-0.5">
                    <svg
                      className="h-4 w-4 text-gym-purple"
                      fill="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path d="M20 6L9 17l-5-5"></path>
                    </svg>
                  </span>
                  Browse qualified coaches
                </li>
                <li className="flex items-start">
                  <span className="inline-flex items-center justify-center rounded-full bg-gym-purple/10 p-1 mr-3 mt-0.5">
                    <svg
                      className="h-4 w-4 text-gym-purple"
                      fill="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path d="M20 6L9 17l-5-5"></path>
                    </svg>
                  </span>
                  Get personalized workout plans
                </li>
                <li className="flex items-start">
                  <span className="inline-flex items-center justify-center rounded-full bg-gym-purple/10 p-1 mr-3 mt-0.5">
                    <svg
                      className="h-4 w-4 text-gym-purple"
                      fill="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path d="M20 6L9 17l-5-5"></path>
                    </svg>
                  </span>
                  Track your progress
                </li>
              </ul>

              <div className="mt-auto">
                <span className="inline-flex px-6 py-3 text-white font-medium rounded-lg bg-gym-purple hover:bg-gym-purple/90 transition-colors">
                  Continue as Client
                </span>
              </div>
            </Link>

            {/* Coach Card */}
            <Link
              to="/signup/coach"
              className="relative bg-white overflow-hidden rounded-2xl shadow-lg hover:shadow-xl transition-all border border-gray-100 flex flex-col p-8 hover:border-gym-blue/30"
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-gym-blue/10 rounded-full -mr-16 -mt-16"></div>

              <Award className="mb-6 w-12 h-12 text-gym-blue" />
              <h3 className="text-2xl font-semibold mb-4">I am a Coach</h3>
              <p className="text-gray-600 mb-8">
                Looking to grow my client base and offer my coaching services
              </p>

              <ul className="space-y-3 text-sm mb-8">
                <li className="flex items-start">
                  <span className="inline-flex items-center justify-center rounded-full bg-gym-blue/10 p-1 mr-3 mt-0.5">
                    <svg
                      className="h-4 w-4 text-gym-blue"
                      fill="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path d="M20 6L9 17l-5-5"></path>
                    </svg>
                  </span>
                  Create coaching packages
                </li>
                <li className="flex items-start">
                  <span className="inline-flex items-center justify-center rounded-full bg-gym-blue/10 p-1 mr-3 mt-0.5">
                    <svg
                      className="h-4 w-4 text-gym-blue"
                      fill="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path d="M20 6L9 17l-5-5"></path>
                    </svg>
                  </span>
                  Manage client relationships
                </li>
                <li className="flex items-start">
                  <span className="inline-flex items-center justify-center rounded-full bg-gym-blue/10 p-1 mr-3 mt-0.5">
                    <svg
                      className="h-4 w-4 text-gym-blue"
                      fill="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path d="M20 6L9 17l-5-5"></path>
                    </svg>
                  </span>
                  Grow your coaching business
                </li>
              </ul>

              <div className="mt-auto">
                <span className="inline-flex px-6 py-3 text-white font-medium rounded-lg bg-gym-blue hover:bg-gym-blue/90 transition-colors">
                  Continue as Coach
                </span>
              </div>
            </Link>
          </div>

          <div className="text-center mt-8">
            <p className="text-gray-600">
              Already have an account?{" "}
              <Link
                to="/login"
                className="text-gym-purple font-medium hover:underline"
              >
                Log in
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RoleSelection;
