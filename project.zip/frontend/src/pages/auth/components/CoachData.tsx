import { UseFormReturn } from "react-hook-form";

import { Input } from "@/components/ui/input";
import { SignupFormValues } from "../SignupPage";
import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { MultiSelect } from "@/components/ui/multi-select";
import useGetSpecialties from "@/services/specialties/list";
import useGetQualifications from "@/services/qualifications/list";

const CoachData = ({ form }: { form: UseFormReturn<SignupFormValues> }) => {
  const { data: specialties } = useGetSpecialties();
  const { data: qualifications } = useGetQualifications();

  const specialtyOptions = specialties?.map((specialty) => ({
    value: specialty.id,
    label: specialty.name,
  }));

  const qualificationOptions = qualifications?.map((qualification) => ({
    value: qualification.id,
    label: qualification.name,
  }));

  return (
    <>
      <FormField
        name="experience"
        control={form.control}
        render={({ field }) => (
          <FormItem>
            <FormLabel htmlFor="experience">Experience (years)</FormLabel>
            <FormControl>
              <Input
                id="experience"
                type="text"
                required
                {...field}
                className="mt-1"
              />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />

      <FormField
        name="qualifications"
        control={form.control}
        render={({ field }) => (
          <FormItem>
            <FormLabel htmlFor="qualifications">
              Qualifications (e.g., certifications)
            </FormLabel>
            <FormControl>
              <MultiSelect
                id="qualifications"
                required
                options={qualificationOptions ?? []}
                {...field}
              />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />

      <FormField
        name="specialties"
        control={form.control}
        render={({ field }) => (
          <FormItem>
            <FormLabel htmlFor="specialties">
              Specialties (e.g., disabilities expertise)
            </FormLabel>
            <FormControl>
              <MultiSelect
                id="specialties"
                required
                options={specialtyOptions ?? []}
                {...field}
              />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />
    </>
  );
};

export default CoachData;
