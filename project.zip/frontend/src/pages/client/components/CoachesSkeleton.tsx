import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

const CoachesSkeleton = () => {
  return Array.from({ length: 3 }).map((_, index) => (
    <Card
      key={index}
      className="overflow-hidden hover:shadow-lg transition-shadow"
    >
      <div className="flex flex-col md:flex-row">
        <div className="w-full md:w-1/4 bg-gray-50 p-4 flex items-center justify-center">
          <div className="aspect-square w-32 h-32 rounded-full overflow-hidden bg-gym-purple/10 flex items-center justify-center">
            <Skeleton className="w-32 h-32 rounded-full" />
          </div>
        </div>

        <div className="w-full md:w-3/4">
          <CardHeader>
            <div className="flex justify-between items-start">
              <div>
                <CardTitle>
                  <Skeleton />
                </CardTitle>
                <CardDescription className="flex items-center mt-1">
                  <Skeleton className="h-4 w-24" />
                </CardDescription>
              </div>
              <div className="flex items-center bg-gym-purple/10 text-gym-purple py-1 px-2 rounded-md">
                <span className="font-medium">
                  <Skeleton className="h-4 w-24" />
                </span>
                <span className="text-xs text-gray-500 ml-1">
                  <Skeleton className="h-4 w-24" />
                </span>
              </div>
            </div>
          </CardHeader>

          <CardContent>
            <div className="mb-4">
              <h4 className="font-medium mb-2">
                <Skeleton className="h-4 w-24" />
              </h4>
              <div className="flex flex-wrap gap-2">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-4 w-24" />
              </div>
            </div>

            <p className="text-gray-600 line-clamp-2">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full mt-2" />
              <Skeleton className="h-4 w-full mt-2" />
            </p>
          </CardContent>

          <CardFooter className="flex justify-between items-center border-t pt-4">
            <div className="space-y-2">
              <p className="text-sm text-gray-500">
                <Skeleton className="h-4 w-24" />
              </p>
              <p className="text-lg font-bold text-gym-purple">
                <Skeleton className="h-4 w-24" />
              </p>
            </div>
          </CardFooter>
        </div>
      </div>
    </Card>
  ));
};

export default CoachesSkeleton;
