import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Star, Dumbbell, MapPin } from "lucide-react";
import useGetCoaches from "@/services/coaches/list";
import { Coach } from "@/types/coach";
import CoachesSkeleton from "./components/CoachesSkeleton";
import useGetSpecialties from "@/services/specialties/list";
import { Specialty } from "@/types/specialty";
import useGetMaxPrice from "@/services/plans/max-price";

const ClientDashboard = () => {
  const navigate = useNavigate();
  const { data: maxPriceData, isLoading: isLoadingMaxPrice } = useGetMaxPrice();
  const maxPrice = maxPriceData?.maxPrice || 500;

  const [localPriceRange, setLocalPriceRange] = useState<[number, number]>([
    0,
    maxPrice,
  ]);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  // Update price range when max price is loaded
  useEffect(() => {
    if (maxPriceData) {
      setLocalPriceRange([0, maxPriceData.maxPrice]);
    }
  }, [maxPriceData]);

  const { data: coaches, isLoading } = useGetCoaches({
    specialty: selectedCategory,
    priceRange: localPriceRange,
  });
  const { data: specialties } = useGetSpecialties();

  const handleCategoryChange = (value: string) => {
    const category = value === "all" ? null : (value as Specialty["id"]);
    setSelectedCategory(category);
  };

  const handlePriceRangeChange = (value: number[]) => {
    const range = [value[0], value[1]] as [number, number];
    setLocalPriceRange(range);
  };

  const handleCoachSelect = (coach: Coach) => {
    navigate(`/client/coach/${coach.id}`);
  };

  const specialtyOptions = [
    {
      label: "All",
      value: "all",
    },
    ...(specialties?.map((specialty) => ({
      label: specialty.name,
      value: specialty.id,
    })) ?? []),
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-2">Find Your Coach</h1>
      <p className="text-gray-600 mb-8">
        Browse our selection of professional coaches
      </p>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Filters sidebar */}
        <div className="bg-white p-6 rounded-lg shadow-md h-fit lg:sticky lg:top-24">
          <h2 className="font-semibold text-lg mb-6">Filters</h2>

          <div className="space-y-6">
            {/* Category filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Category
              </label>
              <Select onValueChange={handleCategoryChange} defaultValue="all">
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select a category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectGroup>
                    {specialtyOptions.map((category) => (
                      <SelectItem key={category.value} value={category.value}>
                        {category.label}
                      </SelectItem>
                    ))}
                  </SelectGroup>
                </SelectContent>
              </Select>
            </div>
            {/* Price range filter */}{" "}
            <div>
              <div className="flex justify-between mb-2">
                <label className="block text-sm font-medium text-gray-700">
                  Price Range
                </label>
                <span className="text-sm text-gray-500">
                  ${localPriceRange[0]} - ${localPriceRange[1]}
                </span>
              </div>
              <Slider
                defaultValue={[0, maxPrice]}
                max={maxPrice}
                step={10}
                value={[localPriceRange[0], localPriceRange[1]]}
                onValueChange={handlePriceRangeChange}
                className="mt-6"
              />
            </div>
          </div>
        </div>

        {/* Coach list */}
        <div className="lg:col-span-3 space-y-6">
          {isLoading ? (
            <CoachesSkeleton />
          ) : coaches!.length === 0 ? (
            <div className="text-center p-12 bg-white rounded-lg shadow">
              <Dumbbell className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-4 text-lg font-medium text-gray-900">
                No coaches found
              </h3>
              <p className="mt-2 text-gray-500">
                Try adjusting your filters to find coaches that match your
                criteria.
              </p>
              <Button
                className="mt-6 bg-gym-purple hover:bg-gym-purple/90"
                onClick={() => {
                  setLocalPriceRange([0, maxPrice]);
                  setSelectedCategory(null);
                }}
              >
                Reset Filters
              </Button>
            </div>
          ) : (
            coaches!.map((coach) => (
              <Card
                key={coach.id}
                className="overflow-hidden hover:shadow-lg transition-shadow"
              >
                <div className="flex flex-col md:flex-row">
                  <div className="w-full md:w-1/4 bg-gray-50 p-4 flex items-center justify-center">
                    <div className="aspect-square w-32 h-32 rounded-full overflow-hidden bg-gym-purple/10 flex items-center justify-center">
                      {/* {coach.profileImage ? (
                        <img
                          src={coach.profileImage}
                          alt={coach.user.firstName}
                          className="w-full h-full object-cover"
                        />
                      ) : ( */}
                      <span className="text-4xl font-bold text-gym-purple">
                        {coach.user.firstName.charAt(0)}
                      </span>
                      {/* )} */}
                    </div>
                  </div>

                  <div className="w-full md:w-3/4">
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle>{coach.user.firstName}</CardTitle>
                          <CardDescription className="flex items-center mt-1">
                            <MapPin className="w-4 h-4 mr-1" />
                            {coach.user.city}
                          </CardDescription>
                        </div>
                        <div className="flex items-center bg-gym-purple/10 text-gym-purple py-1 px-2 rounded-md">
                          <Star className="w-4 h-4 mr-1 fill-current" />
                          <span className="font-medium">
                            {coach.averageRating}
                          </span>
                          <span className="text-xs text-gray-500 ml-1">
                            ({coach.reviews.length} reviews)
                          </span>
                        </div>
                      </div>
                    </CardHeader>

                    <CardContent>
                      <div className="mb-4">
                        <h4 className="font-medium mb-2">Specialties</h4>
                        <div className="flex flex-wrap gap-2">
                          {coach.specialties.map((specialty) => (
                            <span
                              key={specialty.id}
                              className="bg-gray-100 text-gray-800 text-xs font-medium py-1 px-2 rounded"
                            >
                              {specialty.name}
                            </span>
                          ))}
                        </div>
                      </div>

                      <p className="text-gray-600 line-clamp-2">
                        {coach.about}
                      </p>
                    </CardContent>

                    <CardFooter className="flex justify-between items-center border-t pt-4">
                      <div>
                        {coach.plans.length > 0 && (
                          <>
                            <p className="text-sm text-gray-500">
                              Starting from
                            </p>
                            <p className="text-lg font-bold text-gym-purple">
                              $
                              {Math.min(
                                ...coach.plans.map((plan) => plan.price)
                              )}
                              /month
                            </p>
                          </>
                        )}
                      </div>

                      <Button
                        className="bg-gym-purple hover:bg-gym-purple/90"
                        onClick={() => handleCoachSelect(coach)}
                      >
                        View Details
                      </Button>
                    </CardFooter>
                  </div>
                </div>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default ClientDashboard;
