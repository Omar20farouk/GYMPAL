import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useCoachStore } from "@/store/coachStore";
import {
  Elements,
  PaymentElement,
  useStripe,
  useElements,
} from "@stripe/react-stripe-js";
import { loadStripe } from "@stripe/stripe-js";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { createPaymentIntent } from "@/services/stripeService";
import { useAuthStore } from "@/store/authStore";

const stripePromise = loadStripe(
  "pk_test_51ROkMDFQo9sfl2sXV3DztbHshi2yb5fyYVBbkceWZDX9QAbsQYwZ3eYAnzvId2NZc4ohL7yNCY2U26FpbfxfSZ4y00MaXVPbOy"
);

const CheckoutForm = () => {
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | undefined>();
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setLoading(true);

    const result = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: `${window.location.origin}/client/payment-success`,
      },
    });

    if (result.error) {
      setErrorMessage(result.error.message);
      toast({
        title: "Payment failed",
        description: result.error.message,
        variant: "destructive",
      });
    }

    setLoading(false);
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="space-y-6">
        <PaymentElement />

        {errorMessage && (
          <div className="text-red-500 text-sm">{errorMessage}</div>
        )}

        <Button
          type="submit"
          disabled={!stripe || loading}
          className="w-full bg-gym-purple hover:bg-gym-purple/90"
        >
          {loading ? "Processing..." : "Pay Now"}
        </Button>
      </div>
    </form>
  );
};

const Payment = () => {
  const [clientSecret, setClientSecret] = useState<string>("");
  const navigate = useNavigate();
  const { selectedCoach, selectedPlan } = useCoachStore();
  const { toast } = useToast();
  const { user } = useAuthStore();
  console.log(user);

  // Check if user has selected a coach and plan
  useEffect(() => {
    if (!selectedCoach || !selectedPlan) {
      navigate("/client/dashboard");
      return;
    }

    // Create payment intent when component loads
    const initializePayment = async () => {
      try {
        if (!user || !user.id) {
          toast({
            title: "Authentication Error",
            description: "You need to be logged in to make a payment.",
            variant: "destructive",
          });
          navigate("/login");
          return;
        }

        const paymentIntent = await createPaymentIntent({
          planId: selectedPlan.id,
        });

        setClientSecret(paymentIntent.clientSecret);
      } catch (error) {
        toast({
          title: "Error",
          description: "Could not initialize payment. Please try again.",
          variant: "destructive",
        });
        console.error("Payment initialization error:", error);
      }
    };

    initializePayment();
  }, []);

  if (!clientSecret) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-2xl">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gym-purple mx-auto"></div>
          <p className="mt-4">Initializing payment...</p>
        </div>
      </div>
    );
  }

  const appearance = {
    theme: "stripe" as const,
    variables: {
      colorPrimary: "#8b5cf6",
    },
  };

  const options = {
    clientSecret,
    appearance,
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-2xl mx-auto">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center text-gym-purple hover:text-gym-purple/80 mb-6"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Back to Health Form
        </button>

        <div className="bg-white rounded-lg shadow-md overflow-hidden mb-8">
          <div className="p-6 border-b">
            <h1 className="text-2xl font-bold">Payment</h1>
            <p className="text-gray-600 mt-1">
              Complete your payment to subscribe to the training plan
            </p>
          </div>

          <div className="p-6">
            <Elements stripe={stripePromise} options={options}>
              <CheckoutForm />
            </Elements>
          </div>
        </div>

        <div className="bg-gray-50 rounded-lg p-6 border border-gray-200">
          <h3 className="font-medium mb-4">Your Selected Plan</h3>
          <div className="flex justify-between items-center">
            <div>
              <p className="font-semibold">{selectedPlan?.name}</p>
              <p className="text-sm text-gray-600">
                With {selectedCoach?.user.firstName}
              </p>
            </div>
            <div className="text-right">
              <p className="font-semibold">${selectedPlan?.price}</p>
              <p className="text-sm text-gray-600">per month</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Payment;
