import { useState, useEffect, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useAuthStore } from "@/store/authStore";
import { chatSocketService } from "@/services/chat/socket";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Send, MessageSquare, UserCircle } from "lucide-react";

interface Message {
  id: string;
  chatId: string;
  senderId: string;
  senderType: "CLIENT" | "COACH";
  content: string;
  read: boolean;
  sentAt: string;
}

interface ConversationInfo {
  chatId: string;
  coachId: string;
  coachName: string;
  planName: string;
  lastMessage: string | null;
  lastMessageDate: string | null;
  unreadCount: number;
}

export default function ClientChat() {
  const { coachId } = useParams<{ coachId: string }>();
  const navigate = useNavigate();
  const user = useAuthStore((state) => state.user);
  const [conversations, setConversations] = useState<ConversationInfo[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [isConnected, setIsConnected] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedCoach, setSelectedCoach] = useState<ConversationInfo | null>(
    null
  );
  const [isTyping, setIsTyping] = useState(false);
  const [typingTimeout, setTypingTimeout] = useState<NodeJS.Timeout | null>(
    null
  );
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Connect to chat socket
  useEffect(() => {
    const connectToSocket = async () => {
      try {
        const connected = await chatSocketService.connect();
        setIsConnected(connected);

        if (!connected) {
          setError("Failed to connect to chat service");
        }
      } catch (err) {
        setError("Error connecting to chat service");
        console.error(err);
      } finally {
        setIsLoading(false);
      }
    };

    connectToSocket();

    return () => {
      chatSocketService.disconnect();
    };
  }, []);

  // Load conversations
  useEffect(() => {
    const loadConversations = async () => {
      if (!isConnected || !user) return;

      try {
        const response = await chatSocketService.getClientConversations();
        if (response.success) {
          setConversations(response.conversations);
        }
      } catch (err) {
        console.error("Failed to load conversations:", err);
      }
    };

    if (isConnected) {
      loadConversations();
    }
  }, [isConnected, user]);

  // Listen for new messages
  useEffect(() => {
    if (!isConnected) return;

    const unsubscribe = chatSocketService.onNewMessage((newMsg: Message) => {
      // If this message belongs to the current conversation
      if (selectedCoach && newMsg.chatId === selectedCoach.chatId) {
        setMessages((prev) => [...prev, newMsg]);
      }

      // Update the conversations list with new message info
      setConversations((prev) =>
        prev.map((conv) => {
          if (conv.chatId === newMsg.chatId) {
            return {
              ...conv,
              lastMessage: newMsg.content,
              lastMessageDate: newMsg.sentAt,
              unreadCount:
                newMsg.senderType === "COACH" && !newMsg.read
                  ? conv.unreadCount + 1
                  : conv.unreadCount,
            };
          }
          return conv;
        })
      );
    });

    // Listen for typing status updates
    const unsubscribeTyping = chatSocketService.onTypingStatus((data) => {
      if (selectedCoach?.coachId === data.userId) {
        setIsTyping(data.isTyping);
      }
    });

    return () => {
      unsubscribe();
      unsubscribeTyping();
    };
  }, [isConnected, selectedCoach, user?.id]);

  // Load conversation messages when coach is selected
  useEffect(() => {
    const loadMessages = async () => {
      if (!selectedCoach || !user) return;

      try {
        const response = await chatSocketService.getConversation(
          selectedCoach.chatId
        );

        if (response.success) {
          setMessages(response.messages);

          // Mark messages as read
          const unreadMessages = response.messages
            .filter((msg: Message) => msg.senderType === "COACH" && !msg.read)
            .map((msg: Message) => msg.id);

          if (unreadMessages.length > 0) {
            await chatSocketService.markAsRead(unreadMessages);

            // Update unread count in conversations
            setConversations((prev) =>
              prev.map((conv) =>
                conv.chatId === selectedCoach.chatId
                  ? { ...conv, unreadCount: 0 }
                  : conv
              )
            );
          }
        }
      } catch (err) {
        console.error("Failed to load messages:", err);
      }
    };

    if (isConnected && selectedCoach) {
      loadMessages();
    }
  }, [isConnected, selectedCoach, user]);

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Select coach from URL param
  useEffect(() => {
    if (coachId && conversations.length > 0) {
      const coach = conversations.find((c) => c.coachId === coachId);
      if (coach) {
        setSelectedCoach(coach);
      }
    }
  }, [coachId, conversations]);

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !selectedCoach || !user) return;

    try {
      const messageData = {
        receiverId: selectedCoach.coachId,
        content: newMessage.trim(),
      };

      await chatSocketService.sendMessage(messageData);
      setNewMessage("");

      // Stop typing indicator
      if (typingTimeout) {
        clearTimeout(typingTimeout);
        chatSocketService.sendTypingStatus(selectedCoach.coachId, false);
      }
    } catch (err) {
      console.error("Failed to send message:", err);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setNewMessage(e.target.value);

    // Send typing status
    if (selectedCoach) {
      chatSocketService.sendTypingStatus(selectedCoach.coachId, true);

      // Clear previous timeout
      if (typingTimeout) {
        clearTimeout(typingTimeout);
      }

      // Set new timeout to stop typing indicator after 2 seconds
      const timeout = setTimeout(() => {
        if (selectedCoach) {
          chatSocketService.sendTypingStatus(selectedCoach.coachId, false);
        }
      }, 2000);

      setTypingTimeout(timeout);
    }
  };

  const selectCoach = (coach: ConversationInfo) => {
    setSelectedCoach(coach);

    // Update URL without reloading the page
    window.history.pushState({}, "", `/client/chat/${coach.coachId}`);
  };

  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <p>Loading chat...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex h-screen items-center justify-center">
        <p className="text-red-500">{error}</p>
      </div>
    );
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat("en-US", {
      hour: "numeric",
      minute: "numeric",
      hour12: true,
      month: "short",
      day: "numeric",
    }).format(date);
  };

  return (
    <div className="h-[calc(100vh-4rem)] flex flex-col">
      <div className="text-xl font-semibold p-4 border-b">Messages</div>

      <div className="flex flex-grow overflow-hidden">
        {/* Coaches sidebar */}
        <div className="w-1/3 border-r overflow-y-auto">
          {conversations.length === 0 ? (
            <div className="p-4 text-center text-gray-500">
              No coaches to chat with. Subscribe to a coach's plan to start a
              conversation.
            </div>
          ) : (
            conversations.map((coach) => (
              <div
                key={coach.coachId}
                className={`p-4 border-b cursor-pointer ${
                  selectedCoach?.coachId === coach.coachId
                    ? "bg-blue-50"
                    : "hover:bg-gray-50"
                }`}
                onClick={() => selectCoach(coach)}
              >
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarFallback>
                      {coach.coachName
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <div className="font-medium">{coach.coachName}</div>
                      {coach.unreadCount > 0 && (
                        <span className="bg-blue-500 text-white text-xs px-2 py-1 rounded-full">
                          {coach.unreadCount}
                        </span>
                      )}
                    </div>
                    <div className="text-sm text-gray-500 truncate">
                      {coach.lastMessage || ""}
                    </div>
                    {coach.lastMessageDate && (
                      <div className="text-xs text-gray-400 mt-1">
                        {formatDate(coach.lastMessageDate)}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Chat area */}
        <div className="flex-1 flex flex-col">
          {selectedCoach ? (
            <>
              {/* Coach header */}
              <div className="p-3 border-b flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarFallback>
                      {selectedCoach.coachName
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-medium">{selectedCoach.coachName}</div>
                    <div className="text-sm text-gray-500">
                      {selectedCoach.planName}
                    </div>
                  </div>
                </div>
              </div>

              {/* Messages */}
              <div className="flex-grow overflow-y-auto p-4">
                {messages.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-gray-400">
                    <MessageSquare size={48} />
                    <p className="mt-2">
                      No messages yet. Start a conversation!
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {messages.map((message) => (
                      <div
                        key={message.id}
                        className={`flex ${
                          message.senderType === "CLIENT"
                            ? "justify-end"
                            : "justify-start"
                        }`}
                      >
                        <div
                          className={`max-w-[70%] rounded-lg p-3 ${
                            message.senderType === "CLIENT"
                              ? "bg-blue-500 text-white rounded-br-none"
                              : "bg-gray-100 rounded-bl-none"
                          }`}
                        >
                          <div>{message.content}</div>
                          <div
                            className={`text-xs mt-1 ${
                              message.senderType === "CLIENT"
                                ? "text-blue-100"
                                : "text-gray-500"
                            }`}
                          >
                            {formatDate(message.sentAt)}
                          </div>
                        </div>
                      </div>
                    ))}
                    {isTyping && (
                      <div className="flex justify-start">
                        <div className="bg-gray-100 rounded-lg p-3 rounded-bl-none">
                          <div className="flex gap-1">
                            <span className="animate-bounce">•</span>
                            <span
                              className="animate-bounce"
                              style={{ animationDelay: "0.2s" }}
                            >
                              •
                            </span>
                            <span
                              className="animate-bounce"
                              style={{ animationDelay: "0.4s" }}
                            >
                              •
                            </span>
                          </div>
                        </div>
                      </div>
                    )}
                    <div ref={messagesEndRef} />
                  </div>
                )}
              </div>

              {/* Message input */}
              <div className="p-4 border-t">
                <div className="flex gap-2">
                  <Input
                    value={newMessage}
                    onChange={handleInputChange}
                    onKeyDown={handleKeyDown}
                    placeholder="Type a message..."
                    className="flex-1"
                  />
                  <Button
                    onClick={handleSendMessage}
                    disabled={!newMessage.trim()}
                    size="icon"
                  >
                    <Send />
                  </Button>
                </div>
              </div>
            </>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-gray-400">
              <UserCircle size={64} />
              <p className="mt-4 text-lg">Select a coach to start chatting</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
