import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useCoachStore } from "@/store/coachStore";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { ArrowLeft, ArrowRight } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import useSubmitHealthForm from "@/services/health-form/submit";
import path from "path";

const healthFormSchema = z.object({
  height: z.string().min(1, "Height is required"),
  weight: z.string().min(1, "Weight is required"),
  chronicDiseases: z.string().optional(),
  hasDisability: z.boolean(),
  disabilityDetails: z.string().optional(),
  favoriteFood: z.string().optional(),
  fitnessGoal: z.enum(
    [
      "Weight Loss",
      "Muscle Gain",
      "Endurance",
      "Flexibility",
      "Tournament Prep",
      "General Health",
      "Other",
    ],
    { message: "Please select a fitness goal" }
  ),
});

type HealthFormValues = z.infer<typeof healthFormSchema>;

const HealthForm = () => {
  const navigate = useNavigate();
  const { selectedCoach, selectedPlan } = useCoachStore();
  const submitHealthForm = useSubmitHealthForm();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<HealthFormValues>({
    resolver: zodResolver(healthFormSchema),
    defaultValues: {
      height: "",
      weight: "",
      chronicDiseases: "",
      hasDisability: false,
      disabilityDetails: "",
      favoriteFood: "",
    },
  });

  // Form state
  const [currentStep, setCurrentStep] = useState(1);

  // Check if user has selected a coach and plan
  useEffect(() => {
    if (!selectedCoach || !selectedPlan) {
      navigate("/client/dashboard");
    }
  }, [selectedCoach, selectedPlan]);

  if (!selectedCoach || !selectedPlan) {
    return null;
  }

  const validateStep = async (step: number) => {
    let isValid = true;

    if (step === 1) {
      isValid = await form.trigger(["height", "weight"]);
    } else if (step === 2) {
      isValid = await form.trigger([
        "chronicDiseases",
        "hasDisability",
        "disabilityDetails",
      ]);
    } else if (step === 3) {
      isValid = await form.trigger(["fitnessGoal"]);
    }

    return isValid;
  };

  const handleNextStep = async (e: React.FormEvent) => {
    e.preventDefault();
    if (await validateStep(currentStep)) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePreviousStep = (e: React.FormEvent) => {
    e.preventDefault();
    setCurrentStep(currentStep - 1);
  };

  const handleSubmit = async (values: HealthFormValues) => {
    if (await validateStep(currentStep)) {
      try {
        setIsSubmitting(true);
        await submitHealthForm({
          height: values.height,
          weight: values.weight,
          chronicDiseases: values.chronicDiseases || "",
          hasDisability: values.hasDisability,
          disabilityDetails: values.disabilityDetails || "",
          favoriteFood: values.favoriteFood || "",
          fitnessGoal: values.fitnessGoal,
          planId: selectedPlan.id,
        });

        navigate("/client/payment");
      } catch (error) {
        console.error("Failed to submit health form:", error);
      }
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-2xl mx-auto">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center text-gym-purple hover:text-gym-purple/80 mb-6"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Back to Coach Profile
        </button>

        <div className="bg-white rounded-lg shadow-md overflow-hidden mb-8">
          <div className="p-6 border-b">
            <h1 className="text-2xl font-bold">Health Details</h1>
            <p className="text-gray-600 mt-1">
              Please provide some health information to help your coach create a
              personalized plan.
            </p>
          </div>

          <div className="p-6">
            {/* Progress indicator */}
            <div className="mb-8">
              <div className="flex items-center justify-between">
                <div className="text-xs font-medium">Basic Info</div>
                <div className="text-xs font-medium">Medical History</div>
                <div className="text-xs font-medium">Goals & Preferences</div>
              </div>
              <div className="mt-2 h-2 w-full bg-gray-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gym-purple transition-all duration-300 ease-in-out"
                  style={{ width: `${(currentStep / 3) * 100}%` }}
                ></div>
              </div>
            </div>

            <Form {...form}>
              <form onSubmit={form.handleSubmit(handleSubmit)}>
                {/* Step 1: Basic Information */}
                {currentStep === 1 && (
                  <div className="space-y-6">
                    <h2 className="text-xl font-semibold">Basic Information</h2>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        name="height"
                        control={form.control}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel htmlFor="height">Height (cm)</FormLabel>
                            <FormControl>
                              <Input
                                id="height"
                                type="number"
                                {...field}
                                className="mt-1"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        name="weight"
                        control={form.control}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel htmlFor="weight">Weight (kg)</FormLabel>
                            <FormControl>
                              <Input
                                id="weight"
                                type="number"
                                {...field}
                                className="mt-1"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                )}

                {/* Step 2: Medical History */}
                {currentStep === 2 && (
                  <div className="space-y-6">
                    <h2 className="text-xl font-semibold">Medical History</h2>
                    <FormField
                      name="chronicDiseases"
                      control={form.control}
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Chronic Diseases (if any)</FormLabel>
                          <FormControl>
                            <Textarea
                              id="chronicDiseases"
                              {...field}
                              placeholder="Please list any chronic diseases or conditions you have."
                              className="h-24"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="space-y-4">
                      <FormField
                        name="hasDisability"
                        control={form.control}
                        render={({ field }) => (
                          <FormItem className="space-y-0 space-x-2 flex items-center">
                            <FormControl>
                              <Checkbox
                                id="hasDisability"
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <FormLabel htmlFor="hasDisability">
                              I have a disability that may affect training
                            </FormLabel>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {form.getValues("hasDisability") && (
                        <FormField
                          name="disabilityDetails"
                          control={form.control}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel htmlFor="hasDisability">
                                Disability Details
                              </FormLabel>
                              <FormControl>
                                <Textarea
                                  id="disabilityDetails"
                                  {...field}
                                  placeholder="Please provide details about your disability and how it impacts your physical activities."
                                  className="h-24"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      )}
                    </div>
                  </div>
                )}

                {/* Step 3: Goals and Preferences */}
                {currentStep === 3 && (
                  <div className="space-y-6">
                    <h2 className="text-xl font-semibold">
                      Goals & Preferences
                    </h2>

                    <FormField
                      name="favoriteFood"
                      control={form.control}
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel htmlFor="favoriteFood">
                            Favorite Foods
                          </FormLabel>
                          <FormControl>
                            <Textarea
                              id="favoriteFood"
                              {...field}
                              placeholder="Please provide details about your favorite foods and eating habits."
                              className="h-24"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      name="fitnessGoal"
                      control={form.control}
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel htmlFor="fitnessGoal">
                            Fitness Goal
                          </FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger id="fitnessGoal">
                                <SelectValue placeholder="Select your primary fitness goal" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="Weight Loss">
                                Weight Loss
                              </SelectItem>
                              <SelectItem value="Muscle Gain">
                                Muscle Gain
                              </SelectItem>
                              <SelectItem value="Endurance">
                                Endurance
                              </SelectItem>
                              <SelectItem value="Flexibility">
                                Flexibility
                              </SelectItem>
                              <SelectItem value="Tournament Prep">
                                Tournament Preparation
                              </SelectItem>
                              <SelectItem value="General Health">
                                General Health
                              </SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                )}

                {/* Navigation buttons */}
                <div className="mt-8 flex justify-between">
                  {currentStep > 1 ? (
                    <Button
                      type="button"
                      variant="outline"
                      onClick={handlePreviousStep}
                      className="flex items-center"
                    >
                      <ArrowLeft className="w-4 h-4 mr-2" />
                      Previous
                    </Button>
                  ) : (
                    <div></div>
                  )}

                  {currentStep <= 3 ? (
                    <Button
                      type="button"
                      onClick={handleNextStep}
                      className="bg-gym-purple hover:bg-gym-purple/90 flex items-center"
                    >
                      Next
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  ) : (
                    <Button
                      type="submit"
                      disabled={isSubmitting}
                      className="bg-gym-purple hover:bg-gym-purple/90"
                    >
                      Proceed to Payment
                    </Button>
                  )}
                </div>
              </form>
            </Form>
          </div>
        </div>

        <div className="bg-gray-50 rounded-lg p-6 border border-gray-200">
          <h3 className="font-medium mb-4">Your Selected Plan</h3>
          <div className="flex justify-between items-center">
            <div>
              <p className="font-semibold">{selectedPlan.name}</p>
              <p className="text-sm text-gray-600">
                With {selectedCoach.user.firstName}
              </p>
            </div>
            <div className="text-right">
              <p className="font-semibold">${selectedPlan.price}</p>
              <p className="text-sm text-gray-600">per month</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HealthForm;
