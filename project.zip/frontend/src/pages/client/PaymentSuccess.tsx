import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { getPaymentStatus, confirmPayment } from "@/services/stripeService";
import { useToast } from "@/components/ui/use-toast";

const PaymentSuccess = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const paymentIntentId = searchParams.get("payment_intent");
    const paymentStatus = searchParams.get("redirect_status");

    const processPayment = async () => {
      if (!paymentIntentId || paymentStatus !== "succeeded") {
        setError("Invalid payment information");
        setLoading(false);
        return;
      }

      try {
        // Verify payment status with backend
        const statusResponse = await getPaymentStatus(paymentIntentId);

        if (statusResponse.status === "succeeded") {
          // Confirm the payment on the backend to create subscription
          await confirmPayment(paymentIntentId);

          toast({
            title: "Payment Successful",
            description: "Your subscription has been activated!",
          });
        } else {
          setError("Payment verification failed. Please contact support.");
        }
      } catch (err) {
        console.error("Payment confirmation error:", err);
        setError("Something went wrong. Please contact support.");
      } finally {
        setLoading(false);
      }
    };

    processPayment();
  }, []);

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-16 max-w-2xl">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gym-purple mx-auto"></div>
          <p className="mt-4">Verifying payment...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-16 max-w-2xl">
        <div className="bg-white rounded-lg shadow-md p-8 text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-red-100 mb-6">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-8 w-8 text-red-500"
              viewBox="0 0 20 20"
              fill="currentColor"
            >
              <path
                fillRule="evenodd"
                d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z"
                clipRule="evenodd"
              />
            </svg>
          </div>
          <h2 className="text-2xl font-bold mb-4">Payment Error</h2>
          <p className="text-gray-600 mb-8">{error}</p>
          <div className="flex justify-center">
            <Button
              onClick={() => navigate("/client/dashboard")}
              className="bg-gym-purple hover:bg-gym-purple/90"
            >
              Go to Dashboard
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-16 max-w-2xl">
      <div className="bg-white rounded-lg shadow-md p-8 text-center">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 mb-6">
          <CheckCircle className="h-8 w-8 text-green-500" />
        </div>
        <h2 className="text-2xl font-bold mb-4">Payment Successful!</h2>
        <p className="text-gray-600 mb-8">
          Your subscription has been activated. You can now start your fitness
          journey with your selected coach.
        </p>
        <div className="flex justify-center">
          <Button
            onClick={() => navigate("/client/dashboard")}
            className="bg-gym-purple hover:bg-gym-purple/90"
          >
            Go to Dashboard
          </Button>
        </div>
      </div>
    </div>
  );
};

export default PaymentSuccess;
