import React, { useState, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { AlertCircle, Image, Upload } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import useCreateComplaint from "@/services/complaints/create";
import useUploadImage from "@/services/uploads/uploadImage";
import useCheckSubscriptionStatus from "@/services/subscriptions/checkStatus";

// Schema for form validation
const formSchema = z.object({
  description: z
    .string()
    .min(10, "Description must be at least 10 characters")
    .max(500, "Description must be less than 500 characters"),
});

const ComplaintForm = () => {
  const { coachId } = useParams<{ coachId: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [previews, setPreviews] = useState<string[]>([]);

  const createComplaint = useCreateComplaint();
  const uploadImage = useUploadImage();

  const { data: hasActiveSubscription, isLoading: isCheckingSubscription } =
    useCheckSubscriptionStatus(coachId || "");

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      description: "",
    },
  });

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;

    if (!files) return;

    // Limit to maximum 5 images
    if (selectedFiles.length + files.length > 5) {
      toast({
        title: "Too many files",
        description: "You can upload a maximum of 5 images",
        variant: "destructive",
      });
      return;
    }

    // Check file types (only images allowed)
    const newFiles: File[] = [];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];

      if (!file.type.startsWith("image/")) {
        toast({
          title: "Invalid file type",
          description: "Only image files are allowed",
          variant: "destructive",
        });
        continue;
      }

      if (file.size > 5 * 1024 * 1024) {
        // 5MB limit
        toast({
          title: "File too large",
          description: "Images must be less than 5MB",
          variant: "destructive",
        });
        continue;
      }

      newFiles.push(file);
    }

    // Add new files to state
    setSelectedFiles((prev) => [...prev, ...newFiles]);

    // Generate and add previews
    const newPreviews = newFiles.map((file) => URL.createObjectURL(file));
    setPreviews((prev) => [...prev, ...newPreviews]);
  };

  const removeFile = (index: number) => {
    // Remove file and its preview
    setSelectedFiles((prev) => prev.filter((_, i) => i !== index));

    // Revoke object URL to avoid memory leaks
    URL.revokeObjectURL(previews[index]);
    setPreviews((prev) => prev.filter((_, i) => i !== index));
  };

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    if (!coachId) {
      toast({
        title: "Error",
        description: "Coach ID is required",
        variant: "destructive",
      });
      return;
    }

    if (!hasActiveSubscription) {
      toast({
        title: "Subscription Required",
        description: "You must be subscribed to this coach to file a complaint",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsSubmitting(true);

      // Upload images if any and collect URLs
      const imageUrls: string[] = [];

      if (selectedFiles.length > 0) {
        toast({
          title: "Uploading images",
          description: "Please wait while we upload your images...",
        });

        for (const file of selectedFiles) {
          try {
            const imageUrl = await uploadImage(file);
            imageUrls.push(imageUrl);
          } catch (error) {
            // Continue with remaining uploads even if one fails
            console.error(`Failed to upload image ${file.name}:`, error);
          }
        }
      }

      // Create the complaint with image URLs if any
      await createComplaint({
        coachId,
        description: values.description,
        ...(imageUrls.length > 0 && { images: imageUrls }),
      });

      toast({
        title: "Complaint Submitted",
        description: "Your complaint has been submitted successfully.",
      });

      // Reset form and navigate back
      form.reset();
      setSelectedFiles([]);
      setPreviews([]);

      // Navigate back to client dashboard
      navigate("/client/dashboard");
    } catch (error) {
      console.error("Error submitting complaint:", error);
      toast({
        title: "Error",
        description: "Failed to submit complaint. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isCheckingSubscription) {
    return (
      <div className="container mx-auto max-w-2xl p-6">
        <div className="flex items-center justify-center p-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
        </div>
      </div>
    );
  }

  if (coachId && !hasActiveSubscription) {
    return (
      <div className="container mx-auto max-w-2xl p-6">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Subscription Required</AlertTitle>
          <AlertDescription>
            You must be subscribed to this coach to file a complaint. Please
            subscribe to their coaching plan first.
          </AlertDescription>
        </Alert>
        <div className="mt-4">
          <Button onClick={() => navigate(`/client/coach/${coachId}`)}>
            View Coach's Plans
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto max-w-2xl p-6">
      <Card>
        <CardHeader>
          <CardTitle>File a Complaint</CardTitle>
          <CardDescription>
            Please provide details about your issue with the coach. Your
            complaint will be reviewed by our administrative team.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Please describe your issue in detail..."
                        className="h-32"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div>
                <FormLabel htmlFor="images">Evidence (Optional)</FormLabel>
                <div className="mt-2">
                  <div
                    className="border-2 border-dashed rounded-md p-6 flex flex-col items-center justify-center cursor-pointer hover:bg-gray-50"
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <Upload className="h-8 w-8 text-gray-400" />
                    <p className="mt-2 text-sm text-gray-500">
                      Click to upload screenshots or evidence (max 5 images)
                    </p>
                    <p className="text-xs text-gray-400 mt-1">
                      PNG, JPG, GIF up to 5MB
                    </p>
                    <Input
                      id="images"
                      type="file"
                      accept="image/*"
                      multiple
                      className="hidden"
                      ref={fileInputRef}
                      onChange={handleFileChange}
                    />
                  </div>
                </div>

                {/* Preview of selected images */}
                {previews.length > 0 && (
                  <div className="mt-4 grid grid-cols-2 gap-4">
                    {previews.map((preview, index) => (
                      <div key={index} className="relative group">
                        <img
                          src={preview}
                          alt={`Preview ${index + 1}`}
                          className="h-24 w-full object-cover rounded-md"
                        />
                        <button
                          type="button"
                          className="absolute top-0 right-0 bg-red-500 text-white p-1 rounded-full transform translate-x-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity"
                          onClick={() => removeFile(index)}
                        >
                          X
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <CardFooter className="px-0 pb-0 pt-6">
                <Button
                  type="submit"
                  className="w-full"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? "Submitting..." : "Submit Complaint"}
                </Button>
              </CardFooter>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
};

export default ComplaintForm;
