import CoachDetails from "@/modules/coach/coach-details";

const CoachDetailsPage = () => {
  return <CoachDetails />;
};

export default CoachDetailsPage;
