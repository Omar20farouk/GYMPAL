import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  useGetProfile,
  useUpdateClientProfile,
} from "@/services/profile/profile";
import { useGetSubscriptions } from "@/services/profile/subscriptions";
import useGetClientComplaints from "@/services/complaints/getClientComplaints";
import { Spinner } from "@/components/ui/spinner";
import { SubscriptionCard } from "@/components/subscriptions/SubscriptionCard";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Complaint, ComplaintStatus } from "@/types/complaint";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";

const clientProfileSchema = z.object({
  firstName: z
    .string()
    .min(2, { message: "First name must be at least 2 characters" }),
  lastName: z
    .string()
    .min(2, { message: "Last name must be at least 2 characters" }),
  city: z.string().min(2, { message: "City must be at least 2 characters" }),
});

type ClientProfileValues = z.infer<typeof clientProfileSchema>;

export default function ClientProfilePage() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("profile");
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(
    null
  );

  const { data: profile, isLoading: profileLoading } = useGetProfile();
  const { data: subscriptions, isLoading: subscriptionsLoading } =
    useGetSubscriptions();
  const { data: complaints, isLoading: complaintsLoading } =
    useGetClientComplaints();
  const { mutate: updateProfile, isPending: isUpdating } =
    useUpdateClientProfile();

  const form = useForm<ClientProfileValues>({
    resolver: zodResolver(clientProfileSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      city: "",
    },
  });

  useEffect(() => {
    if (profile) {
      form.reset({
        firstName: profile.firstName,
        lastName: profile.lastName,
        city: profile.city,
      });
    }
  }, [profile, form]);

  function onSubmit(values: ClientProfileValues) {
    updateProfile(values, {
      onSuccess: () => {
        toast({
          title: "Profile updated",
          description: "Your profile has been updated successfully.",
        });
      },
      onError: () => {
        toast({
          title: "Error",
          description:
            "An error occurred while updating your profile. Please try again.",
          variant: "destructive",
        });
      },
    });
  }

  if (profileLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Spinner size="lg" />
      </div>
    );
  }

  return (
    <div className="container py-10">
      <h1 className="text-3xl font-bold mb-8">My Profile</h1>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-8">
          <TabsTrigger value="profile">Profile Information</TabsTrigger>
          <TabsTrigger value="subscriptions">My Subscriptions</TabsTrigger>
          <TabsTrigger value="complaints">My Complaints</TabsTrigger>
        </TabsList>

        <TabsContent value="profile">
          <Card>
            <CardHeader>
              <CardTitle>Profile Information</CardTitle>
              <CardDescription>
                Update your personal information
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form
                  onSubmit={form.handleSubmit(onSubmit)}
                  className="space-y-6"
                >
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="firstName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>First Name</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="lastName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Last Name</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="city"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>City</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input value={profile?.email || ""} disabled />
                      </FormControl>
                    </FormItem>
                  </div>

                  <Button type="submit" disabled={isUpdating}>
                    {isUpdating ? <Spinner className="mr-2" size="sm" /> : null}
                    Save Changes
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="subscriptions">
          <Card>
            <CardHeader>
              <CardTitle>My Subscriptions</CardTitle>
              <CardDescription>View all your subscriptions</CardDescription>
            </CardHeader>
            <CardContent>
              {subscriptionsLoading ? (
                <div className="flex items-center justify-center h-40">
                  <Spinner size="lg" />
                </div>
              ) : subscriptions && subscriptions.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {subscriptions.map((subscription) => (
                    <SubscriptionCard
                      key={subscription.id}
                      subscription={subscription}
                    />
                  ))}
                </div>
              ) : (
                <div className="text-center py-10">
                  <p className="text-muted-foreground">
                    You don't have any subscriptions yet.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="complaints">
          <Card>
            <CardHeader>
              <CardTitle>My Complaints</CardTitle>
              <CardDescription>
                Review all complaints you have filed
              </CardDescription>
            </CardHeader>
            <CardContent>
              {complaintsLoading ? (
                <div className="flex items-center justify-center h-40">
                  <Spinner size="lg" />
                </div>
              ) : complaints && complaints.length > 0 ? (
                <div>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Coach</TableHead>
                        <TableHead>Date Filed</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Description</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {complaints.map((complaint) => (
                        <TableRow
                          key={complaint.id}
                          className="cursor-pointer hover:bg-muted/50"
                          onClick={() => setSelectedComplaint(complaint)}
                        >
                          <TableCell className="font-medium">
                            {complaint.coach?.user?.firstName}{" "}
                            {complaint.coach?.user?.lastName}
                          </TableCell>
                          <TableCell>
                            {new Date(complaint.createdAt).toLocaleDateString()}
                          </TableCell>
                          <TableCell>
                            {complaint.status === ComplaintStatus.PENDING ? (
                              <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-200">
                                Pending
                              </Badge>
                            ) : (
                              <Badge className="bg-green-100 text-green-800 hover:bg-green-200">
                                Resolved
                              </Badge>
                            )}
                          </TableCell>
                          <TableCell>
                            {complaint.description.length > 50
                              ? `${complaint.description.substring(0, 50)}...`
                              : complaint.description}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <div className="text-center py-10">
                  <p className="text-muted-foreground">
                    You haven't filed any complaints yet.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Complaint Details Dialog */}
      <Dialog
        open={!!selectedComplaint}
        onOpenChange={() => setSelectedComplaint(null)}
      >
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Complaint Details</DialogTitle>
            <DialogDescription>
              Filed on{" "}
              {selectedComplaint &&
                new Date(selectedComplaint.createdAt).toLocaleString()}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <h3 className="font-medium">Status</h3>
              <div>
                {selectedComplaint?.status === ComplaintStatus.PENDING ? (
                  <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-200">
                    Pending
                  </Badge>
                ) : (
                  <Badge className="bg-green-100 text-green-800 hover:bg-green-200">
                    Resolved
                  </Badge>
                )}
              </div>
            </div>

            <div>
              <h3 className="font-medium">Coach</h3>
              <p>
                {selectedComplaint?.coach?.user?.firstName}{" "}
                {selectedComplaint?.coach?.user?.lastName}
              </p>
              <p className="text-sm text-gray-500">
                {selectedComplaint?.coach?.user?.email}
              </p>
            </div>

            <div>
              <h3 className="font-medium">Description</h3>
              <p className="text-sm mt-1 whitespace-pre-wrap">
                {selectedComplaint?.description}
              </p>
            </div>

            {selectedComplaint?.images &&
              selectedComplaint.images.length > 0 && (
                <div>
                  <h3 className="font-medium">Evidence Images</h3>
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    {selectedComplaint.images.map((image, index) => (
                      <div key={index} className="relative">
                        <img
                          src={image}
                          alt={`Evidence ${index + 1}`}
                          className="rounded-md object-cover w-full h-auto cursor-pointer"
                          onClick={() => window.open(image, "_blank")}
                        />
                        <div className="absolute bottom-0 right-0 bg-black bg-opacity-50 text-white text-xs px-1 rounded-tl">
                          Click to enlarge
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function getStatusVariant(status: ComplaintStatus) {
  switch (status) {
    case ComplaintStatus.PENDING:
      return "outline";
    case ComplaintStatus.RESOLVED:
      return "success";
    // case ComplaintStatus.REJECTED:
    //   return "destructive";
    default:
      return "default";
  }
}
