import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Search, Download, Loader2 } from "lucide-react";
import { format } from "date-fns";
import { useGetPayments } from "@/services/payments/list";

const PaymentsPage = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  const { data: payments = [], isLoading } = useGetPayments();

  // Calculate platform fee (20% based on the payment service logic)
  const calculatePlatformFee = (amount: number) => amount * 0.2;

  // Filter payments based on search query and status
  const filteredPayments = payments.filter((payment) => {
    const clientName = `${payment.client?.firstName || ""} ${
      payment.client?.lastName || ""
    }`.trim();
    const coachName = `${payment.coach?.firstName || ""} ${
      payment.coach?.lastName || ""
    }`.trim();

    const matchesSearch =
      clientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      coachName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      payment.id.toString().toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus =
      statusFilter === "all" || payment.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  // Calculate totals
  const totalRevenue = filteredPayments.reduce(
    (sum, payment) => sum + Number(payment.amount),
    0
  );

  const totalPlatformFees = filteredPayments.reduce(
    (sum, payment) => sum + calculatePlatformFee(Number(payment.amount)),
    0
  );

  const exportToCSV = () => {
    const headers = [
      "ID",
      "Date",
      "Client",
      "Coach",
      "Plan",
      "Amount",
      "Platform Fee",
      "Status",
    ];

    const dataRows = filteredPayments.map((payment) => [
      payment.id.toString(),
      format(new Date(payment.createdAt), "yyyy-MM-dd"),
      `${payment.client?.firstName || ""} ${
        payment.client?.lastName || ""
      }`.trim(),
      `${payment.coach?.firstName || ""} ${
        payment.coach?.lastName || ""
      }`.trim(),
      payment.plan?.name || "",
      Number(payment.amount).toFixed(2),
      calculatePlatformFee(Number(payment.amount)).toFixed(2),
      payment.status,
    ]);

    const csvContent = [
      headers.join(","),
      ...dataRows.map((row) => row.join(",")),
    ].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute(
      "download",
      `payments_${format(new Date(), "yyyyMMdd")}.csv`
    );
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="container p-6 mx-auto">
      <h1 className="text-2xl font-bold mb-6">Payment Transactions</h1>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">
              Total Transactions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{filteredPayments.length}</div>
            <p className="text-xs text-gray-500 mt-1">In filtered results</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${totalRevenue.toFixed(2)}</div>
            <p className="text-xs text-gray-500 mt-1">From all transactions</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Platform Fees</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              ${totalPlatformFees.toFixed(2)}
            </div>
            <p className="text-xs text-gray-500 mt-1">Total earnings</p>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 w-4 h-4" />
          <Input
            placeholder="Search by client, coach, or transaction ID..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <div className="w-full md:w-48">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectGroup>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="succeeded">Succeeded</SelectItem>
                <SelectItem value="failed">Failed</SelectItem>
              </SelectGroup>
            </SelectContent>
          </Select>
        </div>
        <Button
          variant="outline"
          className="flex items-center gap-2"
          onClick={exportToCSV}
        >
          <Download className="w-4 h-4" />
          Export CSV
        </Button>
      </div>

      {/* Transactions Table */}
      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="flex justify-center items-center p-8">
              <Loader2 className="h-8 w-8 animate-spin text-gray-500" />
              <span className="ml-2">Loading payment data...</span>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Client</TableHead>
                  <TableHead>Coach</TableHead>
                  <TableHead>Plan</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Platform Fee</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredPayments.length > 0 ? (
                  filteredPayments.map((payment) => {
                    const platformFee = calculatePlatformFee(
                      Number(payment.amount)
                    );
                    const clientName = `${
                      payment.client?.user?.firstName || ""
                    } ${payment.client?.user?.lastName || ""}`.trim();
                    const coachName = `${
                      payment.coach?.user?.firstName || ""
                    } ${payment.coach?.user?.lastName || ""}`.trim();

                    return (
                      <TableRow key={payment.id}>
                        <TableCell className="font-medium">
                          {payment.id}
                        </TableCell>
                        <TableCell>
                          {format(new Date(payment.createdAt), "yyyy-MM-dd")}
                        </TableCell>
                        <TableCell>{clientName || "Unknown Client"}</TableCell>
                        <TableCell>{coachName || "Unknown Coach"}</TableCell>
                        <TableCell>
                          {payment.plan?.name || "Unknown Plan"}
                        </TableCell>
                        <TableCell>
                          ${Number(payment.amount).toFixed(2)}
                        </TableCell>
                        <TableCell>${platformFee.toFixed(2)}</TableCell>
                        <TableCell>
                          <span
                            className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                              payment.status === "succeeded"
                                ? "bg-green-100 text-green-800"
                                : payment.status === "pending"
                                ? "bg-yellow-100 text-yellow-800"
                                : payment.status === "refunded"
                                ? "bg-blue-100 text-blue-800"
                                : "bg-red-100 text-red-800"
                            }`}
                          >
                            {payment.status.charAt(0).toUpperCase() +
                              payment.status.slice(1)}
                          </span>
                        </TableCell>
                      </TableRow>
                    );
                  })
                ) : (
                  <TableRow>
                    <TableCell
                      colSpan={8}
                      className="text-center py-8 text-gray-500"
                    >
                      No payment records found
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default PaymentsPage;
