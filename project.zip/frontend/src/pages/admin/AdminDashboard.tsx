import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DollarSign, Users, ShieldCheck, AlertTriangle } from "lucide-react";
import useGetDashboardStats from "@/services/admin/get-dashboard-stats";
import useGetPendingCoaches from "@/services/admin/get-pending-coaches";
import useGetReports from "@/services/admin/get-reports";
import useApproveCoach from "@/services/admin/approve-coach";
import useRejectCoach from "@/services/admin/reject-coach";
import { Skeleton } from "@/components/ui/skeleton";
import { formatDistanceToNow } from "date-fns";

const AdminDashboard = () => {
  const { data: stats, isLoading: isLoadingStats } = useGetDashboardStats();
  const { data: pendingCoaches, isLoading: isLoadingCoaches } =
    useGetPendingCoaches();
  const { data: reports, isLoading: isLoadingReports } = useGetReports();
  const approveCoach = useApproveCoach();
  const rejectCoach = useRejectCoach();

  const formatDate = (dateString: string) => {
    try {
      return formatDistanceToNow(new Date(dateString), { addSuffix: true });
    } catch (e) {
      return "Unknown date";
    }
  };

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Admin Dashboard</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {/* Stats Cards */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            <Users className="h-4 w-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            {isLoadingStats ? (
              <Skeleton className="h-8 w-20" />
            ) : (
              <>
                <div className="text-2xl font-bold">
                  {stats?.totalUsers || 0}
                </div>
                <div className="flex items-center pt-1">
                  <span className="text-xs text-green-600">
                    +{stats?.userGrowth || 0}%
                  </span>
                  <span className="text-xs text-gray-500 ml-2">
                    from last month
                  </span>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">
              Pending Approvals
            </CardTitle>
            <ShieldCheck className="h-4 w-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            {isLoadingStats ? (
              <Skeleton className="h-8 w-20" />
            ) : (
              <>
                <div className="text-2xl font-bold">
                  {stats?.pendingCoaches || 0}
                </div>
                <p className="text-xs text-gray-500 mt-1">New coach requests</p>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Reports</CardTitle>
            <AlertTriangle className="h-4 w-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            {isLoadingStats ? (
              <Skeleton className="h-8 w-20" />
            ) : (
              <>
                <div className="text-2xl font-bold">{stats?.reports || 0}</div>
                <p className="text-xs text-gray-500 mt-1">Content violations</p>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">
              Platform Revenue
            </CardTitle>
            <DollarSign className="h-4 w-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            {isLoadingStats ? (
              <Skeleton className="h-8 w-20" />
            ) : (
              <>
                <div className="text-2xl font-bold">
                  ${stats?.revenue.toLocaleString() || 0}
                </div>
                <div className="flex items-center pt-1">
                  <span className="text-xs text-green-600">
                    +{stats?.revenueGrowth || 0}%
                  </span>
                  <span className="text-xs text-gray-500 ml-2">
                    from last month
                  </span>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Pending Coach Approvals */}
        <Card>
          <CardHeader>
            <CardTitle>Pending Coach Approvals</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoadingCoaches ? (
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="flex justify-between items-center">
                    <Skeleton className="h-14 w-full" />
                  </div>
                ))}
              </div>
            ) : pendingCoaches && pendingCoaches.length > 0 ? (
              <div className="space-y-4">
                {pendingCoaches.map((coach) => (
                  <div
                    key={coach.id}
                    className="flex justify-between items-center"
                  >
                    <div className="flex items-center">
                      <div className="w-10 h-10 rounded-full bg-gray-200 mr-3 flex items-center justify-center">
                        {coach.user.firstName?.charAt(0) || ""}
                        {coach.user.lastName?.charAt(0) || ""}
                      </div>
                      <div>
                        <div className="font-medium">
                          {coach.user.firstName} {coach.user.lastName}
                        </div>
                        <div className="text-sm text-gray-500">
                          {coach.experience || 0} years experience •{" "}
                          {coach.specialties
                            .map((specialty) => specialty.name)
                            .join(", ") || "General fitness"}
                        </div>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <button
                        className="px-3 py-1 bg-green-100 text-green-800 text-sm rounded-md hover:bg-green-200"
                        onClick={() => approveCoach(coach.id)}
                      >
                        Approve
                      </button>
                      <button
                        className="px-3 py-1 bg-red-100 text-red-800 text-sm rounded-md hover:bg-red-200"
                        onClick={() => rejectCoach(coach.id)}
                      >
                        Deny
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-center text-gray-500 py-8">
                No pending coach approvals
              </p>
            )}
          </CardContent>
        </Card>

        {/* Recent Reports */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Reports</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoadingReports ? (
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <Skeleton key={i} className="h-24 w-full" />
                ))}
              </div>
            ) : reports && reports.length > 0 ? (
              <div className="space-y-4">
                {reports.map((report) => (
                  <div key={report.id} className="bg-red-50 p-3 rounded-md">
                    <div className="flex justify-between mb-1">
                      <div className="font-medium">{report.title}</div>
                      <div className="text-xs text-gray-500">
                        {formatDate(report.createdAt)}
                      </div>
                    </div>
                    <p className="text-sm mb-2">{report.description}</p>
                    <div className="text-xs text-gray-600 mb-2">
                      <span className="font-medium">Client:</span>{" "}
                      {report.client} |{" "}
                      <span className="font-medium"> Coach:</span>{" "}
                      {report.coach}
                    </div>
                    <div className="flex justify-end">
                      <button className="px-3 py-1 bg-red-100 text-red-800 text-sm rounded-md hover:bg-red-200">
                        Review
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-center text-gray-500 py-8">
                No pending reports
              </p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AdminDashboard;
