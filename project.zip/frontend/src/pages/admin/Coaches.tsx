import React, { useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
} from "@/components/ui/dropdown-menu";
import { Check, X, MoreVertical, Search } from "lucide-react";
import useApproveCoach from "@/services/admin/approve-coach";
import useRejectCoach from "@/services/admin/reject-coach";
import useGetCoaches from "@/services/coaches/list";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";

// Define the Coach structure
interface Coach {
  id: string;
  userId: string;
  user: {
    firstName: string;
    lastName: string;
    email: string;
    city: string;
  };
  status: "PENDING" | "APPROVED" | "REJECTED";
  experience: number;
  specialties: { id: string; name: string }[];
}

const CoachesApproval = () => {
  const approveCoach = useApproveCoach();
  const rejectCoach = useRejectCoach();
  const [searchQuery, setSearchQuery] = useState("");
  const { data: coaches, isLoading } = useGetCoaches();

  const filteredCoaches = coaches
    ? coaches.filter(
        (coach) =>
          coach.user?.firstName
            .toLowerCase()
            .includes(searchQuery.toLowerCase()) ||
          coach.user?.lastName
            .toLowerCase()
            .includes(searchQuery.toLowerCase()) ||
          coach.user?.email?.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "PENDING":
        return (
          <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-200">
            Pending
          </Badge>
        );
      case "APPROVED":
        return (
          <Badge className="bg-green-100 text-green-800 hover:bg-green-200">
            Approved
          </Badge>
        );
      case "REJECTED":
        return (
          <Badge className="bg-red-100 text-red-800 hover:bg-red-200">
            Rejected
          </Badge>
        );
      default:
        return null;
    }
  };

  return (
    <div className="container p-6 mx-auto">
      <h1 className="text-2xl font-bold mb-6">Coaches</h1>

      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 w-4 h-4" />
          <Input
            placeholder="Search by name or email..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Coaches</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center p-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Location</TableHead>
                  <TableHead>Experience</TableHead>
                  <TableHead>Specialties</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredCoaches.length === 0 ? (
                  <TableRow>
                    <TableCell
                      colSpan={7}
                      className="text-center py-8 text-gray-500"
                    >
                      No coaches found
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredCoaches.map((coach) => (
                    <TableRow key={coach.id}>
                      <TableCell className="font-medium">
                        {coach.user.firstName} {coach.user.lastName}
                      </TableCell>
                      <TableCell>{coach.user.email}</TableCell>
                      <TableCell>{coach.user.city}</TableCell>
                      <TableCell>{coach.experience} years</TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {coach.specialties.map((specialty) => (
                            <Badge
                              key={specialty.id}
                              variant="outline"
                              className="mr-1"
                            >
                              {specialty.name}
                            </Badge>
                          ))}
                        </div>
                      </TableCell>
                      <TableCell>{getStatusBadge(coach.status)}</TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <MoreVertical className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem
                              disabled={
                                coach.status !== "PENDING" &&
                                coach.status !== "REJECTED"
                              }
                              onClick={() => approveCoach(coach.id)}
                              className="text-green-600"
                            >
                              <Check className="mr-2" size={16} /> Approve
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              disabled={
                                coach.status !== "PENDING" &&
                                coach.status !== "APPROVED"
                              }
                              onClick={() => rejectCoach(coach.id)}
                              className="text-red-600"
                            >
                              <X className="mr-2" size={16} /> Reject
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default CoachesApproval;
