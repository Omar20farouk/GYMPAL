import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { Search } from "lucide-react";
import useGetClients from "@/services/clients/list";

const ClientsTable = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const { data: clients, isLoading } = useGetClients();

  const filteredClients = clients
    ? clients.filter(
        (client) =>
          client.user?.firstName
            .toLowerCase()
            .includes(searchQuery.toLowerCase()) ||
          client.user?.lastName
            .toLowerCase()
            .includes(searchQuery.toLowerCase()) ||
          client.user?.email.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];

  return (
    <div className="container p-6 mx-auto">
      <h1 className="text-2xl font-bold mb-6">Clients</h1>

      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 w-4 h-4" />
          <Input
            placeholder="Search by name or email..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Clients</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center p-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>City</TableHead>
                  <TableHead>Join Date</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredClients.length === 0 ? (
                  <TableRow>
                    <TableCell
                      colSpan={5}
                      className="text-center py-8 text-gray-500"
                    >
                      No clients found
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredClients.map((client) => (
                    <TableRow key={client.id}>
                      <TableCell className="font-medium">
                        {client.user?.firstName} {client.user?.lastName}
                      </TableCell>
                      <TableCell>{client.user?.email}</TableCell>
                      <TableCell>{client.user?.city}</TableCell>

                      <TableCell>
                        {new Date(client.user?.createdAt).toLocaleDateString()}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default ClientsTable;
