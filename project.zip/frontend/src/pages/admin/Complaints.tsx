import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Search, MoreVertical, CheckCircle } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
} from "@/components/ui/dropdown-menu";
import useGetComplaints from "@/services/complaints/list";
import useResolveComplaint from "@/services/complaints/resolve";
import { Complaint, ComplaintStatus } from "@/types/complaint";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";

const ComplaintsTable = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(
    null
  );
  const { data: complaints, isLoading } = useGetComplaints();
  const resolveComplaint = useResolveComplaint();

  const filteredComplaints = complaints
    ? complaints.filter(
        (complaint) =>
          complaint.client?.user?.firstName
            ?.toLowerCase()
            .includes(searchQuery.toLowerCase()) ||
          complaint.client?.user?.lastName
            ?.toLowerCase()
            .includes(searchQuery.toLowerCase()) ||
          complaint.coach?.user?.firstName
            ?.toLowerCase()
            .includes(searchQuery.toLowerCase()) ||
          complaint.coach?.user?.lastName
            ?.toLowerCase()
            .includes(searchQuery.toLowerCase()) ||
          complaint.description
            ?.toLowerCase()
            .includes(searchQuery.toLowerCase())
      )
    : [];

  const getStatusBadge = (status: ComplaintStatus) => {
    switch (status) {
      case ComplaintStatus.PENDING:
        return (
          <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-200">
            Pending
          </Badge>
        );
      case ComplaintStatus.RESOLVED:
        return (
          <Badge className="bg-green-100 text-green-800 hover:bg-green-200">
            Resolved
          </Badge>
        );
      default:
        return null;
    }
  };

  const handleResolveComplaint = async (id: string) => {
    await resolveComplaint(id);
    setSelectedComplaint(null);
  };

  const handleViewComplaintDetails = (complaint: Complaint) => {
    setSelectedComplaint(complaint);
  };

  return (
    <div className="container p-6 mx-auto">
      <h1 className="text-2xl font-bold mb-6">Complaints Management</h1>

      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 w-4 h-4" />
          <Input
            placeholder="Search complaints..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Complaints</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center p-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Client</TableHead>
                  <TableHead>Coach</TableHead>
                  <TableHead>Date Filed</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredComplaints.length === 0 ? (
                  <TableRow>
                    <TableCell
                      colSpan={6}
                      className="text-center py-8 text-gray-500"
                    >
                      No complaints found
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredComplaints.map((complaint) => (
                    <TableRow key={complaint.id}>
                      <TableCell className="font-medium">
                        {complaint.client?.user?.firstName}{" "}
                        {complaint.client?.user?.lastName}
                      </TableCell>
                      <TableCell>
                        {complaint.coach?.user?.firstName}{" "}
                        {complaint.coach?.user?.lastName}
                      </TableCell>
                      <TableCell>
                        {new Date(complaint.createdAt).toLocaleDateString()}
                      </TableCell>
                      <TableCell>{getStatusBadge(complaint.status)}</TableCell>
                      <TableCell>
                        {complaint.description.length > 50
                          ? `${complaint.description.substring(0, 50)}...`
                          : complaint.description}
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <MoreVertical className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem
                              onClick={() =>
                                handleViewComplaintDetails(complaint)
                              }
                            >
                              View Details
                            </DropdownMenuItem>
                            {complaint.status === ComplaintStatus.PENDING && (
                              <DropdownMenuItem
                                onClick={() =>
                                  handleResolveComplaint(complaint.id)
                                }
                                className="text-green-600"
                              >
                                <CheckCircle className="mr-2" size={16} /> Mark
                                as Resolved
                              </DropdownMenuItem>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Complaint Details Dialog */}
      <Dialog
        open={!!selectedComplaint}
        onOpenChange={() => setSelectedComplaint(null)}
      >
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Complaint Details</DialogTitle>
            <DialogDescription>
              Filed on{" "}
              {selectedComplaint &&
                new Date(selectedComplaint.createdAt).toLocaleString()}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <h3 className="font-medium">Status</h3>
              <div>
                {selectedComplaint && getStatusBadge(selectedComplaint.status)}
              </div>
            </div>

            <div>
              <h3 className="font-medium">Client</h3>
              <p>
                {selectedComplaint?.client?.user?.firstName}{" "}
                {selectedComplaint?.client?.user?.lastName}
              </p>
              <p className="text-sm text-gray-500">
                {selectedComplaint?.client?.user?.email}
              </p>
            </div>

            <div>
              <h3 className="font-medium">Coach</h3>
              <p>
                {selectedComplaint?.coach?.user?.firstName}{" "}
                {selectedComplaint?.coach?.user?.lastName}
              </p>
              <p className="text-sm text-gray-500">
                {selectedComplaint?.coach?.user?.email}
              </p>
            </div>

            <div>
              <h3 className="font-medium">Description</h3>
              <p className="text-sm mt-1 whitespace-pre-wrap">
                {selectedComplaint?.description}
              </p>
            </div>

            {selectedComplaint?.images &&
              selectedComplaint.images.length > 0 && (
                <div>
                  <h3 className="font-medium">Evidence Images</h3>
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    {selectedComplaint.images.map((image, index) => (
                      <div key={index} className="relative">
                        <img
                          src={image}
                          alt={`Evidence ${index + 1}`}
                          className="rounded-md object-cover w-full h-auto cursor-pointer"
                          onClick={() => window.open(image, "_blank")}
                        />
                        <div className="absolute bottom-0 right-0 bg-black bg-opacity-50 text-white text-xs px-1 rounded-tl">
                          Click to enlarge
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
          </div>

          {selectedComplaint?.status === ComplaintStatus.PENDING && (
            <div className="flex justify-end mt-4">
              <Button
                onClick={() => handleResolveComplaint(selectedComplaint.id)}
                className="bg-green-600 hover:bg-green-700"
              >
                <CheckCircle className="mr-2 h-4 w-4" /> Mark as Resolved
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ComplaintsTable;
