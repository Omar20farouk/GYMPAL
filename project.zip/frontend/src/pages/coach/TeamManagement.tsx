import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Spinner } from "@/components/ui/spinner";
import { Plus, Edit, Trash2 } from "lucide-react";
import { TeamForm } from "@/components/teams/TeamForm";
import {
  useGetCoachTeam,
  useCreateTeam,
  useUpdateTeam,
  useDeleteTeam,
  useRemoveTeamMember,
} from "@/services/teams";
import { CreateTeamParams, TeamMember, UpdateTeamParams } from "@/types/team";
import { TeamMembersList } from "@/components/teams/TeamMembersList";
import { useGetProfile } from "@/services/profile/profile";
import { CreateTeamMemberForm } from "@/components/teams/CreateTeamMemberForm";
import { UpdateTeamMemberForm } from "@/components/teams/UpdateTeamMemberForm";

export default function TeamManagement() {
  const { data: profile, isLoading: isLoadingProfile } = useGetProfile();
  const { data: teams, isLoading: isLoadingTeams } = useGetCoachTeam();
  const createTeam = useCreateTeam();
  const updateTeam = useUpdateTeam();
  const deleteTeam = useDeleteTeam();
  const removeTeamMember = useRemoveTeamMember();

  // Team dialog states
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);

  // Team member dialog states
  const [isCreateMemberDialogOpen, setIsCreateMemberDialogOpen] =
    useState(false);
  const [isUpdateMemberDialogOpen, setIsUpdateMemberDialogOpen] =
    useState(false);
  const [selectedMember, setSelectedMember] = useState<TeamMember | null>(null);

  const team = teams && teams.length > 0 ? teams[0] : null;
  const isCoach = profile?.role === "COACH";

  const handleCreateTeam = (data: CreateTeamParams | UpdateTeamParams) => {
    // Ensure we have a name for creating a team
    if (!("name" in data) || !data.name) {
      return;
    }

    createTeam.mutate(data as CreateTeamParams, {
      onSuccess: () => {
        setIsCreateDialogOpen(false);
      },
    });
  };

  const handleUpdateTeam = (data: CreateTeamParams | UpdateTeamParams) => {
    if (team) {
      updateTeam.mutate(
        { id: team.id, data: data as UpdateTeamParams },
        {
          onSuccess: () => {
            setIsEditDialogOpen(false);
          },
        }
      );
    }
  };

  const handleDeleteTeam = () => {
    if (team) {
      deleteTeam.mutate(team.id, {
        onSuccess: () => {
          setIsDeleteDialogOpen(false);
        },
      });
    }
  };

  const handleRemoveMember = (member: TeamMember) => {
    if (team) {
      removeTeamMember.mutate({ teamId: team.id, memberId: member.id });
    }
  };

  if (isLoadingProfile || isLoadingTeams) {
    return (
      <div className="flex justify-center items-center h-[500px]">
        <Spinner size="lg" />
      </div>
    );
  }

  if (!isCoach) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold mb-2">Access Denied</h2>
        <p className="text-muted-foreground">
          You need to be a coach to access team management.
        </p>
      </div>
    );
  }

  return (
    <div className="container py-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold">Team Management</h1>
        {!team && (
          <Dialog
            open={isCreateDialogOpen}
            onOpenChange={setIsCreateDialogOpen}
          >
            <DialogTrigger asChild>
              <Button className="flex items-center gap-1">
                <Plus className="h-4 w-4" /> Create Team
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogTitle>Create a New Team</DialogTitle>
              <TeamForm
                onSubmit={handleCreateTeam}
                isLoading={createTeam.isPending}
              />
            </DialogContent>
          </Dialog>
        )}
      </div>

      {team ? (
        <Card>
          <CardHeader className="flex flex-row items-start justify-between">
            <div>
              <CardTitle className="text-2xl">{team.name}</CardTitle>
              {team.description && (
                <CardDescription className="mt-2">
                  {team.description}
                </CardDescription>
              )}
            </div>
            <div className="flex gap-2">
              <Dialog
                open={isEditDialogOpen}
                onOpenChange={setIsEditDialogOpen}
              >
                <DialogTrigger asChild>
                  <Button variant="outline" size="icon">
                    <Edit className="h-4 w-4" />
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogTitle>Edit Team</DialogTitle>
                  <TeamForm
                    team={team}
                    onSubmit={handleUpdateTeam}
                    isLoading={updateTeam.isPending}
                  />
                </DialogContent>
              </Dialog>

              <AlertDialog
                open={isDeleteDialogOpen}
                onOpenChange={setIsDeleteDialogOpen}
              >
                <AlertDialogTrigger asChild>
                  <Button variant="outline" size="icon">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Delete Team</AlertDialogTitle>
                    <AlertDialogDescription>
                      Are you sure you want to delete your team? This action
                      cannot be undone and all team member relationships will be
                      lost.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction
                      onClick={handleDeleteTeam}
                      disabled={deleteTeam.isPending}
                      className="bg-red-600 hover:bg-red-700"
                    >
                      {deleteTeam.isPending ? "Deleting..." : "Delete"}
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          </CardHeader>
          <CardContent>
            <TeamMembersList
              members={team.members || []}
              onCreateMember={() => setIsCreateMemberDialogOpen(true)}
              onUpdateMember={(member) => {
                setSelectedMember(member);
                setIsUpdateMemberDialogOpen(true);
              }}
              onRemoveMember={handleRemoveMember}
              isCoach={true}
            />
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>No Team Created</CardTitle>
            <CardDescription>
              You haven't created a team yet. Create a team to manage your team
              members.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex justify-center py-12">
            <Dialog
              open={isCreateDialogOpen}
              onOpenChange={setIsCreateDialogOpen}
            >
              <DialogTrigger asChild>
                <Button size="lg" className="flex items-center gap-2">
                  <Plus className="h-5 w-5" /> Create Your Team
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogTitle>Create a New Team</DialogTitle>
                <TeamForm
                  onSubmit={handleCreateTeam}
                  isLoading={createTeam.isPending}
                />
              </DialogContent>
            </Dialog>
          </CardContent>
        </Card>
      )}

      {/* Team Member Dialogs */}
      {team && (
        <>
          <Dialog
            open={isCreateMemberDialogOpen}
            onOpenChange={setIsCreateMemberDialogOpen}
          >
            <DialogContent>
              <DialogTitle>Create New Team Member</DialogTitle>
              <CreateTeamMemberForm
                teamId={team.id}
                onSuccess={() => setIsCreateMemberDialogOpen(false)}
              />
            </DialogContent>
          </Dialog>

          {/* Update Member Dialog */}
          <Dialog
            open={isUpdateMemberDialogOpen && selectedMember !== null}
            onOpenChange={(open) => {
              if (!open) {
                setIsUpdateMemberDialogOpen(false);
                setSelectedMember(null);
              }
            }}
          >
            <DialogContent>
              <DialogTitle>Update Team Member</DialogTitle>
              {selectedMember && (
                <UpdateTeamMemberForm
                  teamId={team.id}
                  member={selectedMember}
                  onSuccess={() => {
                    setIsUpdateMemberDialogOpen(false);
                    setSelectedMember(null);
                  }}
                />
              )}
            </DialogContent>
          </Dialog>
        </>
      )}
    </div>
  );
}
