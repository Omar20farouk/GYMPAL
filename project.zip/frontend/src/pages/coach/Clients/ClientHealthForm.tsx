import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Search, Calendar } from "lucide-react";
import useGetClientHealthForms from "@/services/health-form/list";
import { format } from "date-fns";
import { FitnessGoal, HealthForm } from "@/types/health-form";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const ClientHealthFormPage = () => {
  const { clientId } = useParams<{ clientId: string }>();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedForm, setSelectedForm] = useState<HealthForm | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);

  const {
    data: healthForms,
    isLoading,
    error,
  } = useGetClientHealthForms(clientId || "");

  const goBack = () => navigate(-1);

  const formatFitnessGoal = (goal: FitnessGoal) => {
    return goal
      .split("_")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join(" ");
  };

  const handleFormClick = (form: HealthForm) => {
    setSelectedForm(form);
    setDialogOpen(true);
  };

  const filteredForms = healthForms
    ? healthForms.filter((form: HealthForm) => {
        const searchLower = searchQuery.toLowerCase();
        return (
          form.plan?.name?.toLowerCase().includes(searchLower) ||
          form.fitnessGoal.toLowerCase().includes(searchLower) ||
          (form.chronicDiseases || "").toLowerCase().includes(searchLower)
        );
      })
    : [];

  if (error) {
    return (
      <div className="space-y-4">
        <Button
          variant="ghost"
          onClick={goBack}
          className="flex items-center gap-2"
        >
          <ArrowLeft className="h-4 w-4" /> Back to Clients
        </Button>
        <Card>
          <CardContent className="pt-6">
            <div className="text-red-500">
              {(error as Error)?.message ||
                "Failed to load health form details. This client may not have any health forms associated with your plans."}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const renderHealthFormDialog = () => {
    if (!selectedForm) return null;

    return (
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Health Form Details</DialogTitle>
          </DialogHeader>
          <div className="grid gap-6 md:grid-cols-2 mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Basic Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Height</p>
                    <p className="font-medium">{selectedForm.height}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Weight</p>
                    <p className="font-medium">{selectedForm.weight}</p>
                  </div>
                </div>

                <div>
                  <p className="text-sm text-muted-foreground">Fitness Goal</p>
                  <Badge variant="outline" className="mt-1 font-normal">
                    {formatFitnessGoal(selectedForm.fitnessGoal)}
                  </Badge>
                </div>

                <div>
                  <p className="text-sm text-muted-foreground">Favorite Food</p>
                  <p className="font-medium">
                    {selectedForm.favoriteFood || "Not specified"}
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Health Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground">
                    Chronic Diseases
                  </p>
                  <p className="font-medium">
                    {selectedForm.chronicDiseases || "None"}
                  </p>
                </div>

                <div>
                  <p className="text-sm text-muted-foreground">
                    Has Disability
                  </p>
                  <p className="font-medium">
                    {selectedForm.hasDisability ? "Yes" : "No"}
                  </p>
                </div>

                {selectedForm.hasDisability && (
                  <div>
                    <p className="text-sm text-muted-foreground">
                      Disability Details
                    </p>
                    <p className="font-medium">
                      {selectedForm.disabilityDetails || "Not specified"}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>Plan Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Plan</p>
                    <p className="font-medium">
                      {selectedForm.plan?.name || "Unknown Plan"}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">
                      Submitted On
                    </p>
                    <p className="font-medium">
                      {format(new Date(selectedForm.createdAt), "PPP")}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </DialogContent>
      </Dialog>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Client Health Forms</h1>
        <Button
          variant="ghost"
          onClick={goBack}
          className="flex items-center gap-2"
        >
          <ArrowLeft className="h-4 w-4" /> Back to Clients
        </Button>
      </div>

      {isLoading ? (
        <Card>
          <CardContent className="pt-6">
            <div className="space-y-4">
              <Skeleton className="h-8 w-1/3" />
              <Skeleton className="h-24 w-full" />
              <Skeleton className="h-8 w-2/3" />
              <Skeleton className="h-8 w-1/2" />
            </div>
          </CardContent>
        </Card>
      ) : healthForms && healthForms.length > 0 ? (
        <>
          <div className="relative mb-4">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
            <Input
              type="text"
              placeholder="Search health forms..."
              className="pl-9 pr-4 w-full max-w-sm"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Health Forms List</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>#</TableHead>
                    <TableHead>Plan</TableHead>
                    <TableHead>Fitness Goal</TableHead>
                    <TableHead>Submitted On</TableHead>
                    <TableHead>Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredForms.length === 0 ? (
                    <TableRow>
                      <TableCell
                        colSpan={5}
                        className="text-center text-muted-foreground py-6"
                      >
                        {searchQuery
                          ? "No matching health forms found"
                          : "No health forms available"}
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredForms.map((form: HealthForm, index: number) => (
                      <TableRow key={form.id}>
                        <TableCell>{index + 1}</TableCell>
                        <TableCell>
                          {form.plan?.name || "Unknown Plan"}
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">
                            {formatFitnessGoal(form.fitnessGoal)}
                          </Badge>
                        </TableCell>
                        <TableCell className="font-medium">
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4 text-muted-foreground" />
                            {format(new Date(form.createdAt), "PP")}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleFormClick(form)}
                          >
                            View Details
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          {renderHealthFormDialog()}
        </>
      ) : (
        <Card>
          <CardContent className="pt-6">
            <div className="text-center text-muted-foreground py-8">
              No health forms found for this client.
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default ClientHealthFormPage;
