import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Search, MessageSquare } from "lucide-react";
import { useNavigate } from "react-router-dom";
import useCoachClients from "@/services/coaches/clients";
import { formatDistanceToNow } from "date-fns";

const ClientsPage = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const { data, isLoading, error } = useCoachClients();
  const navigate = useNavigate();

  if (error) {
    return <div className="text-red-500">Error loading client data</div>;
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800";
      case "expired":
        return "bg-orange-100 text-orange-800";
      case "cancelled":
        return "bg-red-100 text-red-800";
      case "none":
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((part) => part[0])
      .join("")
      .toUpperCase();
  };

  const filteredClients = data?.filter(
    (client) =>
      client.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      client.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleChatWithClient = (clientId: string) => {
    navigate(`/coach/chat/${clientId}`);
  };

  const handleViewHealthForm = (clientId: string) => {
    navigate(`/coach/clients/${clientId}/health-form`);
  };

  return (
    <>
      <h1 className="text-2xl font-bold mb-6">My Clients</h1>

      <div className="flex justify-between items-center mb-6">
        <div className="relative max-w-md">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
          <Input
            type="text"
            placeholder="Search clients..."
            className="pl-9 pr-4"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Client List</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-3">
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Client</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Subscription Status</TableHead>
                  <TableHead>Plan</TableHead>
                  <TableHead>Last Interaction</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredClients?.length === 0 ? (
                  <TableRow>
                    <TableCell
                      colSpan={6}
                      className="text-center text-gray-500 py-6"
                    >
                      No clients found
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredClients?.map((client) => (
                    <TableRow key={client.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar>
                            <AvatarImage
                              src={client.avatar}
                              alt={client.name}
                            />
                            <AvatarFallback>
                              {getInitials(client.name)}
                            </AvatarFallback>
                          </Avatar>
                          <span
                            className="font-medium cursor-pointer hover:text-primary hover:underline"
                            onClick={() => handleViewHealthForm(client.id)}
                          >
                            {client.name}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>{client.email}</TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={getStatusColor(client.subscriptionStatus)}
                        >
                          {client.subscriptionStatus}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {client.subscriptionPlan || "No active plan"}
                      </TableCell>
                      <TableCell>
                        {client.lastInteraction
                          ? `${formatDistanceToNow(
                              new Date(client.lastInteraction)
                            )} ago`
                          : "Never"}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            className="flex items-center gap-1"
                            onClick={() => handleChatWithClient(client.id)}
                          >
                            <MessageSquare className="h-4 w-4" />
                            <span>Chat</span>
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleViewHealthForm(client.id)}
                          >
                            View Health Form
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </>
  );
};

export default ClientsPage;
