import { useEffect, useState, useRef } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { Textarea } from "@/components/ui/textarea";
import {
  useGetProfile,
  useUpdateCoachProfile,
} from "@/services/profile/profile";
import { Spinner } from "@/components/ui/spinner";
import { CoachProfileInfo } from "@/components/coaches/CoachProfileInfo";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import useUploadImage from "@/services/uploads/uploadImage";
import { Camera, ImageIcon } from "lucide-react";
import ImageUploader from "@/components/image-uploader";

const coachProfileSchema = z.object({
  firstName: z
    .string()
    .min(2, { message: "First name must be at least 2 characters" }),
  lastName: z
    .string()
    .min(2, { message: "Last name must be at least 2 characters" }),
  city: z.string().min(2, { message: "City must be at least 2 characters" }),
  experience: z.coerce
    .number()
    .min(0, { message: "Experience must be a positive number" }),
  about: z.string().optional(),
  profilePicture: z.string().optional(),
  coverPicture: z.string().optional(),
});

type CoachProfileValues = z.infer<typeof coachProfileSchema>;

export default function CoachProfilePage() {
  const { toast } = useToast();

  const { data: profile, isLoading } = useGetProfile();
  const { mutate: updateProfile, isPending: isUpdating } =
    useUpdateCoachProfile();

  const [uploadingProfileImage, setUploadingProfileImage] = useState(false);
  const [uploadingCoverImage, setUploadingCoverImage] = useState(false);

  const form = useForm<CoachProfileValues>({
    resolver: zodResolver(coachProfileSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      city: "",
      experience: 0,
      about: "",
      profilePicture: "",
      coverPicture: "",
    },
  });

  useEffect(() => {
    if (profile && profile.coach) {
      form.reset({
        firstName: profile.firstName,
        lastName: profile.lastName,
        city: profile.city,
        experience: profile.coach.experience,
        about: profile.coach.about || "",
        profilePicture: profile.coach.profilePicture || "",
        coverPicture: profile.coach.coverPicture || "",
      });
    }
  }, [profile, form]);

  function onSubmit(values: CoachProfileValues) {
    updateProfile(values, {
      onSuccess: () => {
        toast({
          title: "Profile updated",
          description: "Your profile has been updated successfully.",
        });
      },
      onError: () => {
        toast({
          title: "Error",
          description:
            "An error occurred while updating your profile. Please try again.",
          variant: "destructive",
        });
      },
    });
  }

  // Handle profile image upload
  const handleProfileImageUpload = (url: string) => {
    setUploadingProfileImage(true);
    const currentValues = form.getValues();
    updateProfile(
      { ...currentValues, profilePicture: url },
      {
        onSuccess: () => {
          toast({
            title: "Profile image updated",
            description: "Your profile image has been updated successfully.",
          });
          setUploadingProfileImage(false);
        },
        onError: () => {
          toast({
            title: "Error",
            description: "An error occurred while updating your profile image.",
            variant: "destructive",
          });
          setUploadingProfileImage(false);
        },
      }
    );
  };

  // Handle cover image upload
  const handleCoverImageUpload = (url: string) => {
    setUploadingCoverImage(true);
    const currentValues = form.getValues();
    updateProfile(
      { ...currentValues, coverPicture: url },
      {
        onSuccess: () => {
          toast({
            title: "Cover image updated",
            description: "Your cover image has been updated successfully.",
          });
          setUploadingCoverImage(false);
        },
        onError: () => {
          toast({
            title: "Error",
            description: "An error occurred while updating your cover image.",
            variant: "destructive",
          });
          setUploadingCoverImage(false);
        },
      }
    );
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Spinner size="lg" />
      </div>
    );
  }

  return (
    <div className="container py-10">
      <h1 className="text-3xl font-bold mb-8">My Profile</h1>

      {/* Cover image */}
      <ImageUploader
        type="cover"
        currentImage={profile?.coach?.coverPicture || undefined}
        onUpload={handleCoverImageUpload}
        className="mb-6"
      />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2">
          <div className="flex items-center mb-6">
            <ImageUploader
              currentImage={profile?.coach?.profilePicture || undefined}
              onUpload={handleProfileImageUpload}
              className="mr-4"
            />
            <div>
              <h2 className="text-xl font-semibold">
                {profile?.firstName} {profile?.lastName}
              </h2>
              <p className="text-muted-foreground">{profile?.city}</p>
            </div>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Profile Information</CardTitle>
              <CardDescription>
                Update your personal information
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form
                  onSubmit={form.handleSubmit(onSubmit)}
                  className="space-y-6"
                >
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="firstName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>First Name</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="lastName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Last Name</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="city"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>City</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input value={profile?.email || ""} disabled />
                      </FormControl>
                    </FormItem>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="experience"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Years of Experience</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="about"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>About</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Tell your clients about yourself, your qualifications, and your coaching philosophy."
                            className="resize-none h-32"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Hidden fields for images */}
                  <FormField
                    control={form.control}
                    name="profilePicture"
                    render={({ field }) => <input type="hidden" {...field} />}
                  />
                  <FormField
                    control={form.control}
                    name="coverPicture"
                    render={({ field }) => <input type="hidden" {...field} />}
                  />

                  <Button type="submit" disabled={isUpdating}>
                    {isUpdating ? <Spinner className="mr-2" size="sm" /> : null}
                    Save Changes
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>

        <div>
          {profile?.coach && <CoachProfileInfo coach={profile.coach} />}
        </div>
      </div>
    </div>
  );
}
