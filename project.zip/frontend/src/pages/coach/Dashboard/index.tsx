import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DollarSign, Users, FileText } from "lucide-react";
import useGetCoachDashboardStats from "@/services/coach/get-dashboard-stats";
import { formatDistanceToNow } from "date-fns";
import { Skeleton } from "@/components/ui/skeleton";

const CoachDashboard = () => {
  const { data, isLoading } = useGetCoachDashboardStats();

  if (isLoading) {
    return <DashboardSkeleton />;
  }

  return (
    <>
      <h1 className="text-2xl font-bold mb-6">Coach Dashboard</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {/* Stats Cards */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Clients</CardTitle>
            <Users className="h-4 w-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data?.totalClients || 0}</div>
            {/* We could add client growth here if we had that data */}
            <p className="text-xs text-gray-500 mt-1">From all subscriptions</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Active Plans</CardTitle>
            <FileText className="h-4 w-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data?.activePlans || 0}</div>
            <p className="text-xs text-gray-500 mt-1">Available to clients</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">
              Monthly Earnings
            </CardTitle>
            <DollarSign className="h-4 w-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              ${data?.monthlyEarnings.toFixed(2) || "0.00"}
            </div>
            <p className="text-xs text-gray-500 mt-1">
              {data?.earningsGrowth !== undefined
                ? `${data.earningsGrowth >= 0 ? "+" : ""}${
                    data.earningsGrowth
                  }% from last month`
                : "No previous data"}
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Recent Clients */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Subscriptions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {data?.recentClients && data.recentClients.length > 0 ? (
                data.recentClients.map((client) => (
                  <div className="flex items-center" key={client.id}>
                    <div className="w-10 h-10 rounded-full bg-gray-200 mr-3 flex items-center justify-center">
                      {client.initials}
                    </div>
                    <div>
                      <div className="font-medium">{client.name}</div>
                      <div className="text-sm text-gray-500">
                        {client.planName} • Started{" "}
                        {formatDistanceToNow(new Date(client.startDate), {
                          addSuffix: true,
                        })}
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-sm text-gray-500">No recent clients</div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Recent Messages */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Messages</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {data?.recentMessages && data.recentMessages.length > 0 ? (
                data.recentMessages.map((message) => (
                  <div className="bg-gray-50 p-3 rounded-md" key={message.id}>
                    <div className="flex justify-between mb-1">
                      <div className="font-medium">{message.clientName}</div>
                      <div className="text-xs text-gray-500">
                        {formatDistanceToNow(new Date(message.sentAt), {
                          addSuffix: true,
                        })}
                      </div>
                    </div>
                    <p className="text-sm">{message.content}</p>
                  </div>
                ))
              ) : (
                <div className="text-sm text-gray-500">No recent messages</div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
};

const DashboardSkeleton = () => (
  <>
    <h1 className="text-2xl font-bold mb-6">Coach Dashboard</h1>

    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
      {[1, 2, 3].map((i) => (
        <Card key={i}>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <Skeleton className="h-4 w-24" />
            <Skeleton className="h-4 w-4" />
          </CardHeader>
          <CardContent>
            <Skeleton className="h-8 w-16 mb-2" />
            <Skeleton className="h-3 w-24" />
          </CardContent>
        </Card>
      ))}
    </div>

    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {[1, 2].map((i) => (
        <Card key={i}>
          <CardHeader>
            <Skeleton className="h-6 w-32" />
          </CardHeader>
          <CardContent>
            {[1, 2, 3].map((j) => (
              <div className="flex items-center mb-4" key={j}>
                <Skeleton className="w-10 h-10 rounded-full mr-3" />
                <div className="space-y-2">
                  <Skeleton className="h-4 w-32" />
                  <Skeleton className="h-3 w-48" />
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      ))}
    </div>
  </>
);

export default CoachDashboard;
