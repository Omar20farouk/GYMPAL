import { useState } from "react";

import {
  DollarSign,
  Plus,
  MoreVertical,
  Edit,
  Trash,
  CalendarDays,
  CheckCircle,
  ListChecks,
} from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

import useCreatePlan from "@/services/plans/create";
import useUpdatePlan from "@/services/plans/update";
import useGetPlans from "@/services/plans/list";
import useDeletePlan from "@/services/plans/delete";
import { Plan } from "@/types/plans";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const planFormSchema = z.object({
  name: z.string().min(1, "Plan name is required"),
  description: z.string().min(1, "Description is required"),
  price: z.coerce.number().positive("Price must be positive"),
  duration: z.coerce.number().min(1, "Duration is required"),
  durationUnit: z.enum(["day", "week", "month"], {
    message: "Duration unit is required",
  }),
  features: z.string().min(1, "Features are required"),
});

type PlanFormValues = z.infer<typeof planFormSchema>;

const Plans = () => {
  const { data: plans } = useGetPlans();
  const createPlan = useCreatePlan();
  const updatePlan = useUpdatePlan();
  const deletePlan = useDeletePlan();

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [currentPlan, setCurrentPlan] = useState<Plan | null>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);

  const form = useForm<PlanFormValues>({
    resolver: zodResolver(planFormSchema),
    defaultValues: {
      name: "",
      description: "",
      price: 0,
      duration: 0,
      durationUnit: "month",
      features: "",
    },
  });

  const handleEdit = (plan: Plan) => {
    setCurrentPlan(plan);
    form.reset({
      name: plan.name,
      description: plan.description,
      price: plan.price,
      duration: plan.duration,
      durationUnit: plan.durationUnit,
      features: plan.features.join("\n"),
    });
    setIsDialogOpen(true);
  };

  const handleCreate = () => {
    setCurrentPlan(null);
    form.reset({
      name: "",
      description: "",
      price: 0,
      duration: 0,
      durationUnit: "month",
      features: "",
    });
    setIsDialogOpen(true);
  };

  const handleDeleteClick = (plan: Plan) => {
    setCurrentPlan(plan);
    setIsDeleteDialogOpen(true);
  };

  const handleDelete = async () => {
    if (currentPlan) {
      await deletePlan(currentPlan.id);
      setIsDeleteDialogOpen(false);
    }
  };

  const onSubmit = async (values: PlanFormValues) => {
    const features = values.features.split("\n").filter(Boolean);

    if (currentPlan) {
      await updatePlan({
        planId: currentPlan.id,
        data: {
          ...values,
          features,
        },
      });
    } else {
      await createPlan({
        ...values,
        features,
      });
    }
    setIsDialogOpen(false);
  };

  return (
    <>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">My Plans</h1>
        <Button onClick={handleCreate}>
          <Plus className="mr-2" size={16} />
          Add New Plan
        </Button>
      </div>

      {plans?.length === 0 ? (
        <div className="text-center py-12">
          <h3 className="text-lg font-medium text-gray-500 mb-4">
            You don't have any plans yet
          </h3>
          <Button onClick={handleCreate}>
            <Plus className="mr-2" size={16} />
            Create Your First Plan
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {plans?.map((plan) => (
            <Card key={plan.id} className="flex flex-col">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <CardTitle>{plan.name}</CardTitle>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreVertical size={16} />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuLabel>Actions</DropdownMenuLabel>
                      <DropdownMenuItem onClick={() => handleEdit(plan)}>
                        <Edit className="mr-2" size={16} />
                        Edit
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => handleDeleteClick(plan)}
                        className="text-red-600"
                      >
                        <Trash className="mr-2" size={16} />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
                <CardDescription>{plan.description}</CardDescription>
              </CardHeader>
              <CardContent className="flex-1">
                <div className="flex items-center gap-2 mb-4">
                  <DollarSign className="text-green-600" size={18} />
                  <span className="text-lg font-bold">${plan.price}</span>
                </div>
                <div className="flex items-center gap-2 mb-4">
                  <CalendarDays className="text-blue-600" size={18} />
                  <span>
                    {plan.duration}{" "}
                    {plan.duration > 1
                      ? plan.durationUnit + "s"
                      : plan.durationUnit}
                  </span>
                </div>
                <div className="mt-3">
                  <div className="flex items-center gap-2 mb-2">
                    <ListChecks size={18} />
                    <h4 className="font-medium">Features</h4>
                  </div>
                  <ul className="space-y-2">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <CheckCircle
                          size={16}
                          className="text-green-500 mt-0.5"
                        />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Create/Edit Plan Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>
              {currentPlan ? "Edit Plan" : "Create New Plan"}
            </DialogTitle>
            <DialogDescription>
              {currentPlan
                ? "Make changes to your plan here. Click save when you're done."
                : "Fill in the details below to create a new plan for your clients."}
            </DialogDescription>
          </DialogHeader>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Plan Name</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. Basic Fitness Plan" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Brief description of what this plan offers"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="price"
                render={({ field }) => (
                  <FormItem className="flex-1">
                    <FormLabel>Price ($)</FormLabel>
                    <FormControl>
                      <Input type="number" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex gap-4">
                <FormField
                  control={form.control}
                  name="duration"
                  render={({ field }) => (
                    <FormItem className="flex-1">
                      <FormLabel>Duration</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. 1" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="durationUnit"
                  render={({ field }) => (
                    <FormItem className="flex-1">
                      <FormLabel>Duration Unit</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a duration unit" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="day">Days</SelectItem>
                          <SelectItem value="week">Weeks</SelectItem>
                          <SelectItem value="month">Months</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="features"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Features (one per line)</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Weekly workout plan&#10;Bi-weekly check-ins&#10;Basic nutrition guide"
                        className="min-h-[120px]"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <DialogFooter>
                <Button type="submit">
                  {currentPlan ? "Save Changes" : "Create Plan"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete "{currentPlan?.name}"? This action
              cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex justify-between">
            <Button
              variant="outline"
              onClick={() => setIsDeleteDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDelete}>
              Delete Plan
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default Plans;
