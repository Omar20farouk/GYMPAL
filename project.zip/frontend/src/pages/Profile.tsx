import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuthStore } from "@/store/authStore";
import { Spinner } from "@/components/ui/spinner";

export default function Profile() {
  const navigate = useNavigate();
  const { user } = useAuthStore();

  useEffect(() => {
    if (user) {
      if (user.role === "CLIENT") {
        navigate("/client/profile");
      } else if (user.role === "COACH") {
        navigate("/coach/profile");
      } else if (user.role === "ADMIN") {
        navigate("/admin/dashboard");
      }
    }
  }, [user, navigate]);

  return (
    <div className="flex items-center justify-center h-96">
      <Spinner size="lg" />
    </div>
  );
}
