import { useParams, useNavigate } from "react-router-dom";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Spinner } from "@/components/ui/spinner";
import { ArrowLeft, Trash } from "lucide-react";
import {
  useGetTeam,
  useUpdateTeamMember,
  useRemoveTeamMember,
  useGetCoachClientsByTeam,
} from "@/services/teams";
import { useGetProfile } from "@/services/profile/profile";
import { TeamMembersList } from "@/components/teams/TeamMembersList";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ClientsList } from "@/components/teams/ClientsList";
import { useState } from "react";
import { UpdateTeamMemberForm } from "@/components/teams/UpdateTeamMemberForm";
import { TeamMember } from "@/types/team";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { CreateTeamMemberForm } from "@/components/teams/CreateTeamMemberForm";

export default function TeamDetails() {
  const navigate = useNavigate();
  const { teamId } = useParams<{ teamId: string }>();
  const { data: team, isLoading: isLoadingTeam } = useGetTeam(teamId || "");
  const { data: profile, isLoading: isLoadingProfile } = useGetProfile();
  const {
    data: clients,
    isLoading: isLoadingClients,
    error: clientsError,
  } = useGetCoachClientsByTeam(teamId || "");

  const isCoach =
    profile?.role === "COACH" && team?.coach?.userId === profile?.id;
  const isTeamMember = profile?.role === "TEAM_MEMBER";

  const [isCreatingMember, setIsCreatingMember] = useState(false);
  const [memberToUpdate, setMemberToUpdate] = useState<TeamMember | null>(null);
  const [memberToRemove, setMemberToRemove] = useState<TeamMember | null>(null);

  const removeTeamMember = useRemoveTeamMember();

  const getInitials = (firstName: string, lastName: string) => {
    return `${firstName?.[0] || ""}${lastName?.[0] || ""}`.toUpperCase();
  };

  const handleCreateMember = () => {
    setIsCreatingMember(true);
  };

  const handleUpdateMember = (member: TeamMember) => {
    setMemberToUpdate(member);
  };

  const handleRemoveMember = (member: TeamMember) => {
    setMemberToRemove(member);
  };

  const confirmRemoveMember = () => {
    if (memberToRemove && teamId) {
      removeTeamMember.mutate(
        { teamId, memberId: memberToRemove.id },
        {
          onSuccess: () => {
            setMemberToRemove(null);
          },
        }
      );
    }
  };

  if (isLoadingTeam || isLoadingProfile) {
    return (
      <div className="flex justify-center items-center h-[500px]">
        <Spinner size="lg" />
      </div>
    );
  }

  if (!team) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold mb-2">Team Not Found</h2>
        <p className="text-muted-foreground mb-4">
          The team you're looking for doesn't exist or you don't have permission
          to view it.
        </p>
        <Button onClick={() => navigate(-1)}>Go Back</Button>
      </div>
    );
  }

  return (
    <div className="container py-8">
      <Button
        variant="ghost"
        onClick={() => navigate(-1)}
        className="mb-6 flex items-center gap-1"
      >
        <ArrowLeft className="h-4 w-4" /> Back
      </Button>

      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">{team.name}</CardTitle>
          {team.description && (
            <CardDescription className="mt-2">
              {team.description}
            </CardDescription>
          )}

          <div className="flex items-center gap-3 mt-4 pt-4 border-t">
            <Avatar className="h-10 w-10">
              <AvatarFallback>
                {getInitials(
                  team.coach.user.firstName,
                  team.coach.user.lastName
                )}
              </AvatarFallback>
            </Avatar>
            <div>
              <p className="font-medium">
                {team.coach.user.firstName} {team.coach.user.lastName}
              </p>
              <p className="text-sm text-muted-foreground">Coach</p>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs
            defaultValue={isTeamMember ? "clients" : "members"}
            className="w-full"
          >
            <TabsList className="mb-6">
              {!isTeamMember && (
                <TabsTrigger value="members">Team Members</TabsTrigger>
              )}
              <TabsTrigger value="clients">Coach Clients</TabsTrigger>
            </TabsList>

            {!isTeamMember && (
              <TabsContent value="members">
                <TeamMembersList
                  members={team.members || []}
                  onCreateMember={handleCreateMember}
                  onUpdateMember={handleUpdateMember}
                  onRemoveMember={handleRemoveMember}
                  isCoach={isCoach}
                />
              </TabsContent>
            )}

            <TabsContent value="clients">
              <ClientsList
                clients={clients || []}
                isLoading={isLoadingClients}
                error={clientsError}
              />
            </TabsContent>
          </Tabs>

          {/* Create Member Dialog */}
          <Dialog open={isCreatingMember} onOpenChange={setIsCreatingMember}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Team Member</DialogTitle>
                <DialogDescription>
                  Create a new user account and add them to your team.
                </DialogDescription>
              </DialogHeader>

              <CreateTeamMemberForm
                teamId={team.id}
                onSuccess={() => setIsCreatingMember(false)}
              />
            </DialogContent>
          </Dialog>

          {/* Update Member Dialog */}
          <Dialog
            open={!!memberToUpdate}
            onOpenChange={(open) => !open && setMemberToUpdate(null)}
          >
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Update Team Member</DialogTitle>
                <DialogDescription>
                  Update the role and position of this team member.
                </DialogDescription>
              </DialogHeader>

              {memberToUpdate && (
                <UpdateTeamMemberForm
                  teamId={team.id}
                  member={memberToUpdate}
                  onSuccess={() => setMemberToUpdate(null)}
                />
              )}
            </DialogContent>
          </Dialog>

          {/* Remove Member Dialog */}
          <Dialog
            open={!!memberToRemove}
            onOpenChange={(open) => !open && setMemberToRemove(null)}
          >
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Remove Team Member</DialogTitle>
                <DialogDescription>
                  Are you sure you want to remove this member from your team?
                </DialogDescription>
              </DialogHeader>

              {memberToRemove && (
                <div className="py-4">
                  <p>
                    You are about to remove{" "}
                    <span className="font-medium">
                      {memberToRemove.user.firstName}{" "}
                      {memberToRemove.user.lastName}
                    </span>{" "}
                    from your team.
                  </p>
                </div>
              )}

              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={() => setMemberToRemove(null)}
                >
                  Cancel
                </Button>
                <Button
                  variant="destructive"
                  onClick={confirmRemoveMember}
                  disabled={removeTeamMember.isPending}
                >
                  {removeTeamMember.isPending ? (
                    <Spinner className="mr-2" size="sm" />
                  ) : (
                    <Trash className="h-4 w-4 mr-2" />
                  )}
                  Remove
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </CardContent>
      </Card>
    </div>
  );
}
