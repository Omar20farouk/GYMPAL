import { useEffect, useState } from "react";
import { useGetProfile } from "@/services/profile/profile";
import { Skeleton } from "@/components/ui/skeleton";
import { ClientsList } from "@/components/teams/ClientsList";
import { useGetCoachClientsByTeam } from "@/services/teams";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";

export default function ClientsPage() {
  const { data: profile, isLoading: isLoadingProfile } = useGetProfile();
  const [teamId, setTeamId] = useState<string | null>(null);
  const navigate = useNavigate();

  const {
    data: clients,
    isLoading: isLoadingClients,
    error: clientsError,
  } = useGetCoachClientsByTeam(teamId || "");

  useEffect(() => {
    if (profile?.teamMember?.teamId) {
      setTeamId(profile.teamMember.teamId);
    }
  }, [profile]);

  if (isLoadingProfile || isLoadingClients) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-12 w-1/3" />
        <Skeleton className="h-[500px]" />
      </div>
    );
  }

  if (!teamId) {
    return (
      <Card className="mt-8">
        <CardHeader>
          <CardTitle>Team Not Found</CardTitle>
          <CardDescription>
            You don't seem to be associated with any team.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Button onClick={() => navigate("/team-member/dashboard")}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Dashboard
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Coach Clients</h1>
        <Button
          variant="outline"
          onClick={() => navigate("/team-member/dashboard")}
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Dashboard
        </Button>
      </div>

      <Card>
        <CardContent className="pt-6">
          <ClientsList
            clients={clients || []}
            isLoading={isLoadingClients}
            error={clientsError}
          />
        </CardContent>
      </Card>
    </div>
  );
}
