import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { useGetProfile } from "@/services/profile/profile";
import { Skeleton } from "@/components/ui/skeleton";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowUpRight } from "lucide-react";
import { useEffect, useState } from "react";

export default function TeamMemberDashboard() {
  const { data: profile, isLoading } = useGetProfile();
  const navigate = useNavigate();
  const [teamId, setTeamId] = useState<string | null>(null);

  useEffect(() => {
    if (profile?.teamMember?.teamId) {
      setTeamId(profile.teamMember.teamId);
    }
  }, [profile]);

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-12 w-1/3" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Skeleton className="h-40" />
          <Skeleton className="h-40" />
          <Skeleton className="h-40" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Welcome, {profile?.firstName}!</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-xl">Coach Clients</CardTitle>
            <CardDescription>View and manage all coach clients</CardDescription>
          </CardHeader>
          <CardContent>
            <Button
              className="w-full mt-2"
              onClick={() => navigate("/team-member/clients")}
            >
              View Clients
              <ArrowUpRight className="ml-2 h-4 w-4" />
            </Button>
          </CardContent>
        </Card>

        {teamId && (
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-xl">Team Details</CardTitle>
              <CardDescription>View your team information</CardDescription>
            </CardHeader>
            <CardContent>
              <Button
                className="w-full mt-2"
                onClick={() => navigate(`/teams/${teamId}`)}
              >
                View Team
                <ArrowUpRight className="ml-2 h-4 w-4" />
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
