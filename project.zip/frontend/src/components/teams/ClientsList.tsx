import { useState } from "react";
import { ClientWithSubscription } from "@/services/coaches/clients";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, MessageSquare } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { formatDistanceToNow } from "date-fns";

interface ClientsListProps {
  clients: ClientWithSubscription[];
  isLoading: boolean;
  error: Error | null;
}

export function ClientsList({ clients, isLoading, error }: ClientsListProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const navigate = useNavigate();

  if (error) {
    return <div className="text-red-500">Error loading client data</div>;
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800";
      case "expired":
        return "bg-orange-100 text-orange-800";
      case "cancelled":
        return "bg-red-100 text-red-800";
      case "none":
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((part) => part[0])
      .join("")
      .toUpperCase();
  };

  const filteredClients = clients?.filter(
    (client) =>
      client.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      client.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // const handleChatWithClient = (clientId: string) => {
  //   navigate(`/coach/chat/${clientId}`);
  // };

  const handleViewHealthForm = (clientId: string) => {
    navigate(`/team-member/clients/${clientId}/health-form`);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold">Coach Clients</h2>
        <div className="relative w-64">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 h-4 w-4" />
          <Input
            placeholder="Search clients..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {isLoading ? (
        <div className="flex justify-center p-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
        </div>
      ) : (
        <div className="border rounded-md">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Client</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Subscription Status</TableHead>
                <TableHead>Plan</TableHead>
                <TableHead>Last Interaction</TableHead>
                {/* <TableHead>Actions</TableHead> */}
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredClients?.length === 0 ? (
                <TableRow>
                  <TableCell
                    colSpan={6}
                    className="text-center text-gray-500 py-6"
                  >
                    No clients found
                  </TableCell>
                </TableRow>
              ) : (
                filteredClients?.map((client) => (
                  <TableRow key={client.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <Avatar>
                          <AvatarFallback>
                            {getInitials(client.name)}
                          </AvatarFallback>
                        </Avatar>
                        <span
                          className="font-medium cursor-pointer hover:text-primary hover:underline"
                          onClick={() => handleViewHealthForm(client.id)}
                        >
                          {client.name}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>{client.email}</TableCell>
                    <TableCell>
                      <Badge
                        className={getStatusColor(client.subscriptionStatus)}
                        variant="outline"
                      >
                        {client.subscriptionStatus.charAt(0).toUpperCase() +
                          client.subscriptionStatus.slice(1)}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {client.subscriptionPlan || "No active plan"}
                    </TableCell>
                    <TableCell>
                      {client.lastInteraction
                        ? formatDistanceToNow(
                            new Date(client.lastInteraction),
                            {
                              addSuffix: true,
                            }
                          )
                        : "Never"}
                    </TableCell>
                    {/* <TableCell>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleChatWithClient(client.id)}
                        className="flex items-center gap-1"
                      >
                        <MessageSquare className="h-4 w-4" />
                        <span>Chat</span>
                      </Button>
                    </TableCell> */}
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
}
