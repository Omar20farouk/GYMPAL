import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { MoreHorizontal, UserPlus, UserCog } from "lucide-react";
import { TeamMember, TeamMemberRole } from "@/types/team";

type TeamMembersListProps = {
  members: TeamMember[];
  onCreateMember: () => void;
  onUpdateMember: (member: TeamMember) => void;
  onRemoveMember: (member: TeamMember) => void;
  isCoach: boolean;
};

export function TeamMembersList({
  members,
  onUpdateMember,
  onRemoveMember,
  onCreateMember,
  isCoach,
}: TeamMembersListProps) {
  const getInitials = (firstName: string, lastName: string) => {
    return `${firstName?.[0] || ""}${lastName?.[0] || ""}`.toUpperCase();
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Team Members</h3>
        {isCoach && (
          <div>
            <Button
              size="sm"
              className="flex items-center gap-1"
              onClick={onCreateMember}
            >
              <UserCog className="h-4 w-4" /> Create New
            </Button>
          </div>
        )}
      </div>

      {members.length === 0 ? (
        <div className="text-center py-8 text-muted-foreground">
          No team members yet
        </div>
      ) : (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Member</TableHead>
              <TableHead>Role</TableHead>
              <TableHead>Position</TableHead>
              {isCoach && <TableHead className="w-[60px]"></TableHead>}
            </TableRow>
          </TableHeader>
          <TableBody>
            {members.map((member) => (
              <TableRow key={member.id}>
                <TableCell className="flex items-center gap-2">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback>
                      {getInitials(member.user.firstName, member.user.lastName)}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium">
                      {member.user.firstName} {member.user.lastName}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {member.user.email}
                    </p>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge
                    variant={
                      member.role === TeamMemberRole.ADMIN
                        ? "default"
                        : "secondary"
                    }
                  >
                    {member.role}
                  </Badge>
                </TableCell>
                <TableCell>{member.position || "N/A"}</TableCell>
                {isCoach && (
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                          onClick={() => onUpdateMember(member)}
                        >
                          Edit Member
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          className="text-red-600"
                          onClick={() => onRemoveMember(member)}
                        >
                          Remove
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                )}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
    </div>
  );
}
