import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  TeamMember,
  TeamMemberRole,
  UpdateTeamMemberParams,
} from "@/types/team";
import { useUpdateTeamMember } from "@/services/teams";
import { Spinner } from "@/components/ui/spinner";

const formSchema = z.object({
  role: z.nativeEnum(TeamMemberRole),
  position: z.string().max(255).optional(),
});

type UpdateTeamMemberFormProps = {
  teamId: string;
  member: TeamMember;
  onSuccess: () => void;
};

export function UpdateTeamMemberForm({
  teamId,
  member,
  onSuccess,
}: UpdateTeamMemberFormProps) {
  const updateTeamMember = useUpdateTeamMember();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      role: member.role,
      position: member.position || "",
    },
  });

  const handleSubmit = (values: z.infer<typeof formSchema>) => {
    updateTeamMember.mutate(
      {
        teamId,
        memberId: member.id,
        data: values,
      },
      {
        onSuccess: () => {
          onSuccess();
        },
      }
    );
  };

  return (
    <Form {...form}>
      <div className="mb-4">
        <p className="font-medium">
          {member.user.firstName} {member.user.lastName}
        </p>
        <p className="text-sm text-muted-foreground">{member.user.email}</p>
      </div>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="role"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Role</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a role" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value={TeamMemberRole.MEMBER}>Member</SelectItem>
                  <SelectItem value={TeamMemberRole.ADMIN}>Admin</SelectItem>
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="position"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Position (Optional)</FormLabel>
              <FormControl>
                <Input
                  placeholder="E.g., Assistant Coach, Nutritionist"
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <Button
          type="submit"
          className="w-full"
          disabled={updateTeamMember.isPending}
        >
          {updateTeamMember.isPending ? (
            <>
              <Spinner className="mr-2" size="sm" /> Updating...
            </>
          ) : (
            "Update Team Member"
          )}
        </Button>
      </form>
    </Form>
  );
}
