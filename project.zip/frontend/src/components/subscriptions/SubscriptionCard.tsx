import { Subscription } from "@/types/subscription";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";

type SubscriptionCardProps = {
  subscription: Subscription;
};

export function SubscriptionCard({ subscription }: SubscriptionCardProps) {
  const isActive = new Date(subscription.endDate) > new Date();

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-6">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="font-semibold text-lg mb-1">
              {subscription.plan.name}
            </h3>
            <p className="text-sm text-muted-foreground mb-3">
              Coach: {subscription.plan.coach.user.firstName}{" "}
              {subscription.plan.coach.user.lastName}
            </p>
          </div>
          <Badge variant={isActive ? "success" : "destructive"}>
            {isActive ? "Active" : "Expired"}
          </Badge>
        </div>

        <div className="grid grid-cols-2 gap-4 mt-4 text-sm">
          <div>
            <p className="text-muted-foreground">Start Date</p>
            <p className="font-medium">
              {format(new Date(subscription.startDate), "MMM dd, yyyy")}
            </p>
          </div>
          <div>
            <p className="text-muted-foreground">End Date</p>
            <p className="font-medium">
              {format(new Date(subscription.endDate), "MMM dd, yyyy")}
            </p>
          </div>
          <div>
            <p className="text-muted-foreground">Price</p>
            <p className="font-medium">${subscription.plan.price}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Duration</p>
            <p className="font-medium">
              {subscription.plan.duration} {subscription.plan.durationUnit}s
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
