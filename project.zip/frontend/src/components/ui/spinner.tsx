import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const spinnerVariants = cva(
  "animate-spin inline-block border-current border-t-transparent rounded-full",
  {
    variants: {
      size: {
        default: "w-4 h-4 border-2",
        sm: "w-3 h-3 border-2",
        lg: "w-6 h-6 border-2",
        xl: "w-10 h-10 border-3",
      },
    },
    defaultVariants: {
      size: "default",
    },
  }
);

interface SpinnerProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof spinnerVariants> {}

export function Spinner({ className, size, ...props }: SpinnerProps) {
  return (
    <div role="status" {...props}>
      <div className={cn(spinnerVariants({ size }), className)} />
      <span className="sr-only">Loading...</span>
    </div>
  );
}
