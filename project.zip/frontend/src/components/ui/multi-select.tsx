import * as React from "react";

import { X } from "lucide-react";
import { Command as CommandPrimitive } from "cmdk";

import { Badge } from "@/components/ui/badge";
import {
  Command,
  CommandGroup,
  CommandItem,
  CommandList,
} from "@/components/ui/command";

type Option = {
  label: string;
  value: string;
};

type MultiSelectProps = {
  options: Option[];
  id?: string;
  placeholder?: string;
  disabled?: boolean;
  required?: boolean;

  // Form field props from react-hook-form controller
  value?: string[];
  onChange?: (value: string[]) => void;
  onBlur?: () => void;
  name?: string;
};

export function MultiSelect({
  options,
  id,
  placeholder = "Select items...",
  disabled = false,
  required = false,
  value = [],
  onChange,
  onBlur,
  name,
}: MultiSelectProps) {
  const inputRef = React.useRef<HTMLInputElement>(null);
  const [open, setOpen] = React.useState(false);
  const [inputValue, setInputValue] = React.useState("");

  console.log(options);

  // Convert string[] to Option[] for internal use
  const selectedOptions = React.useMemo(() => {
    return options.filter((option) => value.includes(option.value));
  }, [options, value]);

  const handleUnselect = React.useCallback(
    (option: Option) => {
      const newValue = value.filter((v) => v !== option.value);
      onChange?.(newValue);
    },
    [value, onChange]
  );

  const handleSelect = React.useCallback(
    (option: Option) => {
      setInputValue("");
      const newValue = [...value, option.value];
      onChange?.(newValue);
    },
    [onChange, value]
  );

  const handleKeyDown = React.useCallback(
    (e: React.KeyboardEvent<HTMLDivElement>) => {
      const input = inputRef.current;
      if (input) {
        if (e.key === "Delete" || e.key === "Backspace") {
          if (input.value === "" && selectedOptions.length > 0) {
            const newValue = [...value];
            newValue.pop();
            onChange?.(newValue);
          }
        }
        // This is not a default behaviour of the <input /> field
        if (e.key === "Escape") {
          input.blur();
          setOpen(false);
        }
      }
    },
    [onChange, value, selectedOptions.length]
  );

  // Filter out already selected options
  const selectableOptions = options.filter(
    (option) => !value.includes(option.value)
  );

  return (
    <Command
      onKeyDown={handleKeyDown}
      className="overflow-visible bg-transparent"
      filter={(value, search) => {
        if (value.toLowerCase().includes(search.toLowerCase())) return 1;
        return 0;
      }}
    >
      <div
        className={`mt-1 h-auto min-h-10 group rounded-md border border-input px-3 py-2 text-sm ring-offset-background ${
          disabled
            ? "opacity-50 cursor-not-allowed"
            : "focus-within:ring-2 focus-within:ring-ring focus-within:ring-offset-2"
        }`}
      >
        <div className="flex flex-wrap gap-1">
          {selectedOptions.map((option) => {
            return (
              <Badge
                key={option.value}
                variant="secondary"
                className="bg-gray-300"
              >
                {option.label}
                {!disabled && (
                  <button
                    type="button"
                    className="ml-1 rounded-full outline-none ring-offset-background focus:ring-2 focus:ring-ring focus:ring-offset-2"
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        handleUnselect(option);
                      }
                    }}
                    onMouseDown={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                    }}
                    onClick={() => handleUnselect(option)}
                  >
                    <X className="h-3 w-3 text-muted-foreground hover:text-foreground" />
                  </button>
                )}
              </Badge>
            );
          })}
          {/* Avoid having the "Search" Icon */}
          {!disabled && (
            <CommandPrimitive.Input
              ref={inputRef}
              id={id}
              value={inputValue}
              name={name}
              required={required && selectedOptions.length === 0}
              onValueChange={setInputValue}
              onBlur={() => {
                setOpen(false);
                onBlur?.();
              }}
              onFocus={() => setOpen(true)}
              placeholder={selectedOptions.length === 0 ? placeholder : ""}
              className="ml-2 flex-1 bg-transparent outline-none placeholder:text-muted-foreground"
              disabled={disabled}
            />
          )}
        </div>
      </div>
      <div className="relative mt-2">
        <CommandList>
          {open && selectableOptions.length > 0 ? (
            <div className="absolute top-0 z-10 w-full rounded-md border bg-popover text-popover-foreground shadow-md outline-none animate-in">
              <CommandGroup className="h-full overflow-auto">
                {selectableOptions.map((option) => {
                  return (
                    <CommandItem
                      key={option.value}
                      onMouseDown={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                      }}
                      onSelect={() => {
                        handleSelect(option);
                      }}
                      className="cursor-pointer"
                    >
                      {option.label}
                    </CommandItem>
                  );
                })}
              </CommandGroup>
            </div>
          ) : null}
        </CommandList>
      </div>
    </Command>
  );
}
