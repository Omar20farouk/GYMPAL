import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Spinner } from "@/components/ui/spinner";
import { useToast } from "@/hooks/use-toast";
import useUploadImage from "@/services/uploads/uploadImage";
import { Camera, ImageIcon } from "lucide-react";
import { useRef, useState } from "react";

const ImageUploader = ({
  currentImage,
  onUpload,
  type = "profile",
  className = "",
}: {
  currentImage?: string | null;
  onUpload: (url: string) => void;
  type?: "profile" | "cover";
  className?: string;
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const uploadImage = useUploadImage();
  const { toast } = useToast();
  const [uploading, setUploading] = useState(false);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setUploading(true);
      const imageUrl = await uploadImage(file);
      onUpload(imageUrl);
      toast({
        title: "Image uploaded",
        description: "Your image has been uploaded successfully.",
      });
    } catch (error) {
      // Error handling is done in useUploadImage
    } finally {
      setUploading(false);
    }
  };

  const handleClick = () => {
    fileInputRef.current?.click();
  };

  if (type === "cover") {
    return (
      <div
        className={`relative w-full h-48 bg-muted rounded-lg overflow-hidden hover:opacity-90 cursor-pointer ${className}`}
        onClick={handleClick}
      >
        {currentImage ? (
          <img
            src={currentImage}
            alt="Cover"
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <ImageIcon className="h-12 w-12 text-muted-foreground" />
            <span className="ml-2 text-muted-foreground">Add Cover Image</span>
          </div>
        )}
        <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
          <Camera className="h-10 w-10 text-white" />
          {uploading && <Spinner size="lg" className="ml-2" />}
        </div>
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          accept="image/jpeg,image/png,image/gif"
          className="hidden"
        />
      </div>
    );
  }

  return (
    <div className={`relative ${className}`}>
      <Avatar
        className="h-24 w-24 cursor-pointer hover:opacity-90"
        onClick={handleClick}
      >
        <AvatarImage src={currentImage || undefined} />
        <AvatarFallback className="text-2xl">
          {uploading ? <Spinner /> : <Camera className="h-8 w-8" />}
        </AvatarFallback>
      </Avatar>
      <div className="absolute bottom-0 right-0 bg-primary text-primary-foreground rounded-full p-1 shadow-lg cursor-pointer">
        <Camera className="h-4 w-4" />
      </div>
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept="image/jpeg,image/png,image/gif"
        className="hidden"
      />
    </div>
  );
};

export default ImageUploader;
