import { Outlet, useLocation } from "react-router-dom";
import { useAuthStore } from "@/store/authStore";
import { useNavigate, Link } from "react-router-dom";
import {
  UserIcon,
  LogOutIcon,
  HomeIcon,
  DumbbellIcon,
  UsersIcon,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";

const items = [
  {
    to: "/team-member/dashboard",
    icon: <HomeIcon className="w-5 h-5 mr-2" />,
    label: "Dashboard",
  },
  {
    to: "/team-member/clients",
    icon: <UsersIcon className="w-5 h-5 mr-2" />,
    label: "Coach Clients",
  },
];

const TeamMemberLayout = () => {
  const { user, logout } = useAuthStore();
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const { toast } = useToast();

  const handleLogout = () => {
    logout();
    toast({
      title: "Logged out",
      description: "You have been successfully logged out.",
    });
    navigate("/");
  };

  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <aside className="hidden md:fixed md:flex flex-col w-64 h-screen bg-white border-r z-40">
        <div className="p-4 border-b">
          <Link
            to="/team-member/dashboard"
            className="flex items-center space-x-2"
          >
            <DumbbellIcon className="w-6 h-6 text-gym-blue" />
            <span className="font-bold text-lg">GYMPAL</span>
          </Link>
        </div>

        <nav className="flex-1 pt-4 px-2">
          <div className="space-y-1">
            {items.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "flex items-center rounded-md px-3 py-2 text-gray-700 hover:bg-gym-blue/10 hover:text-gym-blue",
                  pathname === item.to && "bg-gym-blue/10 text-gym-blue"
                )}
              >
                {item.icon}
                <span>{item.label}</span>
              </Link>
            ))}
          </div>
        </nav>

        <div className="border-t p-4">
          <Button
            variant="outline"
            className="w-full justify-start text-left"
            onClick={handleLogout}
          >
            <LogOutIcon className="w-4 h-4 mr-2" />
            <span>Logout</span>
          </Button>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col md:pl-64">
        {/* Header */}
        <header className="bg-white border-b sticky top-0 z-30 shadow-sm h-16 flex items-center px-4">
          <div className="flex md:hidden">
            <Button variant="ghost" size="icon">
              <HomeIcon className="w-5 h-5" />
            </Button>
          </div>

          <div className="flex-1"></div>

          <div className="flex items-center space-x-4">
            {/* User dropdown */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center space-x-2">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gym-blue/10">
                    <UserIcon className="h-4 w-4 text-gym-blue" />
                  </div>
                  <span className="hidden md:inline-flex">
                    {user?.firstName} {user?.lastName}
                  </span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <div className="flex items-center justify-start gap-2 p-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gym-blue/10">
                    <UserIcon className="h-5 w-5 text-gym-blue" />
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm font-medium leading-none">
                      {user?.firstName} {user?.lastName}
                    </p>
                    <p className="text-xs leading-none text-gray-500">
                      {user?.email}
                    </p>
                  </div>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  className="text-red-600"
                  onClick={handleLogout}
                >
                  <LogOutIcon className="w-4 h-4 mr-2" />
                  <span>Logout</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 bg-gray-50 overflow-auto p-6 h-[calc(100vh-4rem)]">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default TeamMemberLayout;
