import { Outlet } from "react-router-dom";
import { useAuthStore } from "@/store/authStore";
import { useNavigate, Link } from "react-router-dom";
import {
  LogOutIcon,
  HomeIcon,
  DumbbellIcon,
  ShieldIcon,
  UsersIcon,
  DollarSignIcon,
  SettingsIcon,
  FileTextIcon,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";

const AdminLayout = () => {
  const { user, logout } = useAuthStore();
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleLogout = () => {
    logout();
    toast({
      title: "Logged out",
      description: "You have been successfully logged out.",
    });
    navigate("/");
  };

  return (
    <div className="flex h-screen">
      {/* Sidebar */}
      <aside className="hidden md:flex flex-col w-64 bg-gray-900 text-white">
        <div className="p-4 border-b border-gray-800">
          <Link to="/admin/dashboard" className="flex items-center space-x-2">
            <DumbbellIcon className="w-6 h-6 text-gym-purple-light" />
            <span className="font-bold text-lg">GYMPAL ADMIN</span>
          </Link>
        </div>

        <nav className="flex-1 pt-4 px-2">
          <div className="space-y-1">
            <div className="px-3 py-2 text-xs uppercase tracking-wider text-gray-400">
              Dashboard
            </div>

            <Link
              to="/admin/dashboard"
              className="flex items-center rounded-md px-3 py-2 text-gray-300 hover:bg-gray-800 hover:text-white"
            >
              <HomeIcon className="w-5 h-5 mr-2" />
              <span>Overview</span>
            </Link>

            <div className="px-3 py-2 text-xs uppercase tracking-wider text-gray-400 mt-4">
              Management
            </div>

            <Link
              to="/admin/coaches"
              className="flex items-center rounded-md px-3 py-2 text-gray-300 hover:bg-gray-800 hover:text-white"
            >
              <UsersIcon className="w-5 h-5 mr-2" />
              <span>Coaches</span>
            </Link>

            <Link
              to="/admin/clients"
              className="flex items-center rounded-md px-3 py-2 text-gray-300 hover:bg-gray-800 hover:text-white"
            >
              <UsersIcon className="w-5 h-5 mr-2" />
              <span>Clients</span>
            </Link>

            <Link
              to="/admin/admins"
              className="flex items-center rounded-md px-3 py-2 text-gray-300 hover:bg-gray-800 hover:text-white"
            >
              <UsersIcon className="w-5 h-5 mr-2" />
              <span>Admins</span>
            </Link>

            <Link
              to="/admin/complaints"
              className="flex items-center rounded-md px-3 py-2 text-gray-300 hover:bg-gray-800 hover:text-white"
            >
              <FileTextIcon className="w-5 h-5 mr-2" />
              <span>Complaints</span>
            </Link>

            <div className="px-3 py-2 text-xs uppercase tracking-wider text-gray-400 mt-4">
              Finance
            </div>

            <Link
              to="/admin/payments"
              className="flex items-center rounded-md px-3 py-2 text-gray-300 hover:bg-gray-800 hover:text-white"
            >
              <DollarSignIcon className="w-5 h-5 mr-2" />
              <span>Payments</span>
            </Link>
          </div>
        </nav>

        <div className="border-t border-gray-800 p-4">
          <div className="flex items-center space-x-3 mb-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gray-800">
              <ShieldIcon className="h-5 w-5 text-gym-purple-light" />
            </div>
            <div>
              <p className="text-sm font-medium text-white">
                {user?.firstName}
              </p>
              <p className="text-xs text-gray-400">Administrator</p>
            </div>
          </div>
          <Button
            variant="destructive"
            className="w-full justify-start text-left"
            onClick={handleLogout}
          >
            <LogOutIcon className="w-4 h-4 mr-2" />
            <span>Logout</span>
          </Button>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col">
        {/* Mobile header */}
        <header className="md:hidden bg-gray-900 text-white p-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <DumbbellIcon className="w-6 h-6 text-gym-purple-light" />
            <span className="font-bold">GYMPAL ADMIN</span>
          </div>

          <Button variant="ghost" size="icon" className="text-white">
            <SettingsIcon className="h-5 w-5" />
          </Button>
        </header>

        {/* Page content */}
        <main className="flex-1 bg-gray-100 overflow-auto p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;
