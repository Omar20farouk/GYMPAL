import { Outlet, useLocation, useRoutes } from "react-router-dom";
import { useAuthStore } from "@/store/authStore";
import { useNavigate, Link } from "react-router-dom";
import {
  BellIcon,
  UserIcon,
  LogOutIcon,
  HomeIcon,
  DumbbellIcon,
  MessageSquareIcon,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";

const items = [
  {
    to: "/client/dashboard",
    icon: <HomeIcon className="w-5 h-5 mr-2" />,
    label: "Dashboard",
  },
  {
    to: "/client/chat",
    icon: <MessageSquareIcon className="w-5 h-5 mr-2" />,
    label: "Messages",
  },
];

const ClientLayout = () => {
  const { user, logout } = useAuthStore();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { pathname } = useLocation();

  const handleLogout = () => {
    logout();
    toast({
      title: "Logged out",
      description: "You have been successfully logged out.",
    });
    navigate("/");
  };

  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-30 shadow-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          {/* Logo */}
          <Link to="/client/dashboard" className="flex items-center space-x-2">
            <DumbbellIcon className="w-6 h-6 text-gym-purple" />
            <span className="font-bold text-lg">GYMPAL</span>
          </Link>

          {/* Navigation */}
          <div className="hidden md:flex items-center space-x-6">
            {items.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  `flex items-center text-gray-700 hover:text-gym-purple`,
                  {
                    "text-gym-purple": pathname === item.to,
                  }
                )}
              >
                {item.icon}
                <span>{item.label}</span>
              </Link>
            ))}
          </div>

          {/* User menu */}
          <div className="flex items-center space-x-4">
            {/* Notifications */}
            {/* <Button size="icon" variant="ghost" className="relative">
              <BellIcon className="w-5 h-5" />
              <span className="absolute top-0 right-0 block h-2 w-2 rounded-full bg-red-500 ring-2 ring-white" />
            </Button> */}

            {/* User dropdown */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="rounded-full">
                  <UserIcon className="w-5 h-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <div className="flex items-center justify-start gap-2 p-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gym-purple/10">
                    <UserIcon className="h-5 w-5 text-gym-purple" />
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm font-medium leading-none">
                      {user?.firstName} {user?.lastName}
                    </p>
                    <p className="text-xs leading-none text-gray-500">
                      {user?.email}
                    </p>
                  </div>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <Link to="/client/profile" className="flex w-full">
                    Profile
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  className="text-red-600"
                  onClick={handleLogout}
                >
                  <LogOutIcon className="w-4 h-4 mr-2" />
                  <span>Logout</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="flex-grow bg-gray-50">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="bg-white border-t py-6">
        <div className="container mx-auto px-4 text-center text-gray-500 text-sm">
          <p>© {new Date().getFullYear()} GYMPAL. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default ClientLayout;
