import { useToast } from "@/hooks/use-toast";
import { useAuthStore } from "@/store/authStore";
import { Navigate } from "react-router-dom";
import RedirectBasedOnRole from "../Redirect";

const AuthGuard = ({
  children,
  allowedRoles,
}: {
  children: JSX.Element;
  allowedRoles: string[];
}) => {
  const { toast } = useToast();
  const user = useAuthStore((state) => state.user);
  const token = useAuthStore((state) => state.token);

  if (!user || !token) {
    return <Navigate to="/login" replace />;
  }

  if (
    allowedRoles.length > 0 &&
    user.role &&
    !allowedRoles.includes(user.role)
  ) {
    // Redirect to appropriate dashboard based on role
    return <RedirectBasedOnRole user={user} />;
  }

  return children;
};

export default AuthGuard;
