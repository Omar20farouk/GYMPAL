import { useAuthStore } from "@/store/authStore";
import ClientLayout from "./ClientLayout";
import CoachLayout from "./CoachLayout";
import AdminLayout from "./AdminLayout";

const Layout = () => {
  const { user } = useAuthStore();

  if (user?.role === "CLIENT") return <ClientLayout />;
  if (user?.role === "COACH") return <CoachLayout />;
  if (user?.role === "ADMIN") return <AdminLayout />;
};

export default Layout;
