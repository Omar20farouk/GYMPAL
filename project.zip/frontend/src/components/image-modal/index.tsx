import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogOverlay } from "@/components/ui/dialog";

type Props = {
  isOpen: boolean;
  onClose: () => void;
  imageUrl: string;
};

const ImageModal: React.FC<Props> = ({ isOpen, onClose, imageUrl }) => {
  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogOverlay />
      <DialogContent>
        <div className="mt-4">
          <img src={imageUrl} alt="Modal" />
          <Button
            className="mt-4 w-full border-black"
            variant="outline"
            onClick={onClose}
          >
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ImageModal;
