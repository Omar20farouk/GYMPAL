import { Coach } from "@/types/coach";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

type CoachProfileInfoProps = {
  coach: Coach;
};

export function CoachProfileInfo({ coach }: CoachProfileInfoProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Coach Information</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <p className="text-sm font-medium mb-1">Status</p>
            {coach.status === "APPROVED" ? (
              <Badge variant="success">Approved</Badge>
            ) : coach.status === "PENDING" ? (
              <Badge variant="warning">Pending Approval</Badge>
            ) : (
              <Badge variant="destructive">Rejected</Badge>
            )}
          </div>

          <Separator />

          <div>
            <p className="text-sm font-medium mb-1">Experience</p>
            <p className="font-bold">{coach.experience} years</p>
          </div>

          <Separator />

          <div>
            <p className="text-sm font-medium mb-1">Specialties</p>
            <div className="flex flex-wrap gap-2">
              {coach.specialties?.map((specialty) => (
                <Badge key={specialty.id} variant="outline">
                  {specialty.name}
                </Badge>
              ))}
            </div>
          </div>

          <Separator />

          <div>
            <p className="text-sm font-medium mb-1">Average Rating</p>
            <div className="flex items-center">
              <p className="font-bold mr-1">
                {coach.averageRating?.toFixed(1) || "0.0"}
              </p>
              <span className="text-yellow-500">★</span>
            </div>
          </div>

          <Separator />

          <div>
            <p className="text-sm font-medium mb-1">Balance</p>
            <p className="font-bold">
              ${Number(coach.balance || 0).toFixed(2)}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
