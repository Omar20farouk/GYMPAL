import { Navigate } from "react-router-dom";
import { useToast } from "@/components/ui/use-toast";
import { useEffect } from "react";
import { User } from "@/types/user";

export default function RedirectBasedOnRole({ user }: { user: User }) {
  if (user.role === "CLIENT") {
    return <Navigate to="/client/dashboard" replace />;
  }

  if (user.role === "COACH") {
    if (user.coach?.status !== "APPROVED") {
      return <Navigate to="/login" replace />;
    }
    return <Navigate to="/coach/dashboard" replace />;
  }

  if (user.role === "ADMIN") {
    return <Navigate to="/admin/dashboard" replace />;
  }

  if (user.role === "TEAM_MEMBER") {
    return <Navigate to="/team-member/dashboard" replace />;
  }

  return null;
}
