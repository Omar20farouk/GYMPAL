import { IsArray, IsNumber, IsString } from 'class-validator';

export class CreatePlanDto {
  @IsString()
  name: string;

  @IsString()
  description: string;

  @IsNumber()
  price: number;

  @IsNumber()
  duration: number;

  @IsString()
  durationUnit: 'day' | 'week' | 'month';

  @IsArray()
  @IsString({ each: true })
  features: string[];
}
