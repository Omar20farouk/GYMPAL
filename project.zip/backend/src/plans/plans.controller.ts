import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
} from '@nestjs/common';
import { PlansService } from './plans.service';
import { CreatePlanDto } from './dto/create-plan.dto';
import { UpdatePlanDto } from './dto/update-plan.dto';
import { CurrentUser } from 'src/common/decorators/current-user.decorator';
import { Coach } from 'src/coaches/entities/coach.entity';

@Controller('plans')
export class PlansController {
  constructor(private readonly plansService: PlansService) {}

  @Post()
  create(
    @CurrentUser('coach') coach: Coach,
    @Body() createPlanDto: CreatePlanDto,
  ) {
    return this.plansService.create({
      ...createPlanDto,
      coachId: coach.id,
    });
  }

  @Get()
  findAll(@CurrentUser('coach') coach: Coach) {
    return this.plansService.findAll({
      where: {
        coachId: coach.id,
      },
    });
  }

  @Get('max-price')
  getMaxPrice() {
    return this.plansService.getMaxPrice();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.plansService.findOne(id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updatePlanDto: UpdatePlanDto) {
    return this.plansService.update(id, updatePlanDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.plansService.remove(id);
  }
}
