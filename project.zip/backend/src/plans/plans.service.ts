import { Injectable } from '@nestjs/common';
import { CreatePlanDto } from './dto/create-plan.dto';
import { UpdatePlanDto } from './dto/update-plan.dto';
import { FindManyOptions, Repository } from 'typeorm';
import { Plan } from './entities/plan.entity';
import { InjectRepository } from '@nestjs/typeorm';

@Injectable()
export class PlansService {
  constructor(
    @InjectRepository(Plan) private readonly plansRepo: Repository<Plan>,
  ) {}
  create(createPlanDto: CreatePlanDto & { coachId: string }) {
    const newPlan = this.plansRepo.create({
      ...createPlanDto,
      coachId: createPlanDto.coachId,
    });
    return this.plansRepo.save(newPlan);
  }

  findAll(options: FindManyOptions<Plan>) {
    return this.plansRepo.find(options);
  }

  findOne(id: string) {
    return this.plansRepo.findOne({ where: { id } });
  }

  update(id: string, updatePlanDto: UpdatePlanDto) {
    return this.plansRepo.update(id, updatePlanDto);
  }

  async getMaxPrice() {
    const result = await this.plansRepo
      .createQueryBuilder('plan')
      .select('MAX(plan.price)', 'maxPrice')
      .getRawOne();

    return { maxPrice: Number(result.maxPrice) || 500 }; // Default to 500 if no plans exist
  }

  remove(id: string) {
    return this.plansRepo.softDelete(id);
  }
}
