import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Coach } from 'src/coaches/entities/coach.entity';

@Entity('plans')
export class Plan {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column('uuid')
  coachId: string;

  @ManyToOne(() => Coach, (coach) => coach.plans)
  @JoinColumn({ name: 'coach_id' })
  coach: Coach;

  @Column({ type: 'varchar', length: 100 })
  name: string;

  @Column('numeric')
  price: number;

  @Column({ type: 'numeric' })
  duration: number;

  @Column({ type: 'enum', enum: ['day', 'week', 'month'] })
  durationUnit: 'day' | 'week' | 'month';

  @Column({ type: 'varchar', length: 500 })
  description: string;

  @Column({ type: 'varchar', length: 100, array: true })
  features: string[];

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @DeleteDateColumn()
  deleteAt: Date;
}
