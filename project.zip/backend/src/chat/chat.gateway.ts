import {
  WebSocketGateway,
  SubscribeMessage,
  MessageBody,
  WebSocketServer,
  ConnectedSocket,
  OnGatewayConnection,
  OnGatewayDisconnect,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { ChatService } from './chat.service';
import { CreateMessageDto } from './dto/create-message.dto';

interface ChatUser {
  userId: string;
  userType: 'CLIENT' | 'COACH';
  socketId: string;
}

@WebSocketGateway({
  cors: {
    origin: '*',
  },
})
export class ChatGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer()
  server: Server;

  // Map to keep track of connected users
  private connectedUsers: Map<string, ChatUser> = new Map();

  constructor(private readonly chatService: ChatService) {}

  async handleConnection(client: Socket) {
    const token = client.handshake.auth.token;
    const userId = client.handshake.auth.userId;
    const userType = client.handshake.auth.userType;

    if (!token || !userId || !userType) {
      client.disconnect();
      return;
    }

    // Store user connection info
    this.connectedUsers.set(userId, {
      userId,
      userType,
      socketId: client.id,
    });

    // Join a room specific to this user
    client.join(`user-${userId}`);

    console.log(`Client connected: ${userId} (${userType})`);
  }

  handleDisconnect(client: Socket) {
    // Find and remove the disconnected user
    for (const [userId, user] of this.connectedUsers.entries()) {
      if (user.socketId === client.id) {
        this.connectedUsers.delete(userId);
        console.log(`Client disconnected: ${userId}`);
        break;
      }
    }
  }

  @SubscribeMessage('sendMessage')
  async handleMessage(
    @ConnectedSocket() client: Socket,
    @MessageBody()
    data: {
      senderId: string;
      senderType: 'CLIENT' | 'COACH';
      receiverId: string;
      content: string;
    },
  ) {
    try {
      const { senderId, senderType, receiverId, content } = data;

      // Find or create chat between these users
      const clientUserId = senderType === 'CLIENT' ? senderId : receiverId;
      const coachUserId = senderType === 'COACH' ? senderId : receiverId;

      const chat = await this.chatService.findOrCreateChat(
        clientUserId,
        coachUserId,
      );

      // Create and save the message
      const messageDto: CreateMessageDto = {
        chatId: chat.id,
        senderId,
        senderType,
        content,
      };

      const savedMessage = await this.chatService.createMessage(messageDto);

      // Emit to sender's room
      this.server.to(`user-${senderId}`).emit('receiveMessage', savedMessage);

      // Emit to receiver's room if they are online
      const receiverUser = this.connectedUsers.get(receiverId);
      if (receiverUser) {
        this.server
          .to(`user-${receiverId}`)
          .emit('receiveMessage', savedMessage);
      }

      return { success: true, message: savedMessage };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  @SubscribeMessage('getConversation')
  async getConversation(
    @ConnectedSocket() client: Socket,
    @MessageBody()
    data: {
      chatId: string;
    },
  ) {
    try {
      const { chatId } = data;
      const messages = await this.chatService.findMessages(chatId);
      return { success: true, messages };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  @SubscribeMessage('getClientConversations')
  async getClientConversations(
    @ConnectedSocket() client: Socket,
    @MessageBody() data: { clientId: string },
  ) {
    try {
      const conversations = await this.chatService.getClientConversations(
        data.clientId,
      );
      return { success: true, conversations };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  @SubscribeMessage('getCoachConversations')
  async getCoachConversations(
    @ConnectedSocket() client: Socket,
    @MessageBody() data: { coachId: string },
  ) {
    try {
      const conversations = await this.chatService.getCoachConversations(
        data.coachId,
      );
      return { success: true, conversations };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  @SubscribeMessage('markAsRead')
  async markAsRead(
    @ConnectedSocket() client: Socket,
    @MessageBody() data: { messageIds: string[] },
  ) {
    try {
      await this.chatService.markAsRead(data.messageIds);
      return { success: true };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  @SubscribeMessage('userTyping')
  async userTyping(
    @ConnectedSocket() client: Socket,
    @MessageBody()
    data: { senderId: string; receiverId: string; isTyping: boolean },
  ) {
    const { senderId, receiverId, isTyping } = data;

    // Emit to the receiver using the user ID
    const receiverUser = this.connectedUsers.get(receiverId);
    if (receiverUser) {
      this.server.to(`user-${receiverId}`).emit('userTypingUpdate', {
        userId: senderId,
        isTyping,
      });
    }
  }
}
