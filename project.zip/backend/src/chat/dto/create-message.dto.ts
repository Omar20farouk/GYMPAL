import { IsNotEmpty, IsUUID, IsEnum, IsString } from 'class-validator';

export class CreateMessageDto {
  @IsNotEmpty()
  @IsUUID()
  chatId: string;

  @IsNotEmpty()
  @IsUUID()
  senderId: string;

  @IsNotEmpty()
  @IsEnum(['CLIENT', 'COACH'])
  senderType: 'CLIENT' | 'COACH';

  @IsNotEmpty()
  @IsString()
  content: string;
}
