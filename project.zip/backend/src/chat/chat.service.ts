import {
  Injectable,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';
import { CreateMessageDto } from './dto/create-message.dto';
import { UpdateChatDto } from './dto/update-chat.dto';
import { Chat } from './entities/chat.entity';
import { Message } from './entities/message.entity';
import { Client } from 'src/clients/entities/client.entity';
import { Coach } from 'src/coaches/entities/coach.entity';
import { Subscription } from 'src/subscriptions/entities/subscription.entity';

@Injectable()
export class ChatService {
  constructor(
    @InjectRepository(Chat)
    private chatRepository: Repository<Chat>,
    @InjectRepository(Message)
    private messageRepository: Repository<Message>,
    @InjectRepository(Client)
    private clientRepository: Repository<Client>,
    @InjectRepository(Coach)
    private coachRepository: Repository<Coach>,
    @InjectRepository(Subscription)
    private subscriptionRepository: Repository<Subscription>,
  ) {}

  // Create or find a chat between a client and coach
  async findOrCreateChat(
    clientUserId: string,
    coachUserId: string,
  ): Promise<Chat> {
    // Find client and coach entities from user IDs
    const client = await this.clientRepository.findOne({
      where: { userId: clientUserId },
    });

    if (!client) {
      throw new NotFoundException('Client not found');
    }

    const coach = await this.coachRepository.findOne({
      where: { userId: coachUserId },
      relations: ['plans'],
    });

    if (!coach) {
      throw new NotFoundException('Coach not found');
    }

    // Check if there's a valid subscription
    const planIds = coach.plans.map((plan) => plan.id);
    const subscription = await this.subscriptionRepository.findOne({
      where: {
        clientId: client.id,
        isActive: true,
        planId: In(planIds),
      },
    });

    if (!subscription) {
      throw new BadRequestException(
        'No active subscription found between client and coach',
      );
    }

    // Try to find existing chat
    let chat = await this.chatRepository.findOne({
      where: {
        clientId: client.id,
        coachId: coach.id,
      },
    });

    // If no chat exists, create one
    if (!chat) {
      const newChat = this.chatRepository.create({
        clientId: client.id,
        coachId: coach.id,
        client,
        coach,
      });
      chat = await this.chatRepository.save(newChat);
    }

    return chat;
  }

  // Send a message
  async createMessage(createMessageDto: CreateMessageDto): Promise<Message> {
    const chat = await this.chatRepository.findOne({
      where: { id: createMessageDto.chatId },
      relations: ['client', 'coach'],
    });

    if (!chat) {
      throw new NotFoundException('Chat not found');
    }

    // Create and save the message
    const message = this.messageRepository.create(createMessageDto);

    // Set client or coach reference based on sender type
    if (createMessageDto.senderType === 'CLIENT') {
      message.client = chat.client;
    } else {
      message.coach = chat.coach;
    }

    return this.messageRepository.save(message);
  }

  // Get all messages in a conversation
  async findMessages(chatId: string): Promise<Message[]> {
    return this.messageRepository.find({
      where: { chatId },
      order: { sentAt: 'ASC' },
    });
  }

  // Get all client conversations (chats with coaches)
  async getClientConversations(userId: string): Promise<any> {
    // Find client by user ID
    const client = await this.clientRepository.findOne({
      where: { userId },
    });

    if (!client) {
      throw new NotFoundException('Client not found');
    }

    // Get all chats this client is part of
    const chats = await this.chatRepository.find({
      where: { clientId: client.id },
      relations: ['coach', 'coach.user'],
    });

    // Get last message for each chat
    const conversations = await Promise.all(
      chats.map(async (chat) => {
        const messages = await this.messageRepository.find({
          where: { chatId: chat.id },
          order: { sentAt: 'DESC' },
          take: 1,
        });

        const lastMessage = messages.length > 0 ? messages[0] : null;

        // Count unread messages
        const unreadCount = await this.messageRepository.count({
          where: {
            chatId: chat.id,
            senderType: 'COACH',
            read: false,
          },
        });

        return {
          chatId: chat.id,
          coachId: chat.coach.userId,
          coachName: `${chat.coach.user.firstName} ${chat.coach.user.lastName}`,
          lastMessage: lastMessage ? lastMessage.content : null,
          lastMessageDate: lastMessage ? lastMessage.sentAt : null,
          unreadCount,
        };
      }),
    );

    return conversations;
  }

  // Get all coach conversations (chats with clients)
  async getCoachConversations(userId: string): Promise<any> {
    // Find coach by user ID
    const coach = await this.coachRepository.findOne({
      where: { userId },
    });

    if (!coach) {
      throw new NotFoundException('Coach not found');
    }

    // Get all chats this coach is part of
    const chats = await this.chatRepository.find({
      where: { coachId: coach.id },
      relations: ['client', 'client.user'],
    });

    // Get last message and other details for each chat
    const conversations = await Promise.all(
      chats.map(async (chat) => {
        const messages = await this.messageRepository.find({
          where: { chatId: chat.id },
          order: { sentAt: 'DESC' },
          take: 1,
        });

        const lastMessage = messages.length > 0 ? messages[0] : null;

        // Count unread messages
        const unreadCount = await this.messageRepository.count({
          where: {
            chatId: chat.id,
            senderType: 'CLIENT',
            read: false,
          },
        });

        // Get subscription info for this client
        const subscription = await this.subscriptionRepository.findOne({
          where: {
            clientId: chat.clientId,
            isActive: true,
          },
          relations: ['plan'],
        });

        return {
          chatId: chat.id,
          clientId: chat.client.userId,
          clientName: `${chat.client.user.firstName} ${chat.client.user.lastName}`,
          planName: subscription ? subscription.plan.name : 'No active plan',
          lastMessage: lastMessage ? lastMessage.content : null,
          lastMessageDate: lastMessage ? lastMessage.sentAt : null,
          unreadCount,
        };
      }),
    );

    return conversations;
  }

  // Mark messages as read
  async markAsRead(messageIds: string[]): Promise<void> {
    if (messageIds.length > 0) {
      await this.messageRepository.update(
        { id: In(messageIds) },
        { read: true },
      );
    }
  }

  // Other utility methods
  findAllChats() {
    return this.chatRepository.find();
  }

  findChatById(id: string) {
    return this.chatRepository.findOne({ where: { id } });
  }

  updateChat(id: string, updateChatDto: UpdateChatDto) {
    return this.chatRepository.update(id, updateChatDto);
  }

  removeChat(id: string) {
    return this.chatRepository.delete(id);
  }
}
