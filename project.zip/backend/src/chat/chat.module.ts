import { forwardRef, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ChatService } from './chat.service';
import { ChatGateway } from './chat.gateway';
import { Chat } from './entities/chat.entity';
import { Message } from './entities/message.entity';
import { SubscriptionsModule } from 'src/subscriptions/subscriptions.module';
import { ClientsModule } from 'src/clients/clients.module';
import { CoachesModule } from 'src/coaches/coaches.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([Chat, Message]),
    SubscriptionsModule,
    ClientsModule,
    forwardRef(() => CoachesModule),
  ],
  providers: [ChatGateway, ChatService],
  exports: [TypeOrmModule, ChatService],
})
export class ChatModule {}
