import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Coach } from 'src/coaches/entities/coach.entity';
import { Between, LessThan, MoreThanOrEqual, Repository } from 'typeorm';
import { CoachStatus } from 'src/coaches/enums';
import { UserRole } from 'src/users/enums';
import { User } from 'src/users/entities/user.entity';
import * as bcrypt from 'bcrypt';
import { CreateAdminDto } from './dto/create-admin.dto';
import { Payment, PaymentStatus } from 'src/payments/entities/payment.entity';
import { Complaint } from 'src/complaints/entities/complaint.entity';
import { ComplaintStatus } from 'src/complaints/enums';
import { MailerService } from 'src/mailer/mailer.service';
import { ConfigService } from '@nestjs/config';
import {
  COACH_APPROVAL_EMAIL,
  COACH_REJECTION_EMAIL,
} from 'src/mailer/templates/email-templates';

@Injectable()
export class AdminService {
  private readonly logger = new Logger(AdminService.name);

  constructor(
    @InjectRepository(Coach) private readonly coachesRepo: Repository<Coach>,
    @InjectRepository(User) private readonly usersRepo: Repository<User>,
    @InjectRepository(Payment)
    private readonly paymentsRepo: Repository<Payment>,
    @InjectRepository(Complaint)
    private readonly complaintsRepo: Repository<Complaint>,
    private readonly mailerService: MailerService,
    private readonly configService: ConfigService,
  ) {}
  async approveCoach(id: string) {
    // Find the coach with user data
    const coach = await this.coachesRepo.findOne({
      where: { id },
      relations: ['user'],
    });

    if (!coach) {
      throw new NotFoundException(`Coach with ID ${id} not found`);
    }

    // Update coach status
    await this.coachesRepo.update(id, { status: CoachStatus.APPROVED });

    // Send approval email
    try {
      const coachName = `${coach.user.firstName} ${coach.user.lastName}`;
      const loginUrl =
        this.configService.get<string>('FRONTEND_URL', 'https://gympal.com') +
        '/login';

      const emailContent = COACH_APPROVAL_EMAIL.replace(
        '{{coachName}}',
        coachName,
      )
        .replace('{{coachEmail}}', coach.user.email)
        .replace('{{loginUrl}}', loginUrl);

      await this.mailerService.sendMail(
        coach.user.email,
        'Your GYMPAL Coach Application is Approved! 🎉',
        emailContent,
      );

      this.logger.log(`Approval email sent to coach ${id}`);
    } catch (error) {
      this.logger.error(
        `Failed to send approval email to coach ${id}: ${error.message}`,
      );
      // Continue with approval even if email fails
    }

    return { success: true, message: 'Coach approved successfully' };
  }

  async rejectCoach(id: string) {
    // Find the coach with user data
    const coach = await this.coachesRepo.findOne({
      where: { id },
      relations: ['user'],
    });

    if (!coach) {
      throw new NotFoundException(`Coach with ID ${id} not found`);
    }

    // Update coach status
    await this.coachesRepo.update(id, { status: CoachStatus.REJECTED });

    // Send rejection email
    try {
      const coachName = `${coach.user.firstName} ${coach.user.lastName}`;
      const supportUrl =
        this.configService.get<string>('FRONTEND_URL', 'https://gympal.com') +
        '/contact';

      const emailContent = COACH_REJECTION_EMAIL.replace(
        '{{coachName}}',
        coachName,
      ).replace('{{coachEmail}}', coach.user.email);

      await this.mailerService.sendMail(
        coach.user.email,
        'Update on Your GYMPAL Coach Application',
        emailContent,
      );

      this.logger.log(`Rejection email sent to coach ${id}`);
    } catch (error) {
      this.logger.error(
        `Failed to send rejection email to coach ${id}: ${error.message}`,
      );
      // Continue with rejection even if email fails
    }

    return { success: true, message: 'Coach rejected successfully' };
  }

  getAdmins() {
    return this.usersRepo.find({
      where: { role: UserRole.ADMIN },
    });
  }

  async createAdmin(createAdminDto: CreateAdminDto) {
    return this.usersRepo.save({
      ...createAdminDto,
      password: await bcrypt.hash(createAdminDto.password, 10),
      role: UserRole.ADMIN,
    });
  }

  async getDashboardStats() {
    const totalUsers = await this.usersRepo.count();
    const pendingCoaches = await this.coachesRepo.count({
      where: { status: CoachStatus.PENDING },
    });

    // Get total reports count
    const reports = await this.complaintsRepo.count({
      where: { status: ComplaintStatus.PENDING },
    });

    // Calculate total revenue from successful payments
    const successfulPayments = await this.paymentsRepo.find({
      where: { status: PaymentStatus.SUCCEEDED },
    });

    const revenue = successfulPayments.reduce(
      (total, payment) => total + Number(payment.amount),
      0,
    );

    // Calculate growth percentages
    // This would typically compare current month to previous month
    // For demo, we're using a 30-day window
    const today = new Date();
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(today.getDate() - 30);
    const sixtyDaysAgo = new Date();
    sixtyDaysAgo.setDate(today.getDate() - 60);

    // Count users created in the last 30 days
    const recentUsers = await this.usersRepo.count({
      where: {
        createdAt: MoreThanOrEqual(thirtyDaysAgo),
      },
    });

    // Count users created in the 30 days before that
    const previousUsers = await this.usersRepo.count({
      where: {
        createdAt: Between(sixtyDaysAgo, thirtyDaysAgo),
      },
    });

    // Calculate revenue from the last 30 days
    const recentPayments = await this.paymentsRepo.find({
      where: {
        status: PaymentStatus.SUCCEEDED,
        createdAt: MoreThanOrEqual(thirtyDaysAgo),
      },
    });

    const recentRevenue = recentPayments.reduce(
      (total, payment) => total + Number(payment.amount),
      0,
    );

    // Calculate revenue from the 30 days before that
    const previousPayments = await this.paymentsRepo.find({
      where: {
        status: PaymentStatus.SUCCEEDED,
        createdAt: Between(sixtyDaysAgo, thirtyDaysAgo),
      },
    });

    const previousRevenue = previousPayments.reduce(
      (total, payment) => total + Number(payment.amount),
      0,
    );

    // Calculate growth percentages
    const userGrowth =
      previousUsers === 0
        ? 100
        : Math.round(((recentUsers - previousUsers) / previousUsers) * 100);

    const revenueGrowth =
      previousRevenue === 0
        ? 100
        : Math.round(
            ((recentRevenue - previousRevenue) / previousRevenue) * 100,
          );

    return {
      totalUsers,
      pendingCoaches,
      reports,
      revenue,
      userGrowth,
      revenueGrowth,
    };
  }

  async getPendingCoaches() {
    return this.coachesRepo.find({
      where: { status: CoachStatus.PENDING },
      relations: ['user', 'specialties'],
    });
  }

  async getReports() {
    const complaints = await this.complaintsRepo.find({
      where: { status: ComplaintStatus.PENDING },
      relations: ['client', 'client.user', 'coach', 'coach.user'],
      order: {
        createdAt: 'DESC',
      },
      take: 5, // Limit to 5 most recent complaints
    });

    return complaints.map((complaint) => ({
      id: complaint.id,
      title: `Complaint against ${complaint.coach.user.firstName} ${complaint.coach.user.lastName}`,
      description: complaint.description,
      createdAt: complaint.createdAt.toISOString(),
      status: complaint.status,
      client: `${complaint.client.user.firstName} ${complaint.client.user.lastName}`,
      coach: `${complaint.coach.user.firstName} ${complaint.coach.user.lastName}`,
    }));
  }
}
