import { Module } from '@nestjs/common';
import { AdminService } from './admin.service';
import { AdminController } from './admin.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Coach } from 'src/coaches/entities/coach.entity';
import { User } from 'src/users/entities/user.entity';
import { Payment } from 'src/payments/entities/payment.entity';
import { Complaint } from 'src/complaints/entities/complaint.entity';
import { MailerModule } from 'src/mailer/mailer.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([Coach, User, Payment, Complaint]),
    MailerModule,
  ],
  controllers: [AdminController],
  providers: [AdminService],
})
export class AdminModule {}
