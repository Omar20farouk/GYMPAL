import { Controller, Patch, Param, Get, Post, Body } from '@nestjs/common';
import { AdminService } from './admin.service';
import { CreateAdminDto } from './dto/create-admin.dto';

@Controller('admin')
export class AdminController {
  constructor(private readonly adminService: AdminService) {}

  @Get('/admins')
  getAdmins() {
    return this.adminService.getAdmins();
  }

  @Post('/admins')
  createAdmin(@Body() createAdminDto: CreateAdminDto) {
    return this.adminService.createAdmin(createAdminDto);
  }

  @Patch('coaches/:id/approve')
  approveCoach(@Param('id') id: string) {
    return this.adminService.approveCoach(id);
  }

  @Patch('coaches/:id/reject')
  rejectCoach(@Param('id') id: string) {
    return this.adminService.rejectCoach(id);
  }

  @Get('/dashboard-stats')
  getDashboardStats() {
    return this.adminService.getDashboardStats();
  }

  @Get('/pending-coaches')
  getPendingCoaches() {
    return this.adminService.getPendingCoaches();
  }

  @Get('/reports')
  getReports() {
    return this.adminService.getReports();
  }
}
