import { Module } from '@nestjs/common';
import { ServeStaticModule } from '@nestjs/serve-static';
import { join } from 'path';

import { AppController } from './app.controller';

import { TypeOrmModule } from '@nestjs/typeorm';
import { UsersModule } from './users/users.module';
import { CoachesModule } from './coaches/coaches.module';
import { ClientsModule } from './clients/clients.module';
import { PaymentsModule } from './payments/payments.module';
import { SubscriptionsModule } from './subscriptions/subscriptions.module';
import { AdminModule } from './admin/admin.module';
import { ComplaintsModule } from './complaints/complaints.module';
import { AuthModule } from './auth/auth.module';
import { ReviewsModule } from './reviews/reviews.module';
import { PlansModule } from './plans/plans.module';
import { SpecialtiesModule } from './specialties/specialties.module';
import { ChatModule } from './chat/chat.module';
import { ProfileModule } from './profile/profile.module';
import { UploadsModule } from './uploads/uploads.module';
import { TeamsModule } from './teams/teams.module';
import { MailerModule } from './mailer/mailer.module';

import { AuthGuard } from './auth/guards/auth.guard';
import { ConfigModule, ConfigService } from '@nestjs/config';

import { AppService } from './app.service';
import { APP_GUARD } from '@nestjs/core';

import { databaseConfig } from './common/config/db.config';
import { authConfig } from './common/config/auth.config';
import { RolesGuard } from './auth/guards/roles.guard';
import { QualificationsModule } from './qualifications/qualifications.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      load: [databaseConfig, authConfig],
      envFilePath: '.env',
    }),

    TypeOrmModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: async () => {
        const config = databaseConfig();

        return {
          ...config,
          cli: {
            migrationsDir: 'src/db/migrations',
          },
        };
      },
    }),

    // Serve static files from the uploads directory
    ServeStaticModule.forRoot({
      rootPath: join(process.cwd(), 'uploads'),
      serveRoot: '/uploads',
    }),

    ChatModule,
    CoachesModule,
    ClientsModule,
    PaymentsModule,
    SubscriptionsModule,
    AdminModule,
    ComplaintsModule,
    UsersModule,
    AuthModule,
    ReviewsModule,
    PlansModule,
    SpecialtiesModule,
    ProfileModule,
    UploadsModule,
    TeamsModule,
    QualificationsModule,
    MailerModule,
  ],

  controllers: [AppController],
  providers: [
    AppService,
    {
      provide: APP_GUARD,
      useClass: AuthGuard,
    },
    {
      provide: APP_GUARD,
      useClass: RolesGuard,
    },
  ],
})
export class AppModule {}
