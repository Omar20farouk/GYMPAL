export enum UserRole {
  CLIENT = 'CLIENT',
  COACH = 'COACH',
  ADMIN = 'ADMIN',
  TEAM_MEMBER = 'TEAM_MEMBER',
}
