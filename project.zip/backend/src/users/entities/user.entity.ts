import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  OneToOne,
  CreateDateColumn,
  UpdateDateColumn,
} from 'typeorm';
import { UserRole } from '../enums';
import { Coach } from 'src/coaches/entities/coach.entity';
import { Client } from 'src/clients/entities/client.entity';
import { TeamMember } from 'src/teams/entities/team-member.entity';

@Entity('users')
export class User {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  firstName: string;

  @Column()
  lastName: string;

  @Column({ unique: true })
  email: string;

  @Column()
  password: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  city: string;

  @Column({ type: 'enum', enum: UserRole })
  role: UserRole;

  @OneToOne(() => Coach, (coach) => coach.user)
  coach: Coach;

  @OneToOne(() => Client, (client) => client.user)
  client: Client;

  @OneToOne(() => TeamMember, (teamMember) => teamMember.user)
  teamMember: TeamMember;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
