export const COACH_APPROVAL_EMAIL = `
<!DOCTYPE html>
<html>
<head>
  <style>
    body {
      font-family: Arial, sans-serif;
      line-height: 1.6;
      color: #333;
    }
    .container {
      max-width: 600px;
      margin: 0 auto;
      padding: 20px;
      border: 1px solid #e1e1e1;
      border-radius: 5px;
    }
    .header {
      background-color: #4A90E2;
      color: white;
      padding: 15px;
      text-align: center;
      border-radius: 5px 5px 0 0;
    }
    .content {
      padding: 20px;
      background-color: #f9f9f9;
    }
    .button {
      display: inline-block;
      background-color: #4CAF50;
      color: white;
      padding: 10px 20px;
      text-decoration: none;
      border-radius: 4px;
      margin: 20px 0;
    }
    .footer {
      text-align: center;
      font-size: 12px;
      color: #888;
      margin-top: 20px;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>Congratulations, {{coachName}}!</h1>
    </div>
    <div class="content">
      <p>Great news! Your coach application for GYMPAL has been <strong>approved</strong>.</p>
      <p>You can now log in to your account and start building your profile, creating training plans, and connecting with clients.</p>
      <p>Get started by setting up your first training plan and customize your coach profile to attract more clients.</p>
      <a href="{{loginUrl}}" class="button">Log In Now</a>
      <p>If you have any questions or need assistance, please don't hesitate to contact our support team.</p>
      <p>We're excited to have you join our community of fitness professionals!</p>
      <p>Best regards,<br>The GYMPAL Team</p>
    </div>
    <div class="footer">
      <p>© 2023 GYMPAL. All rights reserved.</p>
      <p>This email was sent to {{coachEmail}} because you registered as a coach on GYMPAL.</p>
    </div>
  </div>
</body>
</html>
`;

export const COACH_REJECTION_EMAIL = `
<!DOCTYPE html>
<html>
<head>
  <style>
    body {
      font-family: Arial, sans-serif;
      line-height: 1.6;
      color: #333;
    }
    .container {
      max-width: 600px;
      margin: 0 auto;
      padding: 20px;
      border: 1px solid #e1e1e1;
      border-radius: 5px;
    }
    .header {
      background-color: #e74c3c;
      color: white;
      padding: 15px;
      text-align: center;
      border-radius: 5px 5px 0 0;
    }
    .content {
      padding: 20px;
      background-color: #f9f9f9;
    }
    .button {
      display: inline-block;
      background-color: #3498db;
      color: white;
      padding: 10px 20px;
      text-decoration: none;
      border-radius: 4px;
      margin: 20px 0;
    }
    .footer {
      text-align: center;
      font-size: 12px;
      color: #888;
      margin-top: 20px;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>Application Status Update</h1>
    </div>
    <div class="content">
      <p>Dear {{coachName}},</p>
      <p>Thank you for your interest in becoming a coach on GYMPAL.</p>
      <p>After careful review of your application, we regret to inform you that we are <strong>unable to approve</strong> your coach account at this time.</p>
      <p>This could be due to one of the following reasons:</p>
      <ul>
        <li>Incomplete or missing qualification information</li>
        <li>Insufficient experience in the fitness industry</li>
        <li>Lack of specialized training credentials</li>
      </ul>
      <p>We encourage you to update your profile with additional information and apply again in the future.</p>
      <p>If you believe this decision was made in error or if you'd like more specific feedback, please contact our support team.</p>
      <p>Best regards,<br>The GYMPAL Team</p>
    </div>
    <div class="footer">
      <p>© 2023 GYMPAL. All rights reserved.</p>
      <p>This email was sent to {{coachEmail}} because you registered as a coach on GYMPAL.</p>
    </div>
  </div>
</body>
</html>
`;
