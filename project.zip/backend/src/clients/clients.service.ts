import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { FindOptionsWhere, Repository } from 'typeorm';
import { CreateHealthFormDto } from './dto/create-health-form.dto';
import { HealthForm } from './entities/health-form.entity';
import { Client } from './entities/client.entity';
import { User } from 'src/users/entities/user.entity';
import { UserRole } from 'src/users/enums';
import { Team } from 'src/teams/entities/team.entity';

@Injectable()
export class ClientsService {
  constructor(
    @InjectRepository(HealthForm)
    private healthFormRepository: Repository<HealthForm>,
    @InjectRepository(Client)
    private clientsRepository: Repository<Client>,
    @InjectRepository(Team)
    private teamsRepository: Repository<Team>,
  ) {}

  findAll() {
    return this.clientsRepository.find({
      relations: {
        user: true,
      },
    });
  }

  async createHealthForm(
    createHealthFormDto: CreateHealthFormDto,
    clientId: string,
  ): Promise<HealthForm> {
    const healthForm = this.healthFormRepository.create({
      ...createHealthFormDto,
      clientId,
    });

    return this.healthFormRepository.save(healthForm);
  }

  async getHealthForms(user: User, clientId: string): Promise<HealthForm[]> {
    let where: FindOptionsWhere<HealthForm> = {
      clientId,
    };

    if (user.role === UserRole.COACH) {
      where = {
        ...where,
        plan: {
          coachId: user.coach.id,
        },
      };
    } else if (user.role === UserRole.TEAM_MEMBER) {
      const team = await this.teamsRepository.findOne({
        where: {
          id: user.teamMember.teamId,
        },
        select: {
          coachId: true,
        },
      });

      if (!team) {
        throw new NotFoundException('Team not found');
      }

      where = {
        ...where,
        plan: {
          coachId: team.coachId,
        },
      };
    }

    const healthForms = await this.healthFormRepository.find({
      where,
      relations: {
        plan: true,
      },
      order: { createdAt: 'DESC' },
    });

    if (!healthForms || healthForms.length === 0) {
      throw new NotFoundException('No health forms found for this client');
    }

    return healthForms;
  }

  async getClientPayments(clientId: string) {
    // This will be implemented when we create the payment service
    return [];
  }
}
