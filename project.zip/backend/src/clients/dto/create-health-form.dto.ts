import {
  IsBoolean,
  IsEnum,
  IsNotEmpty,
  IsOptional,
  IsString,
} from 'class-validator';

export enum FitnessGoal {
  WEIGHT_LOSS = 'Weight Loss',
  MUSCLE_GAIN = 'Muscle Gain',
  ENDURANCE = 'Endurance',
  FLEXIBILITY = 'Flexibility',
  TOURNAMENT_PREP = 'Tournament Prep',
  GENERAL_HEALTH = 'General Health',
  OTHER = 'Other',
}

export class CreateHealthFormDto {
  @IsNotEmpty()
  @IsString()
  height: string;

  @IsNotEmpty()
  @IsString()
  weight: string;

  @IsOptional()
  @IsString()
  chronicDiseases?: string;

  @IsNotEmpty()
  @IsBoolean()
  hasDisability: boolean;

  @IsOptional()
  @IsString()
  disabilityDetails?: string;

  @IsOptional()
  @IsString()
  favoriteFood?: string;

  @IsNotEmpty()
  @IsEnum(FitnessGoal)
  fitnessGoal: FitnessGoal;

  @IsNotEmpty()
  @IsString()
  planId: string;
}
