import { Controller, Get, Post, Body, Param } from '@nestjs/common';
import { ClientsService } from './clients.service';
import { CreateHealthFormDto } from './dto/create-health-form.dto';
import { CurrentUser } from 'src/common/decorators/current-user.decorator';
import { Client } from './entities/client.entity';
import { User } from 'src/users/entities/user.entity';

@Controller('clients')
export class ClientsController {
  constructor(private readonly clientsService: ClientsService) {}

  @Get()
  findAll() {
    return this.clientsService.findAll();
  }

  @Post('health-form')
  createHealthForm(
    @CurrentUser() user: User,
    @Body() createHealthFormDto: CreateHealthFormDto,
  ) {
    return this.clientsService.createHealthForm(
      createHealthFormDto,
      user.client.id,
    );
  }

  @Get(':id/health-forms')
  getHealthForms(@CurrentUser() user: User, @Param('id') id: string) {
    return this.clientsService.getHealthForms(user, id);
  }

  @Get(':id/payments')
  getClientPayments(@Param('id') id: string) {
    return this.clientsService.getClientPayments(id);
  }
}
