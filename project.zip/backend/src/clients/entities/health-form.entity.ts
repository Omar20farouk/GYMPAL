import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Client } from './client.entity';
import { Plan } from '../../plans/entities/plan.entity';
import { FitnessGoal } from '../dto/create-health-form.dto';

@Entity('health_forms')
export class HealthForm {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  height: string;

  @Column()
  weight: string;

  @Column({ nullable: true })
  chronicDiseases: string;

  @Column()
  hasDisability: boolean;

  @Column({ nullable: true })
  disabilityDetails: string;

  @Column({ nullable: true })
  favoriteFood: string;

  @Column({
    type: 'enum',
    enum: FitnessGoal,
    default: FitnessGoal.GENERAL_HEALTH,
  })
  fitnessGoal: FitnessGoal;

  @Column('uuid')
  clientId: string;

  @ManyToOne(() => Client)
  @JoinColumn({ name: 'client_id' })
  client: Client;

  @Column('uuid')
  planId: string;

  @ManyToOne(() => Plan)
  @JoinColumn({ name: 'plan_id' })
  plan: Plan;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
