import {
  Injectable,
  NotFoundException,
  ForbiddenException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CreateComplaintDto } from './dto/create-complaint.dto';
import { UpdateComplaintDto } from './dto/update-complaint.dto';
import { Complaint } from './entities/complaint.entity';
import { ComplaintStatus } from './enums';
import { SubscriptionsService } from '../subscriptions/subscriptions.service';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class ComplaintsService {
  constructor(
    @InjectRepository(Complaint)
    private complaintsRepository: Repository<Complaint>,
    private subscriptionsService: SubscriptionsService,
    private readonly configService: ConfigService,
  ) {}

  async create(clientId: string, createComplaintDto: CreateComplaintDto) {
    // Verify that the client has an active subscription to the coach
    const hasActiveSubscription =
      await this.subscriptionsService.clientHasActiveSubscriptionToCoach(
        clientId,
        createComplaintDto.coachId,
      );

    if (!hasActiveSubscription) {
      throw new ForbiddenException(
        'You must be subscribed to this coach to file a complaint',
      );
    }

    const complaint = this.complaintsRepository.create({
      clientId,
      ...createComplaintDto,
      status: ComplaintStatus.PENDING,
    });

    return this.complaintsRepository.save(complaint);
  }

  async findAll() {
    const complaints = await this.complaintsRepository.find({
      relations: ['client', 'client.user', 'coach', 'coach.user'],
      order: { createdAt: 'DESC' },
    });

    return complaints.map((complaint) => ({
      ...complaint,
      images: complaint.images?.map(
        (image) => `${this.configService.get('BACKEND_URL')}${image}`,
      ),
    }));
  }

  async findByClientId(clientId: string) {
    const complaints = await this.complaintsRepository.find({
      where: { clientId },
      relations: ['client', 'client.user', 'coach', 'coach.user'],
      order: { createdAt: 'DESC' },
    });

    return complaints.map((complaint) => ({
      ...complaint,
      images: complaint.images?.map(
        (image) => `${this.configService.get('BACKEND_URL')}${image}`,
      ),
    }));
  }

  async findOne(id: string) {
    const complaint = await this.complaintsRepository.findOne({
      where: { id },
      relations: ['client', 'client.user', 'coach', 'coach.user'],
    });

    if (!complaint) {
      throw new NotFoundException(`Complaint with ID ${id} not found`);
    }

    complaint.images =
      complaint.images?.map(
        (image) => `${this.configService.get('BACKEND_URL')}${image}`,
      ) ?? null;

    return complaint;
  }

  async update(id: string, updateComplaintDto: UpdateComplaintDto) {
    const complaint = await this.findOne(id);

    this.complaintsRepository.merge(complaint, updateComplaintDto);
    return this.complaintsRepository.save(complaint);
  }

  async resolveComplaint(id: string) {
    const complaint = await this.findOne(id);

    complaint.status = ComplaintStatus.RESOLVED;
    return this.complaintsRepository.save(complaint);
  }

  async remove(id: string) {
    const complaint = await this.findOne(id);
    return this.complaintsRepository.remove(complaint);
  }
}
