import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
} from '@nestjs/common';
import { ComplaintsService } from './complaints.service';
import { CreateComplaintDto } from './dto/create-complaint.dto';
import { UpdateComplaintDto } from './dto/update-complaint.dto';
import { Roles } from '../common/decorators/roles.decorator';
import { UserRole } from '../users/enums';
import { CurrentUser } from 'src/common/decorators/current-user.decorator';
import { User } from 'src/users/entities/user.entity';

@Controller('complaints')
export class ComplaintsController {
  constructor(private readonly complaintsService: ComplaintsService) {}

  @Post()
  create(
    @CurrentUser() user: User,
    @Body() createComplaintDto: CreateComplaintDto,
  ) {
    return this.complaintsService.create(user.client.id, createComplaintDto);
  }

  @Get('my-complaints')
  getMyComplaints(@CurrentUser() user: User) {
    return this.complaintsService.findByClientId(user.client.id);
  }

  @Get('current-client-complaints')
  getCurrentClientComplaints(@CurrentUser() user: User) {
    return this.complaintsService.findByClientId(user.client.id);
  }

  @Roles(UserRole.ADMIN)
  @Get()
  findAll() {
    return this.complaintsService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.complaintsService.findOne(id);
  }

  @Roles(UserRole.ADMIN)
  @Patch(':id')
  update(
    @Param('id') id: string,
    @Body() updateComplaintDto: UpdateComplaintDto,
  ) {
    return this.complaintsService.update(id, updateComplaintDto);
  }

  @Roles(UserRole.ADMIN)
  @Patch(':id/resolve')
  resolveComplaint(@Param('id') id: string) {
    return this.complaintsService.resolveComplaint(id);
  }

  @Roles(UserRole.ADMIN)
  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.complaintsService.remove(id);
  }
}
