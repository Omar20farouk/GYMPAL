import { Client } from 'src/clients/entities/client.entity';
import { Coach } from 'src/coaches/entities/coach.entity';
import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { ComplaintStatus } from '../enums';

@Entity('complaints')
export class Complaint {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column('uuid')
  clientId: string;

  @ManyToOne(() => Client, (client) => client.complaints)
  @JoinColumn({ name: 'client_id' })
  client: Client;

  @Column('uuid')
  coachId: string;

  @ManyToOne(() => Coach, (coach) => coach.complaints)
  @JoinColumn({ name: 'coach_id' })
  coach: Coach;

  @Column('text')
  description: string;

  @Column('text', { nullable: true, array: true })
  images: string[] | null;

  @Column({
    type: 'enum',
    enum: ComplaintStatus,
    default: ComplaintStatus.PENDING,
  })
  status: ComplaintStatus;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
