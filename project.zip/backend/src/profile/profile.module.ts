import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ProfileController } from './profile.controller';
import { ProfileService } from './profile.service';
import { User } from 'src/users/entities/user.entity';
import { Coach } from 'src/coaches/entities/coach.entity';
import { Client } from 'src/clients/entities/client.entity';
import { Subscription } from 'src/subscriptions/entities/subscription.entity';

@Module({
  imports: [TypeOrmModule.forFeature([User, Coach, Client, Subscription])],
  controllers: [ProfileController],
  providers: [ProfileService],
})
export class ProfileModule {}
