import { Body, Controller, Get, Patch } from '@nestjs/common';
import { ProfileService } from './profile.service';
import { AuthGuard } from 'src/auth/guards/auth.guard';
import { CurrentUser } from 'src/common/decorators/current-user.decorator';
import { UpdateClientProfileDto } from './dto/update-client-profile.dto';
import { UpdateCoachProfileDto } from './dto/update-coach-profile.dto';
import { User } from 'src/users/entities/user.entity';

@Controller('profile')
export class ProfileController {
  constructor(private readonly profileService: ProfileService) {}

  @Get()
  getProfile(@CurrentUser() user: User) {
    return this.profileService.getProfile(user.id);
  }

  @Patch('client')
  updateClientProfile(
    @CurrentUser() user: User,
    @Body() updateClientProfileDto: UpdateClientProfileDto,
  ) {
    return this.profileService.updateClientProfile(
      user.id,
      updateClientProfileDto,
    );
  }

  @Patch('coach')
  updateCoachProfile(
    @CurrentUser() user: User,
    @Body() updateCoachProfileDto: UpdateCoachProfileDto,
  ) {
    return this.profileService.updateCoachProfile(
      user.id,
      updateCoachProfileDto,
    );
  }

  @Get('subscriptions')
  getClientSubscriptions(@CurrentUser() user) {
    return this.profileService.getClientSubscriptions(user.id);
  }
}
