import { IsNotEmpty, IsOptional, IsString } from 'class-validator';

export class UpdateClientProfileDto {
  @IsNotEmpty()
  @IsString()
  firstName: string;

  @IsNotEmpty()
  @IsString()
  lastName: string;

  @IsNotEmpty()
  @IsString()
  city: string;
}
