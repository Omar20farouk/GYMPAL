import { IsNotEmpty, IsNumber, IsOptional, IsString } from 'class-validator';

export class UpdateCoachProfileDto {
  @IsNotEmpty()
  @IsString()
  firstName: string;

  @IsNotEmpty()
  @IsString()
  lastName: string;

  @IsNotEmpty()
  @IsString()
  city: string;

  @IsOptional()
  @IsString()
  about?: string;

  @IsNotEmpty()
  @IsNumber()
  experience: number;

  @IsOptional()
  @IsString()
  profilePicture?: string;

  @IsOptional()
  @IsString()
  coverPicture?: string;
}
