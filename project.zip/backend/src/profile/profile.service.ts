import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User } from 'src/users/entities/user.entity';
import { Coach } from 'src/coaches/entities/coach.entity';
import { Client } from 'src/clients/entities/client.entity';
import { Subscription } from 'src/subscriptions/entities/subscription.entity';
import { UpdateClientProfileDto } from './dto/update-client-profile.dto';
import { UpdateCoachProfileDto } from './dto/update-coach-profile.dto';
import { UserRole } from 'src/users/enums';

@Injectable()
export class ProfileService {
  constructor(
    @InjectRepository(User)
    private readonly usersRepository: Repository<User>,
    @InjectRepository(Coach)
    private readonly coachesRepository: Repository<Coach>,
    @InjectRepository(Client)
    private readonly clientsRepository: Repository<Client>,
    @InjectRepository(Subscription)
    private readonly subscriptionsRepository: Repository<Subscription>,
  ) {}

  async getProfile(userId: string) {
    const user = await this.usersRepository.findOne({
      where: { id: userId },
      relations: {
        coach: {
          specialties: true,
        },
        client: true,
        teamMember: true,
      },
    });

    if (!user) {
      throw new NotFoundException('User not found');
    }

    return user;
  }

  async updateClientProfile(
    userId: string,
    updateClientProfileDto: UpdateClientProfileDto,
  ) {
    const user = await this.usersRepository.findOne({
      where: { id: userId },
      relations: { client: true },
    });

    if (!user || user.role !== UserRole.CLIENT) {
      throw new NotFoundException('Client not found');
    }

    // Update user information
    Object.assign(user, {
      firstName: updateClientProfileDto.firstName,
      lastName: updateClientProfileDto.lastName,
      city: updateClientProfileDto.city,
    });

    await this.usersRepository.save(user);

    return user;
  }

  async updateCoachProfile(
    userId: string,
    updateCoachProfileDto: UpdateCoachProfileDto,
  ) {
    const user = await this.usersRepository.findOne({
      where: { id: userId },
      relations: { coach: true },
    });

    if (!user || user.role !== UserRole.COACH) {
      throw new NotFoundException('Coach not found');
    }

    // Update user information
    Object.assign(user, {
      firstName: updateCoachProfileDto.firstName,
      lastName: updateCoachProfileDto.lastName,
      city: updateCoachProfileDto.city,
    });

    // Update coach information
    if (user.coach) {
      Object.assign(user.coach, {
        about: updateCoachProfileDto.about,
        experience: updateCoachProfileDto.experience,
        profilePicture: updateCoachProfileDto.profilePicture,
        coverPicture: updateCoachProfileDto.coverPicture,
      });

      await this.coachesRepository.save(user.coach);
    }

    await this.usersRepository.save(user);

    return user;
  }

  async getClientSubscriptions(userId: string) {
    const user = await this.usersRepository.findOne({
      where: { id: userId },
      relations: { client: true },
    });

    if (!user || user.role !== UserRole.CLIENT || !user.client) {
      throw new NotFoundException('Client not found');
    }

    const subscriptions = await this.subscriptionsRepository.find({
      where: { clientId: user.client.id },
      relations: {
        plan: {
          coach: {
            user: true,
          },
        },
      },
      order: {
        startDate: 'DESC',
      },
    });

    return subscriptions;
  }
}
