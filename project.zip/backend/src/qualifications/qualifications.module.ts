import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Qualification } from './entities/qualification.entity';
import { QualificationsController } from './qualifications.controller';
import { QualificationsService } from './qualifications.service';

@Module({
  imports: [TypeOrmModule.forFeature([Qualification])],
  controllers: [QualificationsController],
  providers: [QualificationsService],
})
export class QualificationsModule {}
