import { Controller, Get } from '@nestjs/common';
import { Public } from 'src/common/decorators/public.decorator';
import { QualificationsService } from './qualifications.service';

@Controller('qualifications')
export class QualificationsController {
  constructor(private readonly qualificationsService: QualificationsService) {}

  @Public()
  @Get()
  findAll() {
    return this.qualificationsService.findAll();
  }
}
