import { Injectable } from '@nestjs/common';
import { FindManyOptions, Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { Qualification } from './entities/qualification.entity';

@Injectable()
export class QualificationsService {
  constructor(
    @InjectRepository(Qualification)
    private readonly QualificationsRepo: Repository<Qualification>,
  ) {}

  findAll(options: FindManyOptions<Qualification> = {}) {
    return this.QualificationsRepo.find(options);
  }
}
