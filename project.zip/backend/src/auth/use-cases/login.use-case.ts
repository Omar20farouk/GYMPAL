import { Injectable, UnauthorizedException } from '@nestjs/common';
import { LoginDto } from '../dto/login.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { User } from 'src/users/entities/user.entity';
import { Repository } from 'typeorm';
import * as bcrypt from 'bcrypt';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class Login {
  constructor(
    @InjectRepository(User) private readonly usersRepo: Repository<User>,
    private readonly jwtService: JwtService,
    private readonly configService: ConfigService,
  ) {}

  async execute(loginDto: LoginDto) {
    const user = await this.usersRepo.findOne({
      where: { email: loginDto.email },
      relations: {
        coach: true,
        client: true,
      },
    });

    if (!user) throw new UnauthorizedException('Wrong email or password');

    const passwordsMatch = await bcrypt.compare(
      loginDto.password,
      user.password,
    );

    if (!passwordsMatch)
      throw new UnauthorizedException('Wrong email or password');

    return {
      ...user,
      password: undefined,
      token: await this.jwtService.signAsync(
        { id: user.id },
        {
          secret: this.configService.getOrThrow('auth.jwtSecret'),
        },
      ),
    };
  }
}
