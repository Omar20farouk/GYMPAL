import {
  BadRequestException,
  ConflictException,
  Injectable,
} from '@nestjs/common';
import { SignUpDto } from '../dto/sign-up.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { User } from 'src/users/entities/user.entity';
import { Repository } from 'typeorm';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { hash } from 'bcrypt';
import { UserRole } from 'src/users/enums';
import { Coach } from 'src/coaches/entities/coach.entity';
import { CoachSpecialty } from 'src/coaches/entities/coach-specialty.entity';
import { Client } from 'src/clients/entities/client.entity';
import { CoachQualification } from 'src/coaches/entities/coach-qualification.entity';

@Injectable()
export class SignUp {
  constructor(
    @InjectRepository(User) private readonly usersRepo: Repository<User>,
    @InjectRepository(Coach) private readonly coachesRepo: Repository<Coach>,
    @InjectRepository(Client) private readonly clientsRepo: Repository<Client>,
    @InjectRepository(CoachSpecialty)
    private readonly coachSpecialtyRepo: Repository<CoachSpecialty>,
    @InjectRepository(CoachQualification)
    private readonly coachQualificationRepo: Repository<CoachQualification>,

    private readonly jwtService: JwtService,
    private readonly configService: ConfigService,
  ) {}

  async execute(signUpDto: SignUpDto) {
    if (signUpDto.password !== signUpDto.confirmPassword)
      throw new BadRequestException('Password do not match.');

    const existingUser = await this.usersRepo.findOne({
      where: { email: signUpDto.email },
      select: { id: true },
    });

    if (existingUser) {
      throw new ConflictException('User with this email already exists.');
    }

    const user = await this.usersRepo.save({
      ...signUpDto,
      password: await hash(signUpDto.password, 10),
    });

    let createdUserRole: Client | Coach;
    if (signUpDto.role === UserRole.COACH) {
      createdUserRole = await this.createCoach(user.id, signUpDto);
    } else {
      createdUserRole = await this.createClient(user.id);
    }

    return {
      ...user,
      ...createdUserRole,
      password: undefined,
      token: await this.jwtService.signAsync(
        { id: user.id },
        {
          secret: this.configService.getOrThrow('auth.jwtSecret'),
        },
      ),
    };
  }

  private async createCoach(userId: string, signUpDto: SignUpDto) {
    const coach = await this.coachesRepo.save({
      userId: userId,
      experience: signUpDto.experience,
    });

    if (signUpDto.specialties) {
      await this.coachSpecialtyRepo.save(
        signUpDto.specialties.map((specialty) => ({
          coachId: coach.id,
          specialtyId: specialty,
        })),
      );
    }

    if (signUpDto.qualifications) {
      await this.coachQualificationRepo.save(
        signUpDto.qualifications.map((qualification) => ({
          coachId: coach.id,
          qualificationId: qualification,
        })),
      );
    }

    return coach;
  }

  private async createClient(userId: string) {
    return this.clientsRepo.save({
      userId: userId,
    });
  }
}
