import { Module } from '@nestjs/common';
import { AuthController } from './auth.controller';
import { Login } from './use-cases/login.use-case';
import { SignUp } from './use-cases/sign-up.use-case';
import { JwtModule } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { UsersModule } from 'src/users/users.module';
import { CoachesModule } from 'src/coaches/coaches.module';
import { ClientsModule } from 'src/clients/clients.module';

@Module({
  imports: [
    JwtModule.registerAsync({
      global: true,
      inject: [ConfigService],
      useFactory: async (configService: ConfigService) => ({
        secret: configService.getOrThrow<string>('auth.jwtSecret'),
        signOptions: { expiresIn: '10d' },
      }),
    }),
    UsersModule,
    ClientsModule,
    CoachesModule,
  ],
  controllers: [AuthController],
  providers: [Login, SignUp],
})
export class AuthModule {}
