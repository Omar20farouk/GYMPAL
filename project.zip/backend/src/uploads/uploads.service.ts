import { Injectable, Logger } from '@nestjs/common';
import { existsSync, mkdirSync } from 'fs';
import { join } from 'path';

@Injectable()
export class UploadsService {
  private readonly logger = new Logger(UploadsService.name);
  private readonly uploadDir: string;

  constructor() {
    // Ensure uploads directory exists
    this.uploadDir = join(process.cwd(), 'uploads');
    this.ensureUploadsDirectoryExists();
  }

  private ensureUploadsDirectoryExists() {
    try {
      if (!existsSync(this.uploadDir)) {
        this.logger.log(`Creating uploads directory at: ${this.uploadDir}`);
        mkdirSync(this.uploadDir, { recursive: true });
      }
    } catch (error) {
      this.logger.error(`Failed to create uploads directory: ${error.message}`);
      throw error;
    }
  }

  getFileUrl(filename: string): string {
    // Return the URL path to access the uploaded file
    return `/uploads/${filename}`;
  }
}
