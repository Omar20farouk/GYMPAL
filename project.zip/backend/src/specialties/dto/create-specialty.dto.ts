export class CreateSpecialtyDto {}
