import {
  Injectable,
  NotFoundException,
  ForbiddenException,
  ConflictException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Team } from './entities/team.entity';
import { TeamMember } from './entities/team-member.entity';
import { User } from 'src/users/entities/user.entity';
import { Coach } from 'src/coaches/entities/coach.entity';
import { CreateTeamDto } from './dto/create-team.dto';
import { UpdateTeamDto } from './dto/update-team.dto';
import { AddTeamMemberDto } from './dto/add-team-member.dto';
import { UpdateTeamMemberDto } from './dto/update-team-member.dto';
import { CreateTeamMemberDto } from './dto/create-team-member.dto';
import { TeamMemberRole } from './enums';
import { UserRole } from 'src/users/enums';
import { hash } from 'bcrypt';
import { CoachesService } from 'src/coaches/coaches.service';

@Injectable()
export class TeamsService {
  constructor(
    @InjectRepository(Team)
    private readonly teamRepository: Repository<Team>,
    @InjectRepository(TeamMember)
    private readonly teamMemberRepository: Repository<TeamMember>,
    @InjectRepository(User)
    private readonly userRepository: Repository<User>,
    @InjectRepository(Coach)
    private readonly coachRepository: Repository<Coach>,
    private readonly coachesService: CoachesService,
  ) {}

  async findOne(id: string) {
    const team = await this.teamRepository.findOne({
      where: { id },
      relations: ['coach', 'coach.user', 'members', 'members.user'],
    });

    if (!team) {
      throw new NotFoundException(`Team with ID ${id} not found`);
    }

    return team;
  }

  async findAll() {
    return this.teamRepository.find({
      relations: ['coach', 'coach.user'],
    });
  }

  async findByCoach(coachId: string) {
    return this.teamRepository.find({
      where: { coachId },
      relations: ['coach', 'coach.user', 'members', 'members.user'],
    });
  }

  async create(userId: string, createTeamDto: CreateTeamDto) {
    // Get coach record for the user
    const coach = await this.coachRepository.findOne({
      where: { userId },
    });

    if (!coach) {
      throw new NotFoundException('Coach profile not found');
    }

    // Check if coach already has a team
    const existingTeam = await this.teamRepository.findOne({
      where: { coachId: coach.id },
    });

    if (existingTeam) {
      throw new ForbiddenException('Coach already has a team');
    }

    // Create a new team
    const team = this.teamRepository.create({
      ...createTeamDto,
      coachId: coach.id,
    });

    return this.teamRepository.save(team);
  }

  async update(teamId: string, userId: string, updateTeamDto: UpdateTeamDto) {
    // Get coach record for the user
    const coach = await this.coachRepository.findOne({
      where: { userId },
    });

    if (!coach) {
      throw new NotFoundException('Coach profile not found');
    }

    // Get the team and verify ownership
    const team = await this.teamRepository.findOne({
      where: { id: teamId },
    });

    if (!team) {
      throw new NotFoundException(`Team with ID ${teamId} not found`);
    }

    if (team.coachId !== coach.id) {
      throw new ForbiddenException(
        'You do not have permission to update this team',
      );
    }

    // Update the team
    Object.assign(team, updateTeamDto);
    return this.teamRepository.save(team);
  }

  async delete(teamId: string, userId: string) {
    // Get coach record for the user
    const coach = await this.coachRepository.findOne({
      where: { userId },
    });

    if (!coach) {
      throw new NotFoundException('Coach profile not found');
    }

    // Get the team and verify ownership
    const team = await this.teamRepository.findOne({
      where: { id: teamId },
    });

    if (!team) {
      throw new NotFoundException(`Team with ID ${teamId} not found`);
    }

    if (team.coachId !== coach.id) {
      throw new ForbiddenException(
        'You do not have permission to delete this team',
      );
    }

    // Delete the team
    await this.teamRepository.remove(team);
    return { success: true };
  }

  async addMember(
    teamId: string,
    userId: string,
    addTeamMemberDto: AddTeamMemberDto,
  ) {
    // Get coach record for the user
    const coach = await this.coachRepository.findOne({
      where: { userId },
    });

    if (!coach) {
      throw new NotFoundException('Coach profile not found');
    }

    // Get the team and verify ownership
    const team = await this.teamRepository.findOne({
      where: { id: teamId },
    });

    if (!team) {
      throw new NotFoundException(`Team with ID ${teamId} not found`);
    }

    if (team.coachId !== coach.id) {
      throw new ForbiddenException(
        'You do not have permission to add members to this team',
      );
    }

    // Verify the user to be added exists
    const userToAdd = await this.userRepository.findOne({
      where: { id: addTeamMemberDto.userId },
    });

    if (!userToAdd) {
      throw new NotFoundException(
        `User with ID ${addTeamMemberDto.userId} not found`,
      );
    }

    // Check if the user is already a member
    const existingMember = await this.teamMemberRepository.findOne({
      where: {
        teamId,
        userId: addTeamMemberDto.userId,
      },
    });

    if (existingMember) {
      throw new ForbiddenException('User is already a member of this team');
    }

    // Create team member
    const teamMember = this.teamMemberRepository.create({
      teamId,
      userId: addTeamMemberDto.userId,
      role: addTeamMemberDto.role || TeamMemberRole.MEMBER,
      position: addTeamMemberDto.position,
    });

    return this.teamMemberRepository.save(teamMember);
  }

  async updateMember(
    teamId: string,
    memberId: string,
    userId: string,
    updateTeamMemberDto: UpdateTeamMemberDto,
  ) {
    // Get coach record for the user
    const coach = await this.coachRepository.findOne({
      where: { userId },
    });

    if (!coach) {
      throw new NotFoundException('Coach profile not found');
    }

    // Get the team and verify ownership
    const team = await this.teamRepository.findOne({
      where: { id: teamId },
    });

    if (!team) {
      throw new NotFoundException(`Team with ID ${teamId} not found`);
    }

    if (team.coachId !== coach.id) {
      throw new ForbiddenException(
        'You do not have permission to update members in this team',
      );
    }

    // Get team member
    const teamMember = await this.teamMemberRepository.findOne({
      where: {
        id: memberId,
        teamId,
      },
    });

    if (!teamMember) {
      throw new NotFoundException(`Team member with ID ${memberId} not found`);
    }

    // Update team member
    Object.assign(teamMember, updateTeamMemberDto);
    return this.teamMemberRepository.save(teamMember);
  }

  async removeMember(teamId: string, memberId: string, userId: string) {
    // Get coach record for the user
    const coach = await this.coachRepository.findOne({
      where: { userId },
    });

    if (!coach) {
      throw new NotFoundException('Coach profile not found');
    }

    // Get the team and verify ownership
    const team = await this.teamRepository.findOne({
      where: { id: teamId },
    });

    if (!team) {
      throw new NotFoundException(`Team with ID ${teamId} not found`);
    }

    if (team.coachId !== coach.id) {
      throw new ForbiddenException(
        'You do not have permission to remove members from this team',
      );
    }

    // Get team member
    const teamMember = await this.teamMemberRepository.findOne({
      where: {
        id: memberId,
        teamId,
      },
    });

    if (!teamMember) {
      throw new NotFoundException(`Team member with ID ${memberId} not found`);
    }

    // Remove team member
    await this.teamMemberRepository.remove(teamMember);
    return { success: true };
  }

  async getTeamMembers(teamId: string) {
    // Check if team exists
    const team = await this.teamRepository.findOne({
      where: { id: teamId },
    });

    if (!team) {
      throw new NotFoundException(`Team with ID ${teamId} not found`);
    }

    // Get all team members
    return this.teamMemberRepository.find({
      where: { teamId },
      relations: ['user'],
    });
  }

  async createTeamMember(
    teamId: string,
    userId: string,
    createTeamMemberDto: CreateTeamMemberDto,
  ) {
    // Get coach record for the user
    const coach = await this.coachRepository.findOne({
      where: { userId },
    });

    if (!coach) {
      throw new NotFoundException('Coach profile not found');
    }

    // Get the team and verify ownership
    const team = await this.teamRepository.findOne({
      where: { id: teamId },
    });

    if (!team) {
      throw new NotFoundException(`Team with ID ${teamId} not found`);
    }

    if (team.coachId !== coach.id) {
      throw new ForbiddenException(
        'You do not have permission to add members to this team',
      );
    }

    // Check if a user with this email already exists
    const existingUser = await this.userRepository.findOne({
      where: { email: createTeamMemberDto.email },
    });

    if (existingUser) {
      throw new ConflictException('User with this email already exists');
    }

    // Create a new user with TEAM_MEMBER role
    const hashedPassword = await hash(createTeamMemberDto.password, 10);
    const newUser = this.userRepository.create({
      firstName: createTeamMemberDto.firstName,
      lastName: createTeamMemberDto.lastName,
      email: createTeamMemberDto.email,
      password: hashedPassword,
      role: UserRole.TEAM_MEMBER,
    });

    const savedUser = await this.userRepository.save(newUser);

    // Create the team member relationship
    const teamMember = this.teamMemberRepository.create({
      teamId,
      userId: savedUser.id,
      role: createTeamMemberDto.role || TeamMemberRole.MEMBER,
      position: createTeamMemberDto.position,
    });

    const savedTeamMember = await this.teamMemberRepository.save(teamMember);

    // Return the team member with user information
    return {
      ...savedTeamMember,
      user: {
        id: savedUser.id,
        firstName: savedUser.firstName,
        lastName: savedUser.lastName,
        email: savedUser.email,
        role: savedUser.role,
      },
    };
  }

  async getCoachClients(teamId: string, user: User) {
    // First, verify that the team exists
    const team = await this.teamRepository.findOne({
      where: { id: teamId },
      relations: ['coach'],
    });

    if (!team) {
      throw new NotFoundException(`Team with ID ${teamId} not found`);
    }

    // If the user is a coach, check if they own the team
    if (user.role === UserRole.COACH) {
      if (user.coach.id !== team.coachId) {
        throw new ForbiddenException('You do not have access to this team');
      }
      // Coach owns the team, get their clients
      return this.coachesService.getClients(user.id);
    }
    // If the user is a team member, check if they belong to the team
    else if (user.role === UserRole.TEAM_MEMBER) {
      const teamMember = await this.teamMemberRepository.findOne({
        where: {
          teamId,
          userId: user.id,
        },
      });

      if (!teamMember) {
        throw new ForbiddenException('You do not have access to this team');
      }

      // Team member belongs to the team, get the coach clients
      const coachId = team.coach.userId;
      return this.coachesService.getClients(coachId);
    }

    throw new ForbiddenException(
      'You do not have permission to access coach clients',
    );
  }
}
