export enum TeamMemberRole {
  MEMBER = 'MEMBER',
  ADMIN = 'ADMIN',
}
