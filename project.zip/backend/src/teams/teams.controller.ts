import {
  Controller,
  Get,
  Post,
  Body,
  Param,
  Delete,
  Put,
} from '@nestjs/common';
import { TeamsService } from './teams.service';
import { CreateTeamDto } from './dto/create-team.dto';
import { UpdateTeamDto } from './dto/update-team.dto';
import { AddTeamMemberDto } from './dto/add-team-member.dto';
import { UpdateTeamMemberDto } from './dto/update-team-member.dto';
import { CreateTeamMemberDto } from './dto/create-team-member.dto';
import { Roles } from 'src/common/decorators/roles.decorator';
import { UserRole } from 'src/users/enums';
import { CurrentUser } from 'src/common/decorators/current-user.decorator';
import { User } from 'src/users/entities/user.entity';

@Controller('teams')
export class TeamsController {
  constructor(private readonly teamsService: TeamsService) {}

  @Get()
  @Roles(UserRole.ADMIN, UserRole.COACH, UserRole.CLIENT)
  findAll() {
    return this.teamsService.findAll();
  }

  @Get('coach')
  @Roles(UserRole.COACH)
  findTeamByCoach(@CurrentUser() user: User) {
    return this.teamsService.findByCoach(user.coach.id);
  }

  @Get(':id')
  @Roles(UserRole.ADMIN, UserRole.COACH, UserRole.CLIENT, UserRole.TEAM_MEMBER)
  findOne(@Param('id') id: string) {
    return this.teamsService.findOne(id);
  }

  @Get(':id/clients')
  @Roles(UserRole.COACH, UserRole.TEAM_MEMBER)
  getCoachClients(@Param('id') id: string, @CurrentUser() user: User) {
    return this.teamsService.getCoachClients(id, user);
  }

  @Post()
  @Roles(UserRole.COACH)
  create(
    @CurrentUser('id') userId: string,
    @Body() createTeamDto: CreateTeamDto,
  ) {
    return this.teamsService.create(userId, createTeamDto);
  }

  @Put(':id')
  @Roles(UserRole.COACH)
  update(
    @Param('id') id: string,
    @CurrentUser('id') userId: string,
    @Body() updateTeamDto: UpdateTeamDto,
  ) {
    return this.teamsService.update(id, userId, updateTeamDto);
  }

  @Delete(':id')
  @Roles(UserRole.COACH)
  remove(@Param('id') id: string, @CurrentUser('id') userId: string) {
    return this.teamsService.delete(id, userId);
  }

  @Get(':id/members')
  @Roles(UserRole.ADMIN, UserRole.COACH, UserRole.CLIENT, UserRole.TEAM_MEMBER)
  getTeamMembers(@Param('id') id: string) {
    return this.teamsService.getTeamMembers(id);
  }

  @Post(':id/members')
  @Roles(UserRole.COACH)
  addMember(
    @Param('id') id: string,
    @CurrentUser('id') userId: string,
    @Body() addTeamMemberDto: AddTeamMemberDto,
  ) {
    return this.teamsService.addMember(id, userId, addTeamMemberDto);
  }

  @Put(':id/members/:memberId')
  @Roles(UserRole.COACH)
  updateMember(
    @Param('id') id: string,
    @Param('memberId') memberId: string,
    @CurrentUser('id') userId: string,
    @Body() updateTeamMemberDto: UpdateTeamMemberDto,
  ) {
    return this.teamsService.updateMember(
      id,
      memberId,
      userId,
      updateTeamMemberDto,
    );
  }

  @Delete(':id/members/:memberId')
  @Roles(UserRole.COACH)
  removeMember(
    @Param('id') id: string,
    @Param('memberId') memberId: string,
    @CurrentUser('id') userId: string,
  ) {
    return this.teamsService.removeMember(id, memberId, userId);
  }

  @Post(':id/members/create')
  @Roles(UserRole.COACH)
  createTeamMember(
    @Param('id') id: string,
    @CurrentUser('id') userId: string,
    @Body() createTeamMemberDto: CreateTeamMemberDto,
  ) {
    return this.teamsService.createTeamMember(id, userId, createTeamMemberDto);
  }
}
