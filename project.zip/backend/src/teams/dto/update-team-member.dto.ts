import { IsOptional, IsString, IsEnum, MaxLength } from 'class-validator';
import { TeamMemberRole } from '../enums';

export class UpdateTeamMemberDto {
  @IsOptional()
  @IsEnum(TeamMemberRole)
  role?: TeamMemberRole;

  @IsOptional()
  @IsString()
  @MaxLength(255)
  position?: string;
}
