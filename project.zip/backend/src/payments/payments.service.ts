import {
  Injectable,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ConfigService } from '@nestjs/config';
import Stripe from 'stripe';
import { CreatePaymentDto } from './dto/create-payment.dto';
import { UpdatePaymentDto } from './dto/update-payment.dto';
import { Payment, PaymentStatus } from './entities/payment.entity';
import { Plan } from '../plans/entities/plan.entity';
import { Subscription } from 'src/subscriptions/entities/subscription.entity';
import { Coach } from 'src/coaches/entities/coach.entity';
import { Chat } from 'src/chat/entities/chat.entity';

@Injectable()
export class PaymentsService {
  private stripe: Stripe;

  constructor(
    @InjectRepository(Payment)
    private paymentRepository: Repository<Payment>,
    @InjectRepository(Plan)
    private planRepository: Repository<Plan>,
    @InjectRepository(Subscription)
    private subscriptionsRepository: Repository<Subscription>,
    @InjectRepository(Coach)
    private coachesRepository: Repository<Coach>,
    @InjectRepository(Chat)
    private chatRepository: Repository<Chat>,
    private configService: ConfigService,
  ) {
    // Initialize Stripe with the API key from environment variables
    this.stripe = new Stripe(
      this.configService.get<string>('STRIPE_SECRET_KEY') as string,
      {
        apiVersion: '2025-04-30.basil',
      },
    );
  }

  async createPaymentIntent(
    createPaymentDto: CreatePaymentDto,
    clientId: string,
  ) {
    // Get the plan details to determine the amount
    const plan = await this.planRepository.findOne({
      where: { id: createPaymentDto.planId },
    });

    if (!plan) {
      throw new NotFoundException('Plan not found');
    }

    // Create a payment intent with Stripe
    const paymentIntent = await this.stripe.paymentIntents.create({
      amount: Math.round(plan.price * 100), // Convert to cents
      currency: 'usd',
      metadata: {
        planId: createPaymentDto.planId,
        clientId,
      },
    });

    // Create a payment record in the database
    const payment = this.paymentRepository.create({
      clientId,
      planId: createPaymentDto.planId,
      coachId: plan.coachId,
      amount: plan.price,
      paymentIntentId: paymentIntent.id,
      status: PaymentStatus.PENDING,
    });

    await this.paymentRepository.save(payment);

    return {
      id: paymentIntent.id,
      clientSecret: paymentIntent.client_secret,
      amount: plan.price,
      currency: 'usd',
      status: paymentIntent.status,
    };
  }

  async confirmPayment(paymentIntentId: string) {
    // Retrieve the payment intent from Stripe
    const paymentIntent =
      await this.stripe.paymentIntents.retrieve(paymentIntentId);

    if (!paymentIntent) {
      throw new NotFoundException('Payment intent not found');
    }

    if (paymentIntent.status !== 'succeeded') {
      throw new BadRequestException('Payment has not been completed');
    }

    // Update the payment record in the database
    const payment = await this.paymentRepository.findOne({
      where: { paymentIntentId },
      relations: {
        plan: true,
      },
    });

    if (!payment) {
      throw new NotFoundException('Payment record not found');
    }

    payment.status = PaymentStatus.SUCCEEDED;
    await this.paymentRepository.save(payment);
    await this.subscriptionsRepository.save({
      clientId: payment.clientId,
      planId: payment.planId,
      startDate: new Date(),
      endDate: this.getSubscriptionEndDate(
        payment.plan.duration,
        payment.plan.durationUnit,
      ),
      isActive: true,
    });
    await this.coachesRepository.increment(
      { id: payment.coachId },
      'balance',
      payment.amount - payment.amount * 0.2,
    );
    await this.chatRepository.upsert(
      {
        clientId: payment.clientId,
        coachId: payment.coachId,
      },
      {
        conflictPaths: ['clientId', 'coachId'],
        skipUpdateIfNoValuesChanged: true,
      },
    );

    return {
      success: true,
      message: 'Payment confirmed successfully',
      payment,
    };
  }

  async getPaymentStatus(paymentIntentId: string) {
    const paymentIntent =
      await this.stripe.paymentIntents.retrieve(paymentIntentId);

    if (!paymentIntent) {
      throw new NotFoundException('Payment intent not found');
    }

    return {
      id: paymentIntent.id,
      status: paymentIntent.status,
      amount: paymentIntent.amount / 100, // Convert from cents
      currency: paymentIntent.currency,
    };
  }

  getSubscriptionEndDate(duration: number, durationUnit: string) {
    const parsedDuration = parseInt(duration.toString(), 10);
    const now = new Date();
    let endDate = new Date();

    switch (durationUnit) {
      case 'day':
        endDate.setDate(now.getDate() + parsedDuration);
        break;
      case 'week':
        endDate.setDate(now.getDate() + parsedDuration * 7);
        break;
      case 'month':
        endDate.setMonth(now.getMonth() + parsedDuration);
        break;
      default:
        throw new BadRequestException('Invalid duration unit');
    }

    return endDate;
  }

  findAll() {
    return this.paymentRepository.find({
      relations: {
        client: {
          user: true,
        },
        coach: {
          user: true,
        },
        plan: true,
      },
    });
  }

  async findOne(id: string) {
    const payment = await this.paymentRepository.findOne({
      where: { id },
      relations: ['client', 'coach', 'plan'],
    });

    if (!payment) {
      throw new NotFoundException(`Payment with ID ${id} not found`);
    }

    return payment;
  }

  async update(id: string, updatePaymentDto: UpdatePaymentDto) {
    const payment = await this.findOne(id);
    // Implement update logic based on your requirements
    return this.paymentRepository.save(payment);
  }

  async remove(id: string) {
    const payment = await this.findOne(id);
    return this.paymentRepository.remove(payment);
  }
}
