import { forwardRef, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PaymentsService } from './payments.service';
import { PaymentsController } from './payments.controller';
import { Payment } from './entities/payment.entity';
import { PlansModule } from 'src/plans/plans.module';
import { SubscriptionsModule } from 'src/subscriptions/subscriptions.module';
import { CoachesModule } from 'src/coaches/coaches.module';
import { ChatModule } from 'src/chat/chat.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([Payment]),
    PlansModule,
    SubscriptionsModule,
    forwardRef(() => CoachesModule),
    ChatModule,
  ],
  controllers: [PaymentsController],
  providers: [PaymentsService],
  exports: [TypeOrmModule],
})
export class PaymentsModule {}
