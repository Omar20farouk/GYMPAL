import { User } from 'src/users/entities/user.entity';
import {
  AfterLoad,
  Column,
  Entity,
  JoinColumn,
  JoinTable,
  ManyToMany,
  OneToMany,
  OneToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { CoachStatus } from '../enums';
import { Review } from 'src/reviews/entities/review.entity';
import { Complaint } from 'src/complaints/entities/complaint.entity';
import { Plan } from 'src/plans/entities/plan.entity';
import { Specialty } from 'src/specialties/entities/specialty.entity';
import { Qualification } from 'src/qualifications/entities/qualification.entity';

@Entity('coaches')
export class Coach {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column('uuid')
  userId: string;

  @OneToOne(() => User, (user) => user.coach)
  @JoinColumn({ name: 'user_id' })
  user: User;

  @Column('enum', { enum: CoachStatus, default: CoachStatus.PENDING })
  status: CoachStatus;

  @Column('float')
  experience: number;

  @Column({ type: 'varchar', length: 500, nullable: true })
  about?: string;

  @ManyToMany(() => Specialty, (specialty) => specialty.coaches)
  @JoinTable({
    name: 'coaches_specialties',
    synchronize: false,
    joinColumn: { name: 'coach_id', referencedColumnName: 'id' },
    inverseJoinColumn: { name: 'specialty_id', referencedColumnName: 'id' },
  })
  specialties: Specialty[];

  @ManyToMany(() => Qualification, (qualification) => qualification.coaches)
  @JoinTable({
    name: 'coaches_qualifications',
    synchronize: false,
    joinColumn: { name: 'coach_id', referencedColumnName: 'id' },
    inverseJoinColumn: { name: 'qualification_id', referencedColumnName: 'id' },
  })
  qualifications: Qualification[];

  @OneToMany(() => Review, (review) => review.coach)
  reviews: Review[];

  averageRating: number;

  @Column({ type: 'numeric', default: 0 })
  balance: number;

  @OneToMany(() => Complaint, (complaint) => complaint.coach)
  complaints: Complaint[];

  @OneToMany(() => Plan, (plan) => plan.coach)
  plans: Plan[];

  @Column({ type: 'text', nullable: true })
  profilePicture: string | null;

  @Column({ type: 'text', nullable: true })
  coverPicture: string | null;

  @AfterLoad()
  calculateAverageRating() {
    if (this.reviews && this.reviews.length > 0) {
      const totalRating = this.reviews.reduce(
        (acc, review) => acc + +review.rating,
        0,
      );
      this.averageRating = totalRating / this.reviews.length;
    } else {
      this.averageRating = 0;
    }
  }

  @AfterLoad()
  setImageUrls() {
    if (this.profilePicture) {
      this.profilePicture = `${process.env.BACKEND_URL}${this.profilePicture}`;
    }
    if (this.coverPicture) {
      this.coverPicture = `${process.env.BACKEND_URL}${this.coverPicture}`;
    }
  }
}
