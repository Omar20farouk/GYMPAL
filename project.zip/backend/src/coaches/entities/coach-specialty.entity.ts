import { Coach } from 'src/coaches/entities/coach.entity';
import { Specialty } from 'src/specialties/entities/specialty.entity';
import { Entity, JoinColumn, ManyToOne, PrimaryColumn } from 'typeorm';

@Entity('coaches_specialties')
export class CoachSpecialty {
  @PrimaryColumn('uuid')
  coachId: string;

  @ManyToOne(() => Coach)
  @JoinColumn({ name: 'coach_id' })
  coach: Coach;

  @PrimaryColumn('uuid')
  specialtyId: string;

  @ManyToOne(() => Specialty)
  @JoinColumn({ name: 'specialty_id' })
  specialty: Specialty;
}
