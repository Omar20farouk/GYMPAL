import { Coach } from 'src/coaches/entities/coach.entity';
import { Qualification } from 'src/qualifications/entities/qualification.entity';
import { Entity, JoinColumn, ManyToOne, PrimaryColumn } from 'typeorm';

@Entity('coaches_qualifications')
export class CoachQualification {
  @PrimaryColumn('uuid')
  coachId: string;

  @ManyToOne(() => Coach)
  @JoinColumn({ name: 'coach_id' })
  coach: Coach;

  @PrimaryColumn('uuid')
  qualificationId: string;

  @ManyToOne(() => Qualification)
  @JoinColumn({ name: 'qualification_id' })
  qualification: Qualification;
}
