export class SubscriptionDto {
  id: string;
  clientName: string;
  amount: number;
  status: 'active' | 'cancelled' | 'pending';
  planName: string;
  startDate: Date;
  endDate: Date;
}

export class CoachEarningsDto {
  currentBalance: number;
  totalEarnings: number;
  pendingPayouts: number;
  subscriptions: SubscriptionDto[];
}
