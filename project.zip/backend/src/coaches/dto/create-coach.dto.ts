export class CreateCoachDto {}
