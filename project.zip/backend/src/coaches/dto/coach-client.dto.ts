export class CoachClientDto {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  subscriptionStatus: 'active' | 'expired' | 'cancelled' | 'none';
  subscriptionPlan?: string;
  startDate?: Date;
  endDate?: Date;
  lastInteraction?: Date;
}
