export interface ClientGrowth {
  count: number;
  growth: number;
}

export interface RecentClient {
  id: string;
  name: string;
  initials: string;
  planName: string;
  startDate: Date;
}

export interface RecentMessage {
  id: string;
  clientId: string;
  clientName: string;
  content: string;
  sentAt: Date;
}

export class CoachDashboardDto {
  totalClients: number;
  activePlans: number;
  monthlyEarnings: number;
  earningsGrowth: number;
  recentClients: RecentClient[];
  recentMessages: RecentMessage[];
}
