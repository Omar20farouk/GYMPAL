import {
  ConflictException,
  Injectable,
  NotFoundException,
  UnauthorizedException,
} from '@nestjs/common';
import { UpdateCoachDto } from './dto/update-coach.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Coach } from './entities/coach.entity';
import {
  Between,
  FindManyOptions,
  FindOneOptions,
  MoreThan,
  Repository,
} from 'typeorm';
import { UserRole } from 'src/users/enums';
import { CoachStatus } from './enums';
import { CoachEarningsDto, SubscriptionDto } from './dto/coach-earnings.dto';
import { CoachClientDto } from './dto/coach-client.dto';
import { Subscription } from 'src/subscriptions/entities/subscription.entity';
import { Payment } from 'src/payments/entities/payment.entity';
import { PaymentStatus } from 'src/payments/entities/payment.entity';
import { Message } from 'src/chat/entities/message.entity';
import { Plan } from 'src/plans/entities/plan.entity';
import { CoachDashboardDto } from './dto/coach-dashboard.dto';
import { CreateReviewDto } from 'src/reviews/dto/create-review.dto';
import { Review } from 'src/reviews/entities/review.entity';

@Injectable()
export class CoachesService {
  constructor(
    @InjectRepository(Coach) private readonly coachesRepo: Repository<Coach>,
    @InjectRepository(Subscription)
    private readonly subscriptionsRepo: Repository<Subscription>,
    @InjectRepository(Payment)
    private readonly paymentsRepo: Repository<Payment>,
    @InjectRepository(Message)
    private readonly messagesRepo: Repository<Message>,
    @InjectRepository(Plan)
    private readonly plansRepo: Repository<Plan>,
    @InjectRepository(Review)
    private readonly reviewsRepo: Repository<Review>,
  ) {}

  findAll(currentUserRole: UserRole, filters: any) {
    const options: FindManyOptions<Coach> = {
      relations: {
        user: true,
        specialties: true,
        qualifications: true,
        plans: true,
        reviews: true,
      },
    };

    if (currentUserRole === UserRole.CLIENT) {
      options.where = {
        ...options.where,
        status: CoachStatus.APPROVED,
      };
    }

    if (filters.specialty) {
      options.where = {
        ...options.where,
        specialties: {
          id: filters.specialty,
        },
      };
    }

    // Get all coaches first
    return this.coachesRepo.find(options).then((coaches) => {
      // If price range is provided, filter coaches by their minimum plan price
      if (
        filters.priceRange &&
        Array.isArray(filters.priceRange) &&
        filters.priceRange.length === 2
      ) {
        const [minPrice, maxPrice] = filters.priceRange;

        return coaches.filter((coach) => {
          // If coach has no plans, exclude from results
          if (!coach.plans || coach.plans.length === 0) return false;

          // Find the minimum priced plan for this coach
          const minPlanPrice = Math.min(
            ...coach.plans.map((plan) => Number(plan.price)),
          );

          // Check if the minimum plan price is within the requested range
          return minPlanPrice >= minPrice && minPlanPrice <= maxPrice;
        });
      }

      return coaches;
    });
  }

  findOne(options: FindOneOptions<Coach> = {}) {
    return this.coachesRepo.findOne(options);
  }

  update(id: number, updateCoachDto: UpdateCoachDto) {
    return `This action updates a #${id} coach`;
  }

  remove(id: number) {
    return `This action removes a #${id} coach`;
  }

  async getEarnings(userId: string): Promise<CoachEarningsDto> {
    // Get the coach record for this user
    const coach = await this.coachesRepo.findOne({
      where: { userId },
      relations: ['user'],
    });

    if (!coach) {
      throw new Error('Coach not found');
    }

    // Get the coach's subscriptions
    const subscriptions = await this.subscriptionsRepo.find({
      where: {
        plan: {
          coachId: coach.id,
        },
      },
      relations: ['client', 'client.user', 'plan'],
    });

    // Get payments for this coach
    const payments = await this.paymentsRepo.find({
      where: {
        coachId: coach.id,
      },
    });

    // Calculate earnings
    const totalEarnings = payments
      .filter((payment) => payment.status === PaymentStatus.SUCCEEDED)
      .reduce((sum, payment) => sum + Number(payment.amount), 0);

    const pendingPayouts = payments
      .filter((payment) => payment.status === PaymentStatus.PENDING)
      .reduce((sum, payment) => sum + Number(payment.amount), 0);

    // Current balance is stored in the coach entity
    const currentBalance = Number(coach.balance);

    // Map subscriptions to DTO format
    const subscriptionDtos: SubscriptionDto[] = subscriptions.map(
      (subscription) => {
        // Determine status based on dates and active flag
        let status: 'active' | 'cancelled' | 'pending' = 'active';
        const now = new Date();

        if (!subscription.isActive) {
          status = 'cancelled';
        } else if (subscription.startDate > now) {
          status = 'pending';
        } else if (subscription.endDate < now) {
          status = 'cancelled';
        }

        return {
          id: subscription.id,
          clientName: `${subscription.client.user.firstName} ${subscription.client.user.lastName}`,
          amount: Number(subscription.plan.price),
          status,
          planName: subscription.plan.name,
          startDate: subscription.startDate,
          endDate: subscription.endDate,
        };
      },
    );

    return {
      currentBalance,
      totalEarnings,
      pendingPayouts,
      subscriptions: subscriptionDtos,
    };
  }

  async getClients(userId: string): Promise<CoachClientDto[]> {
    // Get the coach record for this user
    const coach = await this.coachesRepo.findOne({
      where: { userId },
    });

    if (!coach) {
      throw new NotFoundException('Coach not found');
    }

    // Get subscriptions for this coach's plans
    const subscriptions = await this.subscriptionsRepo.find({
      where: {
        plan: {
          coachId: coach.id,
        },
      },
      relations: ['client', 'client.user', 'plan'],
    });

    // Get unique clients from subscriptions
    const clientIds = [...new Set(subscriptions.map((sub) => sub.clientId))];

    // Get the last message for each client to determine last interaction
    const lastInteractions = await Promise.all(
      clientIds.map(async (clientId) => {
        const lastMessage = await this.messagesRepo.findOne({
          where: [
            {
              senderId: clientId,
              senderType: 'CLIENT',
            },
            {
              senderId: coach.id,
              senderType: 'COACH',
            },
          ],
          order: { sentAt: 'DESC' },
        });
        return { clientId, lastInteractionDate: lastMessage?.sentAt };
      }),
    );

    // Map to result DTOs
    const result: CoachClientDto[] = [];
    const today = new Date();

    for (const clientId of clientIds) {
      // Get active subscription for this client if any
      const activeSubscription = subscriptions.find(
        (sub) =>
          sub.clientId === clientId && sub.isActive && sub.endDate >= today,
      );

      // Get all subscriptions for this client to determine status
      const clientSubscriptions = subscriptions.filter(
        (sub) => sub.clientId === clientId,
      );
      const hasExpiredSubscription = clientSubscriptions.some(
        (sub) => sub.endDate < today && sub.isActive,
      );
      const hasCancelledSubscription = clientSubscriptions.some(
        (sub) => !sub.isActive,
      );

      // Determine subscription status
      let subscriptionStatus: 'active' | 'expired' | 'cancelled' | 'none' =
        'none';
      if (activeSubscription) {
        subscriptionStatus = 'active';
      } else if (hasCancelledSubscription) {
        subscriptionStatus = 'cancelled';
      } else if (hasExpiredSubscription) {
        subscriptionStatus = 'expired';
      }

      // Get client's user info
      const clientInfo = clientSubscriptions[0]?.client;
      if (clientInfo && clientInfo.user) {
        const lastInteraction = lastInteractions.find(
          (li) => li.clientId === clientId,
        );

        result.push({
          id: clientInfo.id,
          name: `${clientInfo.user.firstName} ${clientInfo.user.lastName}`,
          email: clientInfo.user.email,
          // Use an avatar if available in your User entity, otherwise it will be undefined
          subscriptionStatus,
          subscriptionPlan: activeSubscription?.plan.name,
          startDate: activeSubscription?.startDate,
          endDate: activeSubscription?.endDate,
          lastInteraction: lastInteraction?.lastInteractionDate,
        });
      }
    }

    // Sort by last interaction, most recent first
    return result.sort((a, b) => {
      if (!a.lastInteraction) return 1;
      if (!b.lastInteraction) return -1;
      return (
        new Date(b.lastInteraction).getTime() -
        new Date(a.lastInteraction).getTime()
      );
    });
  }

  async getDashboardStats(userId: string): Promise<CoachDashboardDto> {
    // Get the coach record for this user
    const coach = await this.coachesRepo.findOne({
      where: { userId },
    });

    if (!coach) {
      throw new NotFoundException('Coach not found');
    }

    // Get the current date
    const today = new Date();
    const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    const firstDayOfLastMonth = new Date(
      today.getFullYear(),
      today.getMonth() - 1,
      1,
    );
    const lastDayOfLastMonth = new Date(
      today.getFullYear(),
      today.getMonth(),
      0,
    );

    // Get total unique clients from subscriptions
    const allSubscriptions = await this.subscriptionsRepo.find({
      where: {
        plan: {
          coachId: coach.id,
        },
      },
      relations: ['client', 'client.user', 'plan'],
    });
    const uniqueClientIds = [
      ...new Set(allSubscriptions.map((sub) => sub.clientId)),
    ];
    const totalClients = uniqueClientIds.length;

    // Get active plans count
    const activePlans = await this.plansRepo.count({
      where: {
        coachId: coach.id,
      },
    });

    // Get monthly earnings and growth
    const currentMonthPayments = await this.paymentsRepo.find({
      where: {
        coachId: coach.id,
        status: PaymentStatus.SUCCEEDED,
        createdAt: MoreThan(firstDayOfMonth),
      },
    });

    const lastMonthPayments = await this.paymentsRepo.find({
      where: {
        coachId: coach.id,
        status: PaymentStatus.SUCCEEDED,
        createdAt: Between(firstDayOfLastMonth, lastDayOfLastMonth),
      },
    });

    const currentMonthEarnings = currentMonthPayments.reduce(
      (sum, payment) => sum + Number(payment.amount),
      0,
    );

    const lastMonthEarnings = lastMonthPayments.reduce(
      (sum, payment) => sum + Number(payment.amount),
      0,
    );

    // Calculate earnings growth percentage
    const earningsGrowth =
      lastMonthEarnings === 0
        ? 100 // If last month was 0, the growth is set to 100%
        : Math.round(
            ((currentMonthEarnings - lastMonthEarnings) / lastMonthEarnings) *
              100,
          );

    // Get recent clients (subscriptions ordered by start date)
    const recentSubscriptions = await this.subscriptionsRepo.find({
      where: {
        plan: {
          coachId: coach.id,
        },
        isActive: true,
      },
      relations: ['client', 'client.user', 'plan'],
      order: {
        startDate: 'DESC',
      },
      take: 3,
    });

    const recentClients = recentSubscriptions.map((sub) => ({
      id: sub.clientId,
      name: `${sub.client.user.firstName} ${sub.client.user.lastName}`,
      initials: `${sub.client.user.firstName.charAt(0)}${sub.client.user.lastName.charAt(0)}`,
      planName: sub.plan.name,
      startDate: sub.startDate,
    }));

    // Get recent messages
    const recentMessages = await this.messagesRepo.find({
      where: [
        {
          chat: {
            coachId: coach.id,
          },
          senderType: 'CLIENT',
        },
      ],
      relations: ['chat', 'chat.client', 'chat.client.user'],
      order: {
        sentAt: 'DESC',
      },
      take: 3,
    });

    const formattedRecentMessages = recentMessages.map((msg) => ({
      id: msg.id,
      clientId: msg.chat.clientId,
      clientName: `${msg.chat.client.user.firstName} ${msg.chat.client.user.lastName}`,
      content: msg.content,
      sentAt: msg.sentAt,
    }));

    return {
      totalClients,
      activePlans,
      monthlyEarnings: currentMonthEarnings,
      earningsGrowth,
      recentClients,
      recentMessages: formattedRecentMessages,
    };
  }

  async createReview(
    clientId: string,
    coachId: string,
    createReviewDto: CreateReviewDto,
  ) {
    const reviewExists = await this.reviewsRepo.findOne({
      where: {
        clientId,
        coachId,
      },
    });

    if (reviewExists) {
      throw new ConflictException('You have already reviewed this coach');
    }

    const subscriptions = await this.subscriptionsRepo.find({
      where: {
        clientId,
        plan: {
          coachId,
        },
      },
      relations: {
        plan: true,
      },
    });

    if (!subscriptions || subscriptions.length === 0) {
      throw new UnauthorizedException('No subscription found for this coach');
    }

    return this.reviewsRepo.save({
      ...createReviewDto,
      clientId,
    });
  }
}
