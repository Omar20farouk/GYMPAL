import { forwardRef, Module } from '@nestjs/common';
import { CoachesService } from './coaches.service';
import { CoachesController } from './coaches.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Coach } from './entities/coach.entity';
import { SubscriptionsModule } from 'src/subscriptions/subscriptions.module';
import { ChatModule } from 'src/chat/chat.module';
import { PaymentsModule } from 'src/payments/payments.module';
import { CoachSpecialty } from './entities/coach-specialty.entity';
import { CoachQualification } from './entities/coach-qualification.entity';
import { ReviewsModule } from 'src/reviews/reviews.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([Coach, CoachSpecialty, CoachQualification]),
    SubscriptionsModule,
    ReviewsModule,
    forwardRef(() => ChatModule),
    forwardRef(() => PaymentsModule),
  ],
  controllers: [CoachesController],
  providers: [CoachesService],
  exports: [TypeOrmModule, CoachesService],
})
export class CoachesModule {}
