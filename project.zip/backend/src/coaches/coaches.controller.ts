import {
  Controller,
  Get,
  Body,
  Patch,
  Param,
  Delete,
  Query,
  Post,
} from '@nestjs/common';
import { CoachesService } from './coaches.service';
import { UpdateCoachDto } from './dto/update-coach.dto';
import { CurrentUser } from 'src/common/decorators/current-user.decorator';
import { UserRole } from 'src/users/enums';
import { Roles } from 'src/common/decorators/roles.decorator';
import { User } from 'src/users/entities/user.entity';
import { CreateReviewDto } from 'src/reviews/dto/create-review.dto';

@Controller('coaches')
export class CoachesController {
  constructor(private readonly coachesService: CoachesService) {}

  @Get()
  findAll(@CurrentUser('role') role: UserRole, @Query() query: any) {
    return this.coachesService.findAll(role, query);
  }

  @Get('earnings')
  @Roles(UserRole.COACH)
  getEarnings(@CurrentUser('id') userId: string) {
    return this.coachesService.getEarnings(userId);
  }

  @Get('clients')
  @Roles(UserRole.COACH)
  getClients(@CurrentUser('id') userId: string) {
    return this.coachesService.getClients(userId);
  }

  @Get('dashboard-stats')
  @Roles(UserRole.COACH)
  getDashboardStats(@CurrentUser() user: User) {
    return this.coachesService.getDashboardStats(user.id);
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.coachesService.findOne({
      where: { id },
      relations: {
        user: true,
        plans: true,
        specialties: true,
        qualifications: true,
        reviews: {
          client: {
            user: true,
          },
        },
      },
    });
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateCoachDto: UpdateCoachDto) {
    return this.coachesService.update(+id, updateCoachDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.coachesService.remove(+id);
  }

  @Post(':id/reviews')
  createReview(
    @CurrentUser() user: User,
    @Param('id') id: string,
    @Body() createReviewDto: CreateReviewDto,
  ) {
    return this.coachesService.createReview(
      user.client.id,
      id,
      createReviewDto,
    );
  }
}
