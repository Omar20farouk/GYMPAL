import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CreateSubscriptionDto } from './dto/create-subscription.dto';
import { UpdateSubscriptionDto } from './dto/update-subscription.dto';
import { Subscription } from './entities/subscription.entity';
import { Plan } from '../plans/entities/plan.entity';

@Injectable()
export class SubscriptionsService {
  constructor(
    @InjectRepository(Subscription)
    private subscriptionsRepository: Repository<Subscription>,
    @InjectRepository(Plan)
    private plansRepository: Repository<Plan>,
  ) {}

  create(createSubscriptionDto: CreateSubscriptionDto) {
    return 'This action adds a new subscription';
  }

  findAll() {
    return `This action returns all subscriptions`;
  }

  findOne(id: number) {
    return `This action returns a #${id} subscription`;
  }

  update(id: number, updateSubscriptionDto: UpdateSubscriptionDto) {
    return `This action updates a #${id} subscription`;
  }

  remove(id: number) {
    return `This action removes a #${id} subscription`;
  }

  async clientHasActiveSubscriptionToCoach(
    clientId: string,
    coachId: string,
  ): Promise<boolean> {
    // Get all active subscriptions for this client
    const activeSubscriptions = await this.subscriptionsRepository.find({
      where: {
        clientId,
        isActive: true,
      },
      relations: {
        plan: true,
      },
    });

    // Check if any subscription's plan belongs to the specified coach
    return activeSubscriptions.some(
      (subscription) => subscription.plan.coachId === coachId,
    );
  }
}
