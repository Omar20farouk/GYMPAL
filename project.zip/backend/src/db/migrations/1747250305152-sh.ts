import { MigrationInterface, QueryRunner } from "typeorm";

export class Sh1747250305152 implements MigrationInterface {
    name = 'Sh1747250305152'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "public"."users_role_enum" AS ENUM('CLIENT', 'COACH', 'ADMIN')`);
        await queryRunner.query(`CREATE TABLE "users" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "first_name" character varying NOT NULL, "last_name" character varying NOT NULL, "email" character varying NOT NULL, "password" character varying NOT NULL, "city" character varying(255) NOT NULL, "role" "public"."users_role_enum" NOT NULL, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_at" TIMESTAMP NOT NULL DEFAULT now(), CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE ("email"), CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TABLE "reviews" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "coach_id" uuid NOT NULL, "client_id" uuid NOT NULL, "rating" numeric NOT NULL, "comment" character varying(500), "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_at" TIMESTAMP NOT NULL DEFAULT now(), CONSTRAINT "PK_231ae565c273ee700b283f15c1d" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TABLE "plans" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "coach_id" uuid NOT NULL, "name" character varying(100) NOT NULL, "price" numeric NOT NULL, "duration" character varying(15) NOT NULL, "description" character varying(500) NOT NULL, "features" character varying(100) array NOT NULL, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_at" TIMESTAMP NOT NULL DEFAULT now(), CONSTRAINT "PK_3720521a81c7c24fe9b7202ba61" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TABLE "specialties" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "name" character varying(255) NOT NULL, CONSTRAINT "PK_ba01cec5aa8ac48778a1d097e98" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TYPE "public"."coaches_status_enum" AS ENUM('PENDING', 'APPROVED', 'REJECTED')`);
        await queryRunner.query(`CREATE TABLE "coaches" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "user_id" uuid NOT NULL, "status" "public"."coaches_status_enum" NOT NULL DEFAULT 'PENDING', "experience" double precision NOT NULL, "about" character varying(500), "balance" numeric NOT NULL DEFAULT '0', CONSTRAINT "REL_bd9923ac72efde2d5895e118fa" UNIQUE ("user_id"), CONSTRAINT "PK_eddaece1a1f1b197fa39e6864a1" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TYPE "public"."complaints_status_enum" AS ENUM('PENDING', 'RESOLVED')`);
        await queryRunner.query(`CREATE TABLE "complaints" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "client_id" uuid NOT NULL, "coach_id" uuid NOT NULL, "description" text NOT NULL, "status" "public"."complaints_status_enum" NOT NULL DEFAULT 'PENDING', "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_at" TIMESTAMP NOT NULL DEFAULT now(), CONSTRAINT "PK_4b7566a2a489c2cc7c12ed076ad" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TABLE "clients" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "user_id" uuid NOT NULL, CONSTRAINT "REL_07a7a09b04e7b035c9d90cf498" UNIQUE ("user_id"), CONSTRAINT "PK_f1ab7cf3a5714dbc6bb4e1c28a4" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TABLE "subscriptions" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "client_id" uuid NOT NULL, "plan_id" uuid NOT NULL, "start_date" TIMESTAMP NOT NULL, "end_date" TIMESTAMP NOT NULL, "is_active" boolean NOT NULL DEFAULT true, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_at" TIMESTAMP NOT NULL DEFAULT now(), CONSTRAINT "PK_a87248d73155605cf782be9ee5e" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TYPE "public"."payments_status_enum" AS ENUM('pending', 'succeeded', 'failed', 'refunded', 'canceled')`);
        await queryRunner.query(`CREATE TABLE "payments" ("id" SERIAL NOT NULL, "client_id" uuid NOT NULL, "coach_id" uuid NOT NULL, "plan_id" uuid NOT NULL, "amount" numeric NOT NULL, "description" character varying, "payment_intent_id" character varying NOT NULL, "status" "public"."payments_status_enum" NOT NULL DEFAULT 'pending', "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_at" TIMESTAMP NOT NULL DEFAULT now(), CONSTRAINT "PK_197ab7af18c93fbb0c9b28b4a59" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TABLE "coaches_specialties" ("coach_id" uuid NOT NULL, "specialty_id" uuid NOT NULL, CONSTRAINT "PK_93bc0247376c00d0736651dd0d3" PRIMARY KEY ("coach_id", "specialty_id"))`);
        await queryRunner.query(`CREATE TYPE "public"."health_forms_fitness_goal_enum" AS ENUM('Weight Loss', 'Muscle Gain', 'Endurance', 'Flexibility', 'Tournament Prep', 'General Health', 'Other')`);
        await queryRunner.query(`CREATE TABLE "health_forms" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "height" character varying NOT NULL, "weight" character varying NOT NULL, "chronic_diseases" character varying, "has_disability" boolean NOT NULL, "disability_details" character varying, "favorite_food" character varying, "fitness_goal" "public"."health_forms_fitness_goal_enum" NOT NULL DEFAULT 'General Health', "client_id" uuid NOT NULL, "plan_id" uuid NOT NULL, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_at" TIMESTAMP NOT NULL DEFAULT now(), CONSTRAINT "PK_c41a3fd1f7f5a976753e685fba4" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TYPE "public"."messages_sender_type_enum" AS ENUM('CLIENT', 'COACH')`);
        await queryRunner.query(`CREATE TYPE "public"."messages_receiver_type_enum" AS ENUM('CLIENT', 'COACH')`);
        await queryRunner.query(`CREATE TABLE "messages" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "sender_id" uuid NOT NULL, "sender_type" "public"."messages_sender_type_enum" NOT NULL, "receiver_id" uuid NOT NULL, "receiver_type" "public"."messages_receiver_type_enum" NOT NULL, "content" text NOT NULL, "read" boolean NOT NULL DEFAULT false, "sent_at" TIMESTAMP NOT NULL DEFAULT now(), "client_id" uuid, "coach_id" uuid, CONSTRAINT "PK_18325f38ae6de43878487eff986" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "reviews" ADD CONSTRAINT "FK_c3fff9d4aaeae60e594d1284dfc" FOREIGN KEY ("coach_id") REFERENCES "coaches"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "reviews" ADD CONSTRAINT "FK_d4e7e923e6bb78a8f0add754493" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "plans" ADD CONSTRAINT "FK_e05fa585a12ec5496e5412d973d" FOREIGN KEY ("coach_id") REFERENCES "coaches"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "coaches" ADD CONSTRAINT "FK_bd9923ac72efde2d5895e118fa8" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "complaints" ADD CONSTRAINT "FK_7bc58e43f44bb23df52f2c1a981" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "complaints" ADD CONSTRAINT "FK_da59fa0edeb5aac6a5d36014ccc" FOREIGN KEY ("coach_id") REFERENCES "coaches"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "clients" ADD CONSTRAINT "FK_07a7a09b04e7b035c9d90cf4984" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "subscriptions" ADD CONSTRAINT "FK_03f469e6b8295eace12ecaaf428" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "subscriptions" ADD CONSTRAINT "FK_e45fca5d912c3a2fab512ac25dc" FOREIGN KEY ("plan_id") REFERENCES "plans"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "payments" ADD CONSTRAINT "FK_bce3f30c3460065a6aeca163258" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "payments" ADD CONSTRAINT "FK_932c9ee3a52b9c13af9e1564375" FOREIGN KEY ("coach_id") REFERENCES "coaches"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "payments" ADD CONSTRAINT "FK_f9b6a4c3196864cdd91b1a440ee" FOREIGN KEY ("plan_id") REFERENCES "plans"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "coaches_specialties" ADD CONSTRAINT "FK_df318ca18a744bb4309aedc9e9f" FOREIGN KEY ("coach_id") REFERENCES "coaches"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "coaches_specialties" ADD CONSTRAINT "FK_e2135a75a18767068bfe4bdc551" FOREIGN KEY ("specialty_id") REFERENCES "specialties"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "health_forms" ADD CONSTRAINT "FK_fa20451c288e5f91428bb9a362e" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "health_forms" ADD CONSTRAINT "FK_0264461d4815f6ded0532bec870" FOREIGN KEY ("plan_id") REFERENCES "plans"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "messages" ADD CONSTRAINT "FK_18df5ffb2002a89c11460d1c66e" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "messages" ADD CONSTRAINT "FK_e6daf8cb80182ea257e04f332d6" FOREIGN KEY ("coach_id") REFERENCES "coaches"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "messages" DROP CONSTRAINT "FK_e6daf8cb80182ea257e04f332d6"`);
        await queryRunner.query(`ALTER TABLE "messages" DROP CONSTRAINT "FK_18df5ffb2002a89c11460d1c66e"`);
        await queryRunner.query(`ALTER TABLE "health_forms" DROP CONSTRAINT "FK_0264461d4815f6ded0532bec870"`);
        await queryRunner.query(`ALTER TABLE "health_forms" DROP CONSTRAINT "FK_fa20451c288e5f91428bb9a362e"`);
        await queryRunner.query(`ALTER TABLE "coaches_specialties" DROP CONSTRAINT "FK_e2135a75a18767068bfe4bdc551"`);
        await queryRunner.query(`ALTER TABLE "coaches_specialties" DROP CONSTRAINT "FK_df318ca18a744bb4309aedc9e9f"`);
        await queryRunner.query(`ALTER TABLE "payments" DROP CONSTRAINT "FK_f9b6a4c3196864cdd91b1a440ee"`);
        await queryRunner.query(`ALTER TABLE "payments" DROP CONSTRAINT "FK_932c9ee3a52b9c13af9e1564375"`);
        await queryRunner.query(`ALTER TABLE "payments" DROP CONSTRAINT "FK_bce3f30c3460065a6aeca163258"`);
        await queryRunner.query(`ALTER TABLE "subscriptions" DROP CONSTRAINT "FK_e45fca5d912c3a2fab512ac25dc"`);
        await queryRunner.query(`ALTER TABLE "subscriptions" DROP CONSTRAINT "FK_03f469e6b8295eace12ecaaf428"`);
        await queryRunner.query(`ALTER TABLE "clients" DROP CONSTRAINT "FK_07a7a09b04e7b035c9d90cf4984"`);
        await queryRunner.query(`ALTER TABLE "complaints" DROP CONSTRAINT "FK_da59fa0edeb5aac6a5d36014ccc"`);
        await queryRunner.query(`ALTER TABLE "complaints" DROP CONSTRAINT "FK_7bc58e43f44bb23df52f2c1a981"`);
        await queryRunner.query(`ALTER TABLE "coaches" DROP CONSTRAINT "FK_bd9923ac72efde2d5895e118fa8"`);
        await queryRunner.query(`ALTER TABLE "plans" DROP CONSTRAINT "FK_e05fa585a12ec5496e5412d973d"`);
        await queryRunner.query(`ALTER TABLE "reviews" DROP CONSTRAINT "FK_d4e7e923e6bb78a8f0add754493"`);
        await queryRunner.query(`ALTER TABLE "reviews" DROP CONSTRAINT "FK_c3fff9d4aaeae60e594d1284dfc"`);
        await queryRunner.query(`DROP TABLE "messages"`);
        await queryRunner.query(`DROP TYPE "public"."messages_receiver_type_enum"`);
        await queryRunner.query(`DROP TYPE "public"."messages_sender_type_enum"`);
        await queryRunner.query(`DROP TABLE "health_forms"`);
        await queryRunner.query(`DROP TYPE "public"."health_forms_fitness_goal_enum"`);
        await queryRunner.query(`DROP TABLE "coaches_specialties"`);
        await queryRunner.query(`DROP TABLE "payments"`);
        await queryRunner.query(`DROP TYPE "public"."payments_status_enum"`);
        await queryRunner.query(`DROP TABLE "subscriptions"`);
        await queryRunner.query(`DROP TABLE "clients"`);
        await queryRunner.query(`DROP TABLE "complaints"`);
        await queryRunner.query(`DROP TYPE "public"."complaints_status_enum"`);
        await queryRunner.query(`DROP TABLE "coaches"`);
        await queryRunner.query(`DROP TYPE "public"."coaches_status_enum"`);
        await queryRunner.query(`DROP TABLE "specialties"`);
        await queryRunner.query(`DROP TABLE "plans"`);
        await queryRunner.query(`DROP TABLE "reviews"`);
        await queryRunner.query(`DROP TABLE "users"`);
        await queryRunner.query(`DROP TYPE "public"."users_role_enum"`);
    }

}
