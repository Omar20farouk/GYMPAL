import { MigrationInterface, QueryRunner } from "typeorm";

export class Sh1747434821231 implements MigrationInterface {
    name = 'Sh1747434821231'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "complaints" ADD "images" text array`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "complaints" DROP COLUMN "images"`);
    }

}
