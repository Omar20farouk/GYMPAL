import { MigrationInterface, QueryRunner } from 'typeorm';

export class SeparateChatAndMessages1716173520000
  implements MigrationInterface
{
  name = 'SeparateChatAndMessages1716173520000';

  public async up(queryRunner: QueryRunner): Promise<void> {
    // Backup existing messages
    await queryRunner.query(
      `CREATE TABLE "messages_backup" AS SELECT * FROM "messages"`,
    );

    // Create new chats table
    await queryRunner.query(
      `CREATE TABLE "chats" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "client_id" uuid NOT NULL, "coach_id" uuid NOT NULL, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_at" TIMESTAMP NOT NULL DEFAULT now(), CONSTRAINT "UQ_client_coach" UNIQUE ("client_id", "coach_id"), CONSTRAINT "PK_chats" PRIMARY KEY ("id"))`,
    );

    // Add foreign keys to chats table
    await queryRunner.query(
      `ALTER TABLE "chats" ADD CONSTRAINT "FK_chats_client" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`,
    );
    await queryRunner.query(
      `ALTER TABLE "chats" ADD CONSTRAINT "FK_chats_coach" FOREIGN KEY ("coach_id") REFERENCES "coaches"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`,
    );

    // Recreate messages table with chat_id
    await queryRunner.query(`DROP TABLE "messages"`);
    await queryRunner.query(
      `CREATE TABLE "messages" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "chat_id" uuid NOT NULL, "sender_id" uuid NOT NULL, "sender_type" "public"."messages_sender_type_enum" NOT NULL, "content" text NOT NULL, "read" boolean NOT NULL DEFAULT false, "sent_at" TIMESTAMP NOT NULL DEFAULT now(), "client_id" uuid, "coach_id" uuid, CONSTRAINT "PK_messages" PRIMARY KEY ("id"))`,
    );

    // Add foreign keys to messages table
    await queryRunner.query(
      `ALTER TABLE "messages" ADD CONSTRAINT "FK_messages_chat" FOREIGN KEY ("chat_id") REFERENCES "chats"("id") ON DELETE CASCADE ON UPDATE NO ACTION`,
    );
    await queryRunner.query(
      `ALTER TABLE "messages" ADD CONSTRAINT "FK_messages_client" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`,
    );
    await queryRunner.query(
      `ALTER TABLE "messages" ADD CONSTRAINT "FK_messages_coach" FOREIGN KEY ("coach_id") REFERENCES "coaches"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`,
    );

    // Migrate old messages to new schema
    await queryRunner.query(`
      INSERT INTO "chats" ("client_id", "coach_id")
      SELECT DISTINCT 
        CASE WHEN mb."sender_type" = 'CLIENT' THEN mb."sender_id" ELSE mb."receiver_id" END as client_id,
        CASE WHEN mb."sender_type" = 'COACH' THEN mb."sender_id" ELSE mb."receiver_id" END as coach_id
      FROM "messages_backup" mb
    `);

    // Insert messages with chat_id
    await queryRunner.query(`
      INSERT INTO "messages" ("chat_id", "sender_id", "sender_type", "content", "read", "sent_at", "client_id", "coach_id")
      SELECT 
        c."id" as chat_id,
        mb."sender_id",
        mb."sender_type",
        mb."content",
        mb."read",
        mb."sent_at",
        CASE WHEN mb."sender_type" = 'CLIENT' THEN mb."sender_id" ELSE mb."receiver_id" END as client_id,
        CASE WHEN mb."sender_type" = 'COACH' THEN mb."sender_id" ELSE mb."receiver_id" END as coach_id
      FROM "messages_backup" mb
      JOIN "chats" c ON 
        (c."client_id" = CASE WHEN mb."sender_type" = 'CLIENT' THEN mb."sender_id" ELSE mb."receiver_id" END AND
         c."coach_id" = CASE WHEN mb."sender_type" = 'COACH' THEN mb."sender_id" ELSE mb."receiver_id" END)
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    // Restore original messages table
    await queryRunner.query(
      `ALTER TABLE "messages" DROP CONSTRAINT "FK_messages_chat"`,
    );
    await queryRunner.query(
      `ALTER TABLE "messages" DROP CONSTRAINT "FK_messages_client"`,
    );
    await queryRunner.query(
      `ALTER TABLE "messages" DROP CONSTRAINT "FK_messages_coach"`,
    );
    await queryRunner.query(`DROP TABLE "messages"`);
    await queryRunner.query(
      `CREATE TABLE "messages" AS SELECT * FROM "messages_backup"`,
    );

    // Drop chats table
    await queryRunner.query(
      `ALTER TABLE "chats" DROP CONSTRAINT "FK_chats_client"`,
    );
    await queryRunner.query(
      `ALTER TABLE "chats" DROP CONSTRAINT "FK_chats_coach"`,
    );
    await queryRunner.query(`DROP TABLE "chats"`);

    // Drop backup table
    await queryRunner.query(`DROP TABLE "messages_backup"`);
  }
}
