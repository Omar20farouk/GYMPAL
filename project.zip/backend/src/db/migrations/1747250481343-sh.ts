import { MigrationInterface, QueryRunner } from 'typeorm';

export class Sh1747250481343 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      INSERT INTO specialties (name) VALUES
        ('General Fitness'),
        ('Weight Loss'),
        ('Muscle Building'),
        ('Tournament Preparation'),
        ('Mobility'),
        ('Specialized for Disabilities');
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      DELETE FROM specialties WHERE name IN (
        'General Fitness',
        'Weight Loss',
        'Muscle Building',
        'Tournament Preparation',
        'Mobility',
        'Specialized for Disabilities'
      );
    `);
  }
}
