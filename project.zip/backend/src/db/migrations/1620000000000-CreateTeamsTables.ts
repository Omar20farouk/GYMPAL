import { MigrationInterface, QueryRunner } from 'typeorm';

export class CreateTeamsTables1620000000000 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE "teams" (
        "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
        "name" character varying NOT NULL,
        "description" character varying(500),
        "coach_id" uuid NOT NULL,
        "created_at" TIMESTAMP NOT NULL DEFAULT now(),
        "updated_at" TIMESTAMP NOT NULL DEFAULT now(),
        CONSTRAINT "PK_teams" PRIMARY KEY ("id"),
        CONSTRAINT "FK_teams_coaches" FOREIGN KEY ("coach_id") REFERENCES "coaches"("id") ON DELETE CASCADE
      )
    `);

    await queryRunner.query(`
      CREATE TABLE "team_members" (
        "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
        "team_id" uuid NOT NULL,
        "user_id" uuid NOT NULL,
        "role" character varying NOT NULL DEFAULT 'MEMBER',
        "position" character varying(255),
        "created_at" TIMESTAMP NOT NULL DEFAULT now(),
        "updated_at" TIMESTAMP NOT NULL DEFAULT now(),
        CONSTRAINT "PK_team_members" PRIMARY KEY ("id"),
        CONSTRAINT "FK_team_members_teams" FOREIGN KEY ("team_id") REFERENCES "teams"("id") ON DELETE CASCADE,
        CONSTRAINT "FK_team_members_users" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE,
        CONSTRAINT "UQ_team_members_team_user" UNIQUE ("team_id", "user_id")
      )
    `);

    // Add index for faster team lookups
    await queryRunner.query(`
      CREATE INDEX "IDX_teams_coach_id" ON "teams" ("coach_id")
    `);

    // Add index for faster team member lookups
    await queryRunner.query(`
      CREATE INDEX "IDX_team_members_team_id" ON "team_members" ("team_id")
    `);

    await queryRunner.query(`
      CREATE INDEX "IDX_team_members_user_id" ON "team_members" ("user_id")
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX "IDX_team_members_user_id"`);
    await queryRunner.query(`DROP INDEX "IDX_team_members_team_id"`);
    await queryRunner.query(`DROP INDEX "IDX_teams_coach_id"`);
    await queryRunner.query(`DROP TABLE "team_members"`);
    await queryRunner.query(`DROP TABLE "teams"`);
  }
}
