import { MigrationInterface, QueryRunner } from "typeorm";

export class Sh1747348157804 implements MigrationInterface {
    name = 'Sh1747348157804'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "public"."plans_duration_unit_enum" AS ENUM('days', 'weeks', 'months')`);
        await queryRunner.query(`ALTER TABLE "plans" ADD "duration_unit" "public"."plans_duration_unit_enum" NOT NULL`);
        await queryRunner.query(`ALTER TABLE "plans" DROP COLUMN "duration"`);
        await queryRunner.query(`ALTER TABLE "plans" ADD "duration" numeric NOT NULL`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "plans" DROP COLUMN "duration"`);
        await queryRunner.query(`ALTER TABLE "plans" ADD "duration" character varying(15) NOT NULL`);
        await queryRunner.query(`ALTER TABLE "plans" DROP COLUMN "duration_unit"`);
        await queryRunner.query(`DROP TYPE "public"."plans_duration_unit_enum"`);
    }

}
