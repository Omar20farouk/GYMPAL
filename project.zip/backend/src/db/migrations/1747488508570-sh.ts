import { MigrationInterface, QueryRunner } from "typeorm";

export class Sh1747488508570 implements MigrationInterface {
    name = 'Sh1747488508570'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "team_members" DROP CONSTRAINT "FK_team_members_teams"`);
        await queryRunner.query(`ALTER TABLE "team_members" DROP CONSTRAINT "FK_team_members_users"`);
        await queryRunner.query(`ALTER TABLE "teams" DROP CONSTRAINT "FK_teams_coaches"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_team_members_team_id"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_team_members_user_id"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_teams_coach_id"`);
        await queryRunner.query(`ALTER TABLE "team_members" DROP CONSTRAINT "UQ_team_members_team_user"`);
        await queryRunner.query(`ALTER TYPE "public"."users_role_enum" RENAME TO "users_role_enum_old"`);
        await queryRunner.query(`CREATE TYPE "public"."users_role_enum" AS ENUM('CLIENT', 'COACH', 'ADMIN', 'TEAM_MEMBER')`);
        await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "role" TYPE "public"."users_role_enum" USING "role"::"text"::"public"."users_role_enum"`);
        await queryRunner.query(`DROP TYPE "public"."users_role_enum_old"`);
        await queryRunner.query(`ALTER TABLE "team_members" DROP COLUMN "role"`);
        await queryRunner.query(`CREATE TYPE "public"."team_members_role_enum" AS ENUM('MEMBER', 'ADMIN')`);
        await queryRunner.query(`ALTER TABLE "team_members" ADD "role" "public"."team_members_role_enum" NOT NULL DEFAULT 'MEMBER'`);
        await queryRunner.query(`ALTER TABLE "teams" ADD CONSTRAINT "UQ_a1df838977d51a13cc483ba013f" UNIQUE ("coach_id")`);
        await queryRunner.query(`ALTER TABLE "team_members" ADD CONSTRAINT "FK_fdad7d5768277e60c40e01cdcea" FOREIGN KEY ("team_id") REFERENCES "teams"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "team_members" ADD CONSTRAINT "FK_c2bf4967c8c2a6b845dadfbf3d4" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "teams" ADD CONSTRAINT "FK_a1df838977d51a13cc483ba013f" FOREIGN KEY ("coach_id") REFERENCES "coaches"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "teams" DROP CONSTRAINT "FK_a1df838977d51a13cc483ba013f"`);
        await queryRunner.query(`ALTER TABLE "team_members" DROP CONSTRAINT "FK_c2bf4967c8c2a6b845dadfbf3d4"`);
        await queryRunner.query(`ALTER TABLE "team_members" DROP CONSTRAINT "FK_fdad7d5768277e60c40e01cdcea"`);
        await queryRunner.query(`ALTER TABLE "teams" DROP CONSTRAINT "UQ_a1df838977d51a13cc483ba013f"`);
        await queryRunner.query(`ALTER TABLE "team_members" DROP COLUMN "role"`);
        await queryRunner.query(`DROP TYPE "public"."team_members_role_enum"`);
        await queryRunner.query(`ALTER TABLE "team_members" ADD "role" character varying NOT NULL DEFAULT 'MEMBER'`);
        await queryRunner.query(`CREATE TYPE "public"."users_role_enum_old" AS ENUM('ADMIN', 'CLIENT', 'COACH')`);
        await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "role" TYPE "public"."users_role_enum_old" USING "role"::"text"::"public"."users_role_enum_old"`);
        await queryRunner.query(`DROP TYPE "public"."users_role_enum"`);
        await queryRunner.query(`ALTER TYPE "public"."users_role_enum_old" RENAME TO "users_role_enum"`);
        await queryRunner.query(`ALTER TABLE "team_members" ADD CONSTRAINT "UQ_team_members_team_user" UNIQUE ("team_id", "user_id")`);
        await queryRunner.query(`CREATE INDEX "IDX_teams_coach_id" ON "teams" ("coach_id") `);
        await queryRunner.query(`CREATE INDEX "IDX_team_members_user_id" ON "team_members" ("user_id") `);
        await queryRunner.query(`CREATE INDEX "IDX_team_members_team_id" ON "team_members" ("team_id") `);
        await queryRunner.query(`ALTER TABLE "teams" ADD CONSTRAINT "FK_teams_coaches" FOREIGN KEY ("coach_id") REFERENCES "coaches"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "team_members" ADD CONSTRAINT "FK_team_members_users" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "team_members" ADD CONSTRAINT "FK_team_members_teams" FOREIGN KEY ("team_id") REFERENCES "teams"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
    }

}
