import { MigrationInterface, QueryRunner } from "typeorm";

export class Sh1747688509142 implements MigrationInterface {
    name = 'Sh1747688509142'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "qualifications" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "name" character varying(255) NOT NULL, CONSTRAINT "PK_9ed4d526ac3b76ba3f1c1080433" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TABLE "coaches_qualifications" ("coach_id" uuid NOT NULL, "qualification_id" uuid NOT NULL, CONSTRAINT "PK_5c11ee5883c0ce1a10d9a4d60e6" PRIMARY KEY ("coach_id", "qualification_id"))`);
        await queryRunner.query(`ALTER TABLE "payments" DROP CONSTRAINT "PK_197ab7af18c93fbb0c9b28b4a59"`);
        await queryRunner.query(`ALTER TABLE "payments" DROP COLUMN "id"`);
        await queryRunner.query(`ALTER TABLE "payments" ADD "id" uuid NOT NULL DEFAULT uuid_generate_v4()`);
        await queryRunner.query(`ALTER TABLE "payments" ADD CONSTRAINT "PK_197ab7af18c93fbb0c9b28b4a59" PRIMARY KEY ("id")`);
        await queryRunner.query(`ALTER TABLE "coaches_qualifications" ADD CONSTRAINT "FK_0a14100db0682641542d9deb12d" FOREIGN KEY ("coach_id") REFERENCES "coaches"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "coaches_qualifications" ADD CONSTRAINT "FK_b04c9fc1a2aa64ac2d17617b170" FOREIGN KEY ("qualification_id") REFERENCES "qualifications"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "coaches_qualifications" DROP CONSTRAINT "FK_b04c9fc1a2aa64ac2d17617b170"`);
        await queryRunner.query(`ALTER TABLE "coaches_qualifications" DROP CONSTRAINT "FK_0a14100db0682641542d9deb12d"`);
        await queryRunner.query(`ALTER TABLE "payments" DROP CONSTRAINT "PK_197ab7af18c93fbb0c9b28b4a59"`);
        await queryRunner.query(`ALTER TABLE "payments" DROP COLUMN "id"`);
        await queryRunner.query(`ALTER TABLE "payments" ADD "id" SERIAL NOT NULL`);
        await queryRunner.query(`ALTER TABLE "payments" ADD CONSTRAINT "PK_197ab7af18c93fbb0c9b28b4a59" PRIMARY KEY ("id")`);
        await queryRunner.query(`DROP TABLE "coaches_qualifications"`);
        await queryRunner.query(`DROP TABLE "qualifications"`);
    }

}
