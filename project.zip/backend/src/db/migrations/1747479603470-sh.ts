import { MigrationInterface, QueryRunner } from "typeorm";

export class Sh1747479603470 implements MigrationInterface {
    name = 'Sh1747479603470'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "chats" DROP CONSTRAINT "FK_chats_client"`);
        await queryRunner.query(`ALTER TABLE "chats" DROP CONSTRAINT "FK_chats_coach"`);
        await queryRunner.query(`ALTER TABLE "messages" DROP CONSTRAINT "FK_messages_chat"`);
        await queryRunner.query(`ALTER TABLE "messages" DROP CONSTRAINT "FK_messages_client"`);
        await queryRunner.query(`ALTER TABLE "messages" DROP CONSTRAINT "FK_messages_coach"`);
        await queryRunner.query(`ALTER TABLE "chats" DROP CONSTRAINT "UQ_client_coach"`);
        await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "city" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "chats" ADD CONSTRAINT "UQ_22e10d9b8587c12aafc61f9a593" UNIQUE ("client_id", "coach_id")`);
        await queryRunner.query(`ALTER TABLE "chats" ADD CONSTRAINT "FK_a0a4ca2299b536cf241d7b9f4bb" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "chats" ADD CONSTRAINT "FK_0bced03c7832ab769636a023c0b" FOREIGN KEY ("coach_id") REFERENCES "coaches"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "messages" ADD CONSTRAINT "FK_7540635fef1922f0b156b9ef74f" FOREIGN KEY ("chat_id") REFERENCES "chats"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "messages" ADD CONSTRAINT "FK_18df5ffb2002a89c11460d1c66e" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "messages" ADD CONSTRAINT "FK_e6daf8cb80182ea257e04f332d6" FOREIGN KEY ("coach_id") REFERENCES "coaches"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "messages" DROP CONSTRAINT "FK_e6daf8cb80182ea257e04f332d6"`);
        await queryRunner.query(`ALTER TABLE "messages" DROP CONSTRAINT "FK_18df5ffb2002a89c11460d1c66e"`);
        await queryRunner.query(`ALTER TABLE "messages" DROP CONSTRAINT "FK_7540635fef1922f0b156b9ef74f"`);
        await queryRunner.query(`ALTER TABLE "chats" DROP CONSTRAINT "FK_0bced03c7832ab769636a023c0b"`);
        await queryRunner.query(`ALTER TABLE "chats" DROP CONSTRAINT "FK_a0a4ca2299b536cf241d7b9f4bb"`);
        await queryRunner.query(`ALTER TABLE "chats" DROP CONSTRAINT "UQ_22e10d9b8587c12aafc61f9a593"`);
        await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "city" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "chats" ADD CONSTRAINT "UQ_client_coach" UNIQUE ("client_id", "coach_id")`);
        await queryRunner.query(`ALTER TABLE "messages" ADD CONSTRAINT "FK_messages_coach" FOREIGN KEY ("coach_id") REFERENCES "coaches"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "messages" ADD CONSTRAINT "FK_messages_client" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "messages" ADD CONSTRAINT "FK_messages_chat" FOREIGN KEY ("chat_id") REFERENCES "chats"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "chats" ADD CONSTRAINT "FK_chats_coach" FOREIGN KEY ("coach_id") REFERENCES "coaches"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "chats" ADD CONSTRAINT "FK_chats_client" FOREIGN KEY ("client_id") REFERENCES "clients"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

}
