import { MigrationInterface, QueryRunner } from "typeorm";

export class Sh1747491213945 implements MigrationInterface {
    name = 'Sh1747491213945'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "plans" ADD "delete_at" TIMESTAMP`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "plans" DROP COLUMN "delete_at"`);
    }

}
