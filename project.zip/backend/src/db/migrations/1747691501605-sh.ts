import { MigrationInterface, QueryRunner } from 'typeorm';

export class Sh1747691501605 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
INSERT INTO qualifications (name) VALUES
('Certified Personal Trainer (CPT)'),
('Certified Strength and Conditioning Specialist (CSCS)'),
('CrossFit Level 1 Trainer (CF-L1)'),
('National Academy of Sports Medicine (NASM-CPT)'),
('American Council on Exercise (ACE-CPT)'),
('International Sports Sciences Association (ISSA-CPT)'),
('Functional Movement Screening (FMS)'),
('CPR/AED Certification'),
('First Aid Certification'),
('Bachelor''s Degree in Exercise Science'),
('Bachelor''s Degree in Kinesiology'),
('Bachelor''s Degree in Physical Education'),
('Master''s Degree in Sports Science'),
('Diploma in Personal Training'),
('Nutrition Certification');
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      DELETE FROM qualifications WHERE name IN (
        'Certified Personal Trainer (CPT)',
        'Certified Strength and Conditioning Specialist (CSCS)',
        'CrossFit Level 1 Trainer (CF-L1)',
        'National Academy of Sports Medicine (NASM-CPT)',
        'American Council on Exercise (ACE-CPT)',
        'International Sports Sciences Association (ISSA-CPT)',
        'Functional Movement Screening (FMS)',
        'CPR/AED Certification',
        'First Aid Certification',
        'Bachelor''s Degree in Exercise Science',
        'Bachelor''s Degree in Kinesiology',
        'Bachelor''s Degree in Physical Education',
        'Master''s Degree in Sports Science',
        'Diploma in Personal Training',
        'Nutrition Certification'
      );
    `);
  }
}
