import { MigrationInterface, QueryRunner } from "typeorm";

export class Sh1749398572601 implements MigrationInterface {
    name = 'Sh1749398572601'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "coaches" ADD "profile_picture" text`);
        await queryRunner.query(`ALTER TABLE "coaches" ADD "cover_picture" text`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "coaches" DROP COLUMN "cover_picture"`);
        await queryRunner.query(`ALTER TABLE "coaches" DROP COLUMN "profile_picture"`);
    }

}
