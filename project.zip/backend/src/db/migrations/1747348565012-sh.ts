import { MigrationInterface, QueryRunner } from "typeorm";

export class Sh1747348565012 implements MigrationInterface {
    name = 'Sh1747348565012'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TYPE "public"."plans_duration_unit_enum" RENAME TO "plans_duration_unit_enum_old"`);
        await queryRunner.query(`CREATE TYPE "public"."plans_duration_unit_enum" AS ENUM('day', 'week', 'month')`);
        await queryRunner.query(`ALTER TABLE "plans" ALTER COLUMN "duration_unit" TYPE "public"."plans_duration_unit_enum" USING "duration_unit"::"text"::"public"."plans_duration_unit_enum"`);
        await queryRunner.query(`DROP TYPE "public"."plans_duration_unit_enum_old"`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "public"."plans_duration_unit_enum_old" AS ENUM('days', 'months', 'weeks')`);
        await queryRunner.query(`ALTER TABLE "plans" ALTER COLUMN "duration_unit" TYPE "public"."plans_duration_unit_enum_old" USING "duration_unit"::"text"::"public"."plans_duration_unit_enum_old"`);
        await queryRunner.query(`DROP TYPE "public"."plans_duration_unit_enum"`);
        await queryRunner.query(`ALTER TYPE "public"."plans_duration_unit_enum_old" RENAME TO "plans_duration_unit_enum"`);
    }

}
