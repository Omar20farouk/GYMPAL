import { Client } from 'src/clients/entities/client.entity';
import { Coach } from 'src/coaches/entities/coach.entity';
import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';

@Entity('reviews')
export class Review {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column('uuid')
  coachId: string;

  @ManyToOne(() => Coach, (coach) => coach.reviews)
  @JoinColumn({ name: 'coach_id' })
  coach: Coach;

  @Column('uuid')
  clientId: string;

  @ManyToOne(() => Client, (client) => client.reviews)
  @JoinColumn({ name: 'client_id' })
  client: Client;

  @Column('numeric')
  rating: number;

  @Column({ type: 'varchar', length: 500, nullable: true })
  comment?: string;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
