export class CreateReviewDto {
  rating: number;
  comment: string;
}
